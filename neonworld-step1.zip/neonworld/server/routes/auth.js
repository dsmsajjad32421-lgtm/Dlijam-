'use strict';
/**
 * AUTH ROUTES
 * POST /api/auth/register
 * POST /api/auth/login
 * POST /api/auth/logout
 * GET  /api/auth/me
 */

const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { v4: uuid } = require('uuid');

const router   = express.Router();
const db       = require('../config/db');
const { authLimiter, SECURITY, sanitizeString, isValidEmail } = require('../config/security');
const { requireAuth } = require('../middleware/auth');
const { logAudit, AUDIT_ACTIONS } = require('../utils/audit');

// ── Helper: sign a JWT and set an HTTP-only cookie ────────────────────────────
function issueToken(res, user) {
  const payload = {
    id:       user.id,
    username: user.username,
    email:    user.email,
    role:     user.role
  };
  const token = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn:  process.env.JWT_EXPIRES_IN || '7d',
    algorithm: 'HS256'
  });

  // HTTP-only cookie — JS can't read this, protects against XSS
  res.cookie('neonworld_token', token, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge:   SECURITY.COOKIE_MAX_AGE_MS
  });

  return token;
}

// ═══════════════════════════════════════════════════════════════════════════════
// POST /api/auth/register
// ═══════════════════════════════════════════════════════════════════════════════
router.post('/register', authLimiter, async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // ── Validate ──
    if (!username || !email || !password) {
      return res.status(400).json({ success: false, error: 'All fields are required.' });
    }

    const cleanUsername = sanitizeString(username, 20);
    const cleanEmail    = sanitizeString(email, 254).toLowerCase();

    if (!SECURITY.USERNAME_REGEX.test(cleanUsername)) {
      return res.status(400).json({
        success: false,
        error: 'Username may only contain letters, numbers, underscores and dashes.'
      });
    }
    if (cleanUsername.length < SECURITY.USERNAME_MIN) {
      return res.status(400).json({
        success: false, error: `Username must be at least ${SECURITY.USERNAME_MIN} characters.`
      });
    }
    if (!isValidEmail(cleanEmail)) {
      return res.status(400).json({ success: false, error: 'Invalid email address.' });
    }
    if (!SECURITY.PASSWORD_REGEX.test(password)) {
      return res.status(400).json({
        success: false,
        error: 'Password must be at least 8 characters with uppercase, lowercase, and a number.'
      });
    }

    // ── Check uniqueness ──
    const { rows: existing } = await db.query(
      'SELECT id FROM users WHERE email = $1 OR username = $2',
      [cleanEmail, cleanUsername]
    );
    if (existing.length > 0) {
      return res.status(409).json({
        success: false, error: 'Email or username already taken.'
      });
    }

    // ── Hash password ──
    const passwordHash = await bcrypt.hash(password, SECURITY.BCRYPT_ROUNDS);
    const userId       = uuid();

    // ── Insert user and profile in a transaction ──
    const client = await db.getClient();
    try {
      await client.query('BEGIN');

      await client.query(
        `INSERT INTO users (id, email, username, password_hash, role)
         VALUES ($1, $2, $3, $4, 'player')`,
        [userId, cleanEmail, cleanUsername, passwordHash]
      );

      const startCoins = Number(process.env.STARTING_COINS) || 100;

      await client.query(
        `INSERT INTO profiles (user_id, display_name, level, xp, coins, score)
         VALUES ($1, $2, 1, 0, $3, 0)`,
        [userId, cleanUsername, startCoins]
      );

      // Give the default character
      const { rows: defaultChar } = await client.query(
        'SELECT id FROM characters WHERE is_default = TRUE LIMIT 1'
      );
      if (defaultChar.length > 0) {
        await client.query(
          `INSERT INTO character_inventory (user_id, character_id, is_equipped)
           VALUES ($1, $2, TRUE)`,
          [userId, defaultChar[0].id]
        );
      }

      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }

    // ── Fetch the new user to sign a token ──
    const { rows } = await db.query(
      'SELECT id, email, username, role FROM users WHERE id = $1', [userId]
    );
    const newUser = rows[0];
    issueToken(res, newUser);

    logAudit(AUDIT_ACTIONS.USER_REGISTER, {
      userId: newUser.id, username: newUser.username, ip: req.ip
    });

    res.status(201).json({
      success: true,
      message: 'Account created successfully!',
      user: { id: newUser.id, username: newUser.username, email: newUser.email, role: newUser.role }
    });

  } catch (err) {
    console.error('Register error:', err.message);
    res.status(500).json({ success: false, error: 'Registration failed. Please try again.' });
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// POST /api/auth/login
// ═══════════════════════════════════════════════════════════════════════════════
router.post('/login', authLimiter, async (req, res) => {
  try {
    const { emailOrUsername, password } = req.body;

    if (!emailOrUsername || !password) {
      return res.status(400).json({ success: false, error: 'Email/username and password are required.' });
    }

    const identifier = sanitizeString(emailOrUsername, 254).toLowerCase();

    // Find user by email or username
    const { rows } = await db.query(
      `SELECT u.id, u.email, u.username, u.password_hash, u.role,
              u.is_banned, u.is_suspended, u.suspend_until
       FROM users u
       WHERE u.email = $1 OR LOWER(u.username) = $1
       LIMIT 1`,
      [identifier]
    );

    if (rows.length === 0) {
      logAudit(AUDIT_ACTIONS.USER_LOGIN_FAILED, { identifier, ip: req.ip, reason: 'not found' });
      // Use same error message as wrong password — prevents username enumeration
      return res.status(401).json({ success: false, error: 'Incorrect email/username or password.' });
    }

    const user = rows[0];

    // Check password
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      logAudit(AUDIT_ACTIONS.USER_LOGIN_FAILED, { userId: user.id, ip: req.ip, reason: 'wrong password' });
      return res.status(401).json({ success: false, error: 'Incorrect email/username or password.' });
    }

    // Check bans / suspensions
    if (user.is_banned) {
      return res.status(403).json({ success: false, error: 'Your account has been banned.' });
    }
    if (user.is_suspended && user.suspend_until && new Date(user.suspend_until) > new Date()) {
      return res.status(403).json({
        success: false,
        error: `Account suspended until ${new Date(user.suspend_until).toLocaleDateString()}.`
      });
    }

    // Update last login
    await db.query(
      'UPDATE users SET last_login_at = NOW(), last_login_ip = $1 WHERE id = $2',
      [req.ip, user.id]
    );

    // Fetch profile
    const { rows: profileRows } = await db.query(
      'SELECT * FROM profiles WHERE user_id = $1', [user.id]
    );
    const profile = profileRows[0] || null;

    issueToken(res, user);

    logAudit(AUDIT_ACTIONS.USER_LOGIN, { userId: user.id, username: user.username, ip: req.ip });

    res.json({
      success: true,
      message: 'Login successful!',
      user:    { id: user.id, username: user.username, email: user.email, role: user.role },
      profile
    });

  } catch (err) {
    console.error('Login error:', err.message);
    res.status(500).json({ success: false, error: 'Login failed. Please try again.' });
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// POST /api/auth/logout
// ═══════════════════════════════════════════════════════════════════════════════
router.post('/logout', requireAuth, async (req, res) => {
  logAudit(AUDIT_ACTIONS.USER_LOGOUT, { userId: req.user.id, username: req.user.username });

  res.clearCookie('neonworld_token', {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax'
  });

  res.json({ success: true, message: 'Logged out successfully.' });
});

// ═══════════════════════════════════════════════════════════════════════════════
// GET /api/auth/me
// Returns the currently authenticated user + profile
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/me', requireAuth, async (req, res) => {
  try {
    const { rows: profileRows } = await db.query(
      `SELECT p.*, c.sprite_key as equipped_sprite_key
       FROM profiles p
       LEFT JOIN character_inventory ci ON ci.user_id = p.user_id AND ci.is_equipped = TRUE
       LEFT JOIN characters c ON c.id = ci.character_id
       WHERE p.user_id = $1`,
      [req.user.id]
    );

    res.json({
      success: true,
      user:    req.user,
      profile: profileRows[0] || null
    });
  } catch (err) {
    console.error('Me error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to fetch profile.' });
  }
});

module.exports = router;
