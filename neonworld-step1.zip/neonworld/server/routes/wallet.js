'use strict';
/**
 * WALLET ROUTES
 * Stores only the PUBLIC wallet address — never private keys.
 *
 * GET  /api/wallet
 * POST /api/wallet/connect
 * POST /api/wallet/disconnect
 *
 * SECURITY RULES (enforced here):
 *  - We never ask for or store private keys or seed phrases.
 *  - We only store the public address the user provides.
 *  - The frontend uses a wallet library (e.g. MetaMask) to
 *    get the address from the user's own wallet app.
 */

const express = require('express');
const router  = express.Router();
const db      = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const { generalLimiter, sanitizeString } = require('../config/security');
const { logAudit, AUDIT_ACTIONS } = require('../utils/audit');

router.use(requireAuth, generalLimiter);

// Basic Ethereum address format check (0x + 40 hex chars)
const isValidAddress = (addr) =>
  typeof addr === 'string' && /^0x[0-9a-fA-F]{40}$/.test(addr);

// ═══════════════════════════════════════════════════════
// GET /api/wallet
// ═══════════════════════════════════════════════════════
router.get('/', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT public_address, wallet_type, connected_at
       FROM wallets WHERE user_id=$1 AND disconnected_at IS NULL`,
      [req.user.id]
    );
    res.json({
      success:  true,
      wallet:   rows[0] || null,
      connected: rows.length > 0
    });
  } catch (err) {
    console.error('Get wallet error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load wallet.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/wallet/connect
// ═══════════════════════════════════════════════════════
router.post('/connect', async (req, res) => {
  try {
    const { publicAddress, walletType } = req.body;

    if (!publicAddress) {
      return res.status(400).json({ success: false, error: 'publicAddress is required.' });
    }

    // Validate format — only ETH-style addresses accepted right now
    if (!isValidAddress(publicAddress)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid wallet address format. Expected 0x followed by 40 hex characters.'
      });
    }

    // SECURITY CHECK: reject anything that looks like a private key or seed phrase
    // Private keys are 64 hex chars (no 0x) or 66 with 0x
    if (/^(0x)?[0-9a-fA-F]{64}$/.test(publicAddress)) {
      return res.status(400).json({
        success: false,
        error: 'This looks like a private key. Never share your private key with anyone.'
      });
    }

    const safeType = sanitizeString(walletType || 'unknown', 30);

    // Disconnect any existing wallet first
    await db.query(
      `UPDATE wallets SET disconnected_at=NOW() WHERE user_id=$1 AND disconnected_at IS NULL`,
      [req.user.id]
    );

    // Insert new wallet connection
    await db.query(
      `INSERT INTO wallets (user_id, public_address, wallet_type)
       VALUES ($1, $2, $3)`,
      [req.user.id, publicAddress.toLowerCase(), safeType]
    );

    logAudit(AUDIT_ACTIONS.WALLET_CONNECTED, {
      userId: req.user.id,
      walletType: safeType,
      // Only log last 6 chars of address for partial privacy
      addressHint: publicAddress.slice(0, 6) + '...' + publicAddress.slice(-4)
    });

    res.json({
      success:       true,
      message:       'Wallet connected successfully.',
      public_address: publicAddress.toLowerCase(),
      wallet_type:   safeType
    });
  } catch (err) {
    console.error('Connect wallet error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to connect wallet.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/wallet/disconnect
// ═══════════════════════════════════════════════════════
router.post('/disconnect', async (req, res) => {
  try {
    await db.query(
      `UPDATE wallets SET disconnected_at=NOW()
       WHERE user_id=$1 AND disconnected_at IS NULL`,
      [req.user.id]
    );

    logAudit(AUDIT_ACTIONS.WALLET_DISCONNECTED, { userId: req.user.id });

    res.json({ success: true, message: 'Wallet disconnected.' });
  } catch (err) {
    console.error('Disconnect wallet error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to disconnect wallet.' });
  }
});

module.exports = router;
