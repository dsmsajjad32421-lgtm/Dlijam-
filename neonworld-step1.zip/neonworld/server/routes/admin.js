'use strict';
/**
 * ADMIN ROUTES
 * All routes require: requireAuth + requireAdmin middleware.
 * Only accounts with role='admin' or role='owner' can access.
 *
 * User Management
 * Character Management
 * Clothing Management
 * Mission Management
 * Game Economy / Settings
 * Announcements
 * Game Updates
 * Audit Logs
 */

const express = require('express');
const router  = express.Router();
const db      = require('../config/db');
const { requireAuth }  = require('../middleware/auth');
const { requireAdmin } = require('../middleware/admin');
const { adminLimiter, sanitizeString, SECURITY } = require('../config/security');
const { logAudit, AUDIT_ACTIONS } = require('../utils/audit');

// Every admin route requires authentication AND admin role
router.use(requireAuth, requireAdmin, adminLimiter);

const ADMIN_PAGE_SIZE = 25;

// ─────────────────────────────────────────────────────────────────────────────
// USER MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────

// GET /api/admin/users?page=1&search=username
router.get('/users', async (req, res) => {
  try {
    const page   = Math.max(1, parseInt(req.query.page) || 1);
    const search = sanitizeString(req.query.search || '', 50);
    const offset = (page - 1) * ADMIN_PAGE_SIZE;

    const whereClause = search
      ? `WHERE u.username ILIKE $3 OR u.email ILIKE $3`
      : '';
    const params = search
      ? [ADMIN_PAGE_SIZE, offset, `%${search}%`]
      : [ADMIN_PAGE_SIZE, offset];

    const { rows } = await db.query(
      `SELECT u.id, u.username, u.email, u.role, u.is_banned, u.is_suspended,
              u.created_at, u.last_login_at, u.last_login_ip,
              p.level, p.coins, p.score
       FROM users u
       LEFT JOIN profiles p ON p.user_id = u.id
       ${whereClause}
       ORDER BY u.created_at DESC
       LIMIT $1 OFFSET $2`,
      params
    );

    const countParams = search ? [`%${search}%`] : [];
    const { rows: countRows } = await db.query(
      `SELECT COUNT(*) FROM users u ${search ? 'WHERE u.username ILIKE $1 OR u.email ILIKE $1' : ''}`,
      countParams
    );

    res.json({
      success: true,
      users:   rows,
      total:   parseInt(countRows[0].count),
      page,
      totalPages: Math.ceil(parseInt(countRows[0].count) / ADMIN_PAGE_SIZE)
    });
  } catch (err) {
    console.error('Admin get users error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load users.' });
  }
});

// GET /api/admin/users/:id
router.get('/users/:id', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT u.*, p.level, p.xp, p.coins, p.score, p.missions_completed
       FROM users u LEFT JOIN profiles p ON p.user_id = u.id
       WHERE u.id = $1`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ success: false, error: 'User not found.' });

    // Recent audit logs for this user
    const { rows: logs } = await db.query(
      `SELECT action, details, created_at FROM audit_logs
       WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20`,
      [req.params.id]
    );

    res.json({ success: true, user: rows[0], recentActivity: logs });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to load user.' });
  }
});

// POST /api/admin/users/:id/ban
router.post('/users/:id/ban', async (req, res) => {
  try {
    const targetId = req.params.id;
    // Protect: cannot ban another owner
    const { rows } = await db.query(`SELECT role FROM users WHERE id=$1`, [targetId]);
    if (rows.length === 0) return res.status(404).json({ success: false, error: 'User not found.' });
    if (rows[0].role === 'owner') return res.status(403).json({ success: false, error: 'Cannot ban an owner account.' });

    await db.query(`UPDATE users SET is_banned=TRUE WHERE id=$1`, [targetId]);
    logAudit(AUDIT_ACTIONS.ADMIN_BAN_USER, {
      adminId: req.user.id, targetUserId: targetId, reason: req.body.reason
    });
    res.json({ success: true, message: 'User banned.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to ban user.' });
  }
});

// POST /api/admin/users/:id/unban
router.post('/users/:id/unban', async (req, res) => {
  try {
    await db.query(`UPDATE users SET is_banned=FALSE WHERE id=$1`, [req.params.id]);
    logAudit(AUDIT_ACTIONS.ADMIN_UNBAN_USER, { adminId: req.user.id, targetUserId: req.params.id });
    res.json({ success: true, message: 'User unbanned.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to unban user.' });
  }
});

// POST /api/admin/users/:id/suspend
router.post('/users/:id/suspend', async (req, res) => {
  try {
    const hours = parseInt(req.body.hours) || 24;
    const until = new Date(Date.now() + hours * 60 * 60 * 1000);
    await db.query(
      `UPDATE users SET is_suspended=TRUE, suspend_until=$1 WHERE id=$2`,
      [until.toISOString(), req.params.id]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_SUSPEND_USER, {
      adminId: req.user.id, targetUserId: req.params.id, hours, reason: req.body.reason
    });
    res.json({ success: true, message: `User suspended for ${hours} hours.` });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to suspend user.' });
  }
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', async (req, res) => {
  try {
    const { rows } = await db.query(`SELECT role, username FROM users WHERE id=$1`, [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, error: 'User not found.' });
    if (rows[0].role === 'owner') return res.status(403).json({ success: false, error: 'Cannot delete owner.' });

    await db.query(`DELETE FROM users WHERE id=$1`, [req.params.id]);
    logAudit(AUDIT_ACTIONS.ADMIN_DELETE_USER, {
      adminId: req.user.id, deletedUserId: req.params.id, username: rows[0].username
    });
    res.json({ success: true, message: 'User deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to delete user.' });
  }
});

// POST /api/admin/users/:id/coins  — adjust coins
router.post('/users/:id/coins', async (req, res) => {
  try {
    const amount = parseInt(req.body.amount);
    if (isNaN(amount)) return res.status(400).json({ success: false, error: 'Invalid amount.' });

    const { rows } = await db.query(
      `UPDATE profiles SET coins = GREATEST(0, coins + $1), updated_at=NOW()
       WHERE user_id=$2 RETURNING coins`,
      [amount, req.params.id]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_ADJUST_COINS, {
      adminId: req.user.id, targetUserId: req.params.id,
      amount, reason: req.body.reason
    });
    res.json({ success: true, newTotal: rows[0]?.coins, message: `Coins adjusted by ${amount}.` });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to adjust coins.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// CHARACTER MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────

router.get('/characters', async (req, res) => {
  try {
    const { rows } = await db.query(`SELECT * FROM characters ORDER BY sort_order, name`);
    res.json({ success: true, characters: rows });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to load.' }); }
});

router.post('/characters', async (req, res) => {
  try {
    const { name, description, sprite_key, sprite_path, rarity, coin_price, is_default, unlock_level, sort_order } = req.body;
    if (!name || !sprite_key) return res.status(400).json({ success: false, error: 'name and sprite_key required.' });

    const { rows } = await db.query(
      `INSERT INTO characters (name, description, sprite_key, sprite_path, rarity, coin_price, is_default, unlock_level, sort_order)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [name, description, sprite_key, sprite_path, rarity||'common', coin_price||0, is_default||false, unlock_level||1, sort_order||0]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_ADD_CHARACTER, { adminId: req.user.id, characterName: name });
    res.status(201).json({ success: true, character: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to add character.' });
  }
});

router.put('/characters/:id', async (req, res) => {
  try {
    const { name, description, coin_price, rarity, unlock_level, sort_order } = req.body;
    const { rows } = await db.query(
      `UPDATE characters SET name=$1, description=$2, coin_price=$3, rarity=$4, unlock_level=$5, sort_order=$6
       WHERE id=$7 RETURNING *`,
      [name, description, coin_price, rarity, unlock_level, sort_order, req.params.id]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_EDIT_CHARACTER, { adminId: req.user.id, characterId: req.params.id });
    res.json({ success: true, character: rows[0] });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to update.' }); }
});

router.put('/characters/:id/toggle', async (req, res) => {
  try {
    const { rows } = await db.query(
      `UPDATE characters SET is_enabled=$1 WHERE id=$2 RETURNING is_enabled`,
      [req.body.is_enabled, req.params.id]
    );
    res.json({ success: true, is_enabled: rows[0]?.is_enabled });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to toggle.' }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// CLOTHING MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────

router.get('/clothing', async (req, res) => {
  try {
    const { rows } = await db.query(`SELECT * FROM clothing ORDER BY category, sort_order`);
    res.json({ success: true, clothing: rows });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to load.' }); }
});

router.post('/clothing', async (req, res) => {
  try {
    const { name, description, category, sprite_key, coin_price, unlock_level } = req.body;
    if (!name || !category || !sprite_key) {
      return res.status(400).json({ success: false, error: 'name, category, sprite_key required.' });
    }
    const { rows } = await db.query(
      `INSERT INTO clothing (name, description, category, sprite_key, coin_price, unlock_level)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [name, description, category, sprite_key, coin_price||0, unlock_level||1]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_ADD_CLOTHING, { adminId: req.user.id, clothingName: name });
    res.status(201).json({ success: true, clothing: rows[0] });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to add clothing.' }); }
});

router.put('/clothing/:id', async (req, res) => {
  try {
    const { name, description, coin_price, unlock_level, sort_order } = req.body;
    const { rows } = await db.query(
      `UPDATE clothing SET name=$1, description=$2, coin_price=$3, unlock_level=$4, sort_order=$5
       WHERE id=$6 RETURNING *`,
      [name, description, coin_price, unlock_level, sort_order||0, req.params.id]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_EDIT_CLOTHING, { adminId: req.user.id, clothingId: req.params.id });
    res.json({ success: true, clothing: rows[0] });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to update.' }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// MISSION MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────

router.get('/missions', async (req, res) => {
  try {
    const { rows } = await db.query(`SELECT * FROM missions ORDER BY sort_order, name`);
    res.json({ success: true, missions: rows });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to load.' }); }
});

router.post('/missions', async (req, res) => {
  try {
    const { name, description, mission_type, zone, objectives, coin_reward, xp_reward, min_level, is_repeatable } = req.body;
    if (!name) return res.status(400).json({ success: false, error: 'name required.' });
    const { rows } = await db.query(
      `INSERT INTO missions (name, description, mission_type, zone, objectives, coin_reward, xp_reward, min_level, is_repeatable)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [name, description, mission_type||'mission_easy', zone||'neon_city',
       JSON.stringify(objectives||[]), coin_reward||100, xp_reward||200, min_level||1, is_repeatable||false]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_ADD_MISSION, { adminId: req.user.id, missionName: name });
    res.status(201).json({ success: true, mission: rows[0] });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to add mission.' }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// GAME SETTINGS
// ─────────────────────────────────────────────────────────────────────────────

router.get('/settings', async (req, res) => {
  try {
    const { rows } = await db.query(`SELECT * FROM game_settings ORDER BY key`);
    res.json({ success: true, settings: rows });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to load settings.' }); }
});

router.put('/settings', async (req, res) => {
  try {
    const { key, value } = req.body;
    if (!key || value === undefined) {
      return res.status(400).json({ success: false, error: 'key and value required.' });
    }
    const safeKey   = sanitizeString(key, 100);
    const safeValue = sanitizeString(String(value), 1000);

    await db.query(
      `UPDATE game_settings SET value=$1, updated_by=$2, updated_at=NOW() WHERE key=$3`,
      [safeValue, req.user.id, safeKey]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_UPDATE_SETTINGS, {
      adminId: req.user.id, key: safeKey, value: safeValue
    });
    res.json({ success: true, message: `Setting "${safeKey}" updated.` });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to update setting.' }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// ANNOUNCEMENTS
// ─────────────────────────────────────────────────────────────────────────────

router.get('/announcements', async (req, res) => {
  try {
    const { rows } = await db.query(`SELECT * FROM announcements ORDER BY created_at DESC`);
    res.json({ success: true, announcements: rows });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to load.' }); }
});

router.post('/announcements', async (req, res) => {
  try {
    const { title, body, type, publish_at, expires_at } = req.body;
    if (!title || !body) return res.status(400).json({ success: false, error: 'title and body required.' });
    const { rows } = await db.query(
      `INSERT INTO announcements (title, body, type, publish_at, expires_at, created_by)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [sanitizeString(title,100), sanitizeString(body,2000), type||'info',
       publish_at||null, expires_at||null, req.user.id]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_ADD_ANNOUNCEMENT, { adminId: req.user.id, title });
    res.status(201).json({ success: true, announcement: rows[0] });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to create announcement.' }); }
});

router.put('/announcements/:id', async (req, res) => {
  try {
    const { title, body, type } = req.body;
    const { rows } = await db.query(
      `UPDATE announcements SET title=$1, body=$2, type=$3 WHERE id=$4 RETURNING *`,
      [sanitizeString(title||'',100), sanitizeString(body||'',2000), type||'info', req.params.id]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_EDIT_ANNOUNCEMENT, { adminId: req.user.id, announcementId: req.params.id });
    res.json({ success: true, announcement: rows[0] });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to update.' }); }
});

router.post('/announcements/:id/publish', async (req, res) => {
  try {
    await db.query(
      `UPDATE announcements SET is_published=TRUE, publish_at=NOW() WHERE id=$1`, [req.params.id]
    );
    res.json({ success: true, message: 'Announcement published.' });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to publish.' }); }
});

router.delete('/announcements/:id', async (req, res) => {
  try {
    await db.query(`DELETE FROM announcements WHERE id=$1`, [req.params.id]);
    logAudit(AUDIT_ACTIONS.ADMIN_DELETE_ANNOUNCEMENT, { adminId: req.user.id, announcementId: req.params.id });
    res.json({ success: true, message: 'Announcement deleted.' });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to delete.' }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// GAME UPDATES (patch notes)
// ─────────────────────────────────────────────────────────────────────────────

router.get('/updates', async (req, res) => {
  try {
    const { rows } = await db.query(`SELECT * FROM game_updates ORDER BY created_at DESC LIMIT 20`);
    res.json({ success: true, updates: rows });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to load updates.' }); }
});

router.post('/updates', async (req, res) => {
  try {
    const { version, title, patch_notes } = req.body;
    if (!version || !title) return res.status(400).json({ success: false, error: 'version and title required.' });
    const { rows } = await db.query(
      `INSERT INTO game_updates (version, title, patch_notes, is_published, published_at, created_by)
       VALUES ($1,$2,$3,TRUE,NOW(),$4) RETURNING *`,
      [sanitizeString(version,20), sanitizeString(title,100), sanitizeString(patch_notes||'',5000), req.user.id]
    );
    // Also update game_settings version
    await db.query(
      `UPDATE game_settings SET value=$1 WHERE key='game_version'`, [version]
    );
    logAudit(AUDIT_ACTIONS.ADMIN_PUBLISH_UPDATE, { adminId: req.user.id, version, title });
    res.status(201).json({ success: true, update: rows[0] });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to publish update.' }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// AUDIT LOGS
// ─────────────────────────────────────────────────────────────────────────────

router.get('/audit-logs', async (req, res) => {
  try {
    const page   = Math.max(1, parseInt(req.query.page) || 1);
    const offset = (page - 1) * ADMIN_PAGE_SIZE;
    const { rows } = await db.query(
      `SELECT al.id, al.action, al.details, al.created_at, al.ip_address, u.username
       FROM audit_logs al
       LEFT JOIN users u ON u.id = al.user_id
       ORDER BY al.created_at DESC
       LIMIT $1 OFFSET $2`,
      [ADMIN_PAGE_SIZE, offset]
    );
    const { rows: countRows } = await db.query(`SELECT COUNT(*) FROM audit_logs`);
    res.json({
      success: true,
      logs:    rows,
      total:   parseInt(countRows[0].count),
      page,
      totalPages: Math.ceil(parseInt(countRows[0].count) / ADMIN_PAGE_SIZE)
    });
  } catch (err) { res.status(500).json({ success: false, error: 'Failed to load audit logs.' }); }
});

module.exports = router;
