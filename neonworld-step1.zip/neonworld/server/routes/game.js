'use strict';
/**
 * GAME ROUTES  (all rewards calculated SERVER-SIDE)
 *
 * POST /api/game/missions/start
 * POST /api/game/missions/complete
 * GET  /api/game/missions
 * GET  /api/game/missions/progress
 * POST /api/game/collect
 * POST /api/game/npc-interact
 * POST /api/game/animal-interact
 * POST /api/game/daily-bonus
 * GET  /api/game/announcements
 * GET  /api/game/settings
 */

const express = require('express');
const router  = express.Router();
const db      = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const { gameLimiter, sanitizeString } = require('../config/security');
const {
  validateCoinReward,
  validateXPReward,
  validateMissionDuration,
  calculateLevel
} = require('../utils/anticheat');
const { logAudit, AUDIT_ACTIONS } = require('../utils/audit');

router.use(requireAuth);
router.use(gameLimiter);

// ── Helper: award coins + XP and update level ─────────────────────────────────
async function awardPlayer(userId, coins, xp, action) {
  // Anti-cheat: clamp server-side
  const coinResult = validateCoinReward(coins, action, { userId });
  const xpResult   = validateXPReward(xp, action, { userId });

  const safeCoin = coinResult.coins;
  const safeXP   = xpResult.xp;

  // Fetch current XP to recalculate level
  const { rows } = await db.query(
    `SELECT xp, level FROM profiles WHERE user_id=$1`, [userId]
  );
  if (rows.length === 0) return null;

  const newTotalXP  = Number(rows[0].xp) + safeXP;
  const levelData   = calculateLevel(newTotalXP);
  const leveledUp   = levelData.level > rows[0].level;

  const { rows: updated } = await db.query(
    `UPDATE profiles
     SET coins = coins + $1,
         xp    = xp    + $2,
         score = score + $3,
         level = $4,
         updated_at = NOW()
     WHERE user_id = $5
     RETURNING coins, xp, score, level`,
    [safeCoin, safeXP, safeCoin, levelData.level, userId]
  );

  if (leveledUp) {
    logAudit(AUDIT_ACTIONS.LEVEL_UP, { userId, newLevel: levelData.level });
  }

  logAudit(AUDIT_ACTIONS.COINS_EARNED, { userId, coins: safeCoin, action });
  logAudit(AUDIT_ACTIONS.XP_EARNED,    { userId, xp: safeXP, action });

  return {
    ...updated[0],
    coins_gained: safeCoin,
    xp_gained:    safeXP,
    leveled_up:   leveledUp,
    level_data:   levelData
  };
}

// ═══════════════════════════════════════════════════════
// GET /api/game/missions
// ═══════════════════════════════════════════════════════
router.get('/missions', async (req, res) => {
  try {
    // Get player level to filter eligible missions
    const { rows: profileRows } = await db.query(
      `SELECT level FROM profiles WHERE user_id=$1`, [req.user.id]
    );
    const playerLevel = profileRows[0]?.level || 1;

    // All enabled missions the player can do
    const { rows: missions } = await db.query(
      `SELECT m.*,
        mp.status,
        mp.started_at,
        mp.completed_at,
        mp.progress
       FROM missions m
       LEFT JOIN mission_progress mp
         ON mp.mission_id = m.id AND mp.user_id = $1
       WHERE m.is_enabled = TRUE AND m.min_level <= $2
       ORDER BY m.sort_order ASC, m.name ASC`,
      [req.user.id, playerLevel]
    );

    res.json({ success: true, missions });
  } catch (err) {
    console.error('Get missions error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load missions.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/game/missions/start
// ═══════════════════════════════════════════════════════
router.post('/missions/start', async (req, res) => {
  try {
    const { missionId } = req.body;
    if (!missionId) return res.status(400).json({ success: false, error: 'missionId required.' });

    // Check mission exists and player meets requirements
    const { rows: missions } = await db.query(
      `SELECT m.*, p.level FROM missions m
       JOIN profiles p ON p.user_id=$1
       WHERE m.id=$2 AND m.is_enabled=TRUE`,
      [req.user.id, missionId]
    );
    if (missions.length === 0) return res.status(404).json({ success: false, error: 'Mission not found.' });
    const mission = missions[0];

    if (mission.level < mission.min_level) {
      return res.status(403).json({ success: false, error: `Need level ${mission.min_level} to start.` });
    }

    // Check if already in progress
    const { rows: existing } = await db.query(
      `SELECT status FROM mission_progress WHERE user_id=$1 AND mission_id=$2`,
      [req.user.id, missionId]
    );

    if (existing.length > 0) {
      if (existing[0].status === 'in_progress') {
        return res.status(409).json({ success: false, error: 'Mission already in progress.' });
      }
      if (existing[0].status === 'completed' && !mission.is_repeatable) {
        return res.status(409).json({ success: false, error: 'Mission already completed.' });
      }
      // Repeatable — update to in_progress
      await db.query(
        `UPDATE mission_progress
         SET status='in_progress', started_at=NOW(), completed_at=NULL, progress='{}'
         WHERE user_id=$1 AND mission_id=$2`,
        [req.user.id, missionId]
      );
    } else {
      await db.query(
        `INSERT INTO mission_progress (user_id, mission_id, status, started_at, progress)
         VALUES ($1, $2, 'in_progress', NOW(), '{}')`,
        [req.user.id, missionId]
      );
    }

    logAudit(AUDIT_ACTIONS.MISSION_STARTED, {
      userId: req.user.id, missionId, missionName: mission.name
    });

    res.json({
      success: true,
      message: `Mission "${mission.name}" started!`,
      mission: {
        id:         mission.id,
        name:       mission.name,
        objectives: mission.objectives
      }
    });
  } catch (err) {
    console.error('Start mission error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to start mission.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/game/missions/complete
// ═══════════════════════════════════════════════════════
router.post('/missions/complete', async (req, res) => {
  try {
    const { missionId } = req.body;
    if (!missionId) return res.status(400).json({ success: false, error: 'missionId required.' });

    // Get the mission progress (server-recorded start time)
    const { rows: progress } = await db.query(
      `SELECT mp.started_at, mp.status, m.mission_type,
              m.coin_reward, m.xp_reward, m.name
       FROM mission_progress mp
       JOIN missions m ON m.id = mp.mission_id
       WHERE mp.user_id=$1 AND mp.mission_id=$2`,
      [req.user.id, missionId]
    );

    if (progress.length === 0) {
      return res.status(404).json({ success: false, error: 'Mission not started.' });
    }
    const mp = progress[0];

    if (mp.status === 'completed') {
      return res.status(409).json({ success: false, error: 'Mission already completed.' });
    }

    // Anti-cheat: validate duration using server-recorded start time
    const durationCheck = validateMissionDuration(mp.started_at, mp.mission_type);
    if (!durationCheck.valid) {
      return res.status(400).json({
        success: false,
        error: `Cannot complete yet: ${durationCheck.reason}`
      });
    }

    // Mark complete
    await db.query(
      `UPDATE mission_progress
       SET status='completed', completed_at=NOW()
       WHERE user_id=$1 AND mission_id=$2`,
      [req.user.id, missionId]
    );

    // Award rewards — server calculates the actual amounts
    const result = await awardPlayer(
      req.user.id,
      mp.coin_reward,
      mp.xp_reward,
      mp.mission_type
    );

    logAudit(AUDIT_ACTIONS.MISSION_COMPLETE, {
      userId: req.user.id, missionId, missionName: mp.name,
      coinsAwarded: result.coins_gained, xpAwarded: result.xp_gained
    });

    res.json({
      success:    true,
      message:    `Mission "${mp.name}" complete!`,
      coins:      result.coins_gained,
      xp:         result.xp_gained,
      leveled_up: result.leveled_up,
      profile:    result
    });
  } catch (err) {
    console.error('Complete mission error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to complete mission.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/game/collect  — pick up an item in the world
// ═══════════════════════════════════════════════════════
router.post('/collect', async (req, res) => {
  try {
    const { itemType, zone } = req.body;
    const safeType = sanitizeString(itemType || 'collectible', 50);

    // Server decides the reward — client cannot inflate this
    const result = await awardPlayer(req.user.id, 20, 30, 'exploration');

    res.json({
      success: true,
      coins:   result.coins_gained,
      xp:      result.xp_gained,
      profile: result
    });
  } catch (err) {
    console.error('Collect error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to collect item.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/game/npc-interact
// ═══════════════════════════════════════════════════════
router.post('/npc-interact', async (req, res) => {
  try {
    const result = await awardPlayer(req.user.id, 10, 20, 'npc_interaction');
    res.json({ success: true, coins: result.coins_gained, xp: result.xp_gained, profile: result });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Interaction failed.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/game/animal-interact
// ═══════════════════════════════════════════════════════
router.post('/animal-interact', async (req, res) => {
  try {
    const result = await awardPlayer(req.user.id, 15, 15, 'animal_interaction');
    res.json({ success: true, coins: result.coins_gained, xp: result.xp_gained, profile: result });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Interaction failed.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/game/daily-bonus
// ═══════════════════════════════════════════════════════
router.post('/daily-bonus', async (req, res) => {
  try {
    // Check if already claimed today (using mission_progress with mission_type='daily')
    const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

    const { rows: existing } = await db.query(
      `SELECT id FROM mission_progress mp
       JOIN missions m ON m.id = mp.mission_id
       WHERE mp.user_id=$1
         AND m.mission_type='daily'
         AND DATE(mp.completed_at) = $2`,
      [req.user.id, today]
    );

    if (existing.length > 0) {
      return res.json({ success: false, error: 'Daily bonus already claimed today.', coins: 0 });
    }

    // Get bonus amount from game_settings
    const { rows: settingRows } = await db.query(
      `SELECT value FROM game_settings WHERE key='daily_bonus_coins'`
    );
    const bonusCoins = parseInt(settingRows[0]?.value || 50);

    const result = await awardPlayer(req.user.id, bonusCoins, 50, 'daily_bonus');

    res.json({
      success:   true,
      message:   'Daily bonus claimed!',
      coins:     result.coins_gained,
      new_total: result.coins,
      profile:   result
    });
  } catch (err) {
    console.error('Daily bonus error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to claim daily bonus.' });
  }
});

// ═══════════════════════════════════════════════════════
// GET /api/game/announcements  — public, no auth needed
// ═══════════════════════════════════════════════════════
router.get('/announcements', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT id, title, body, type, publish_at, expires_at
       FROM announcements
       WHERE is_published = TRUE
         AND (publish_at IS NULL OR publish_at <= NOW())
         AND (expires_at IS NULL OR expires_at > NOW())
       ORDER BY created_at DESC
       LIMIT 5`
    );
    res.json({ success: true, announcements: rows });
  } catch (err) {
    console.error('Announcements error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load announcements.' });
  }
});

// ═══════════════════════════════════════════════════════
// GET /api/game/settings  — live game config for clients
// ═══════════════════════════════════════════════════════
router.get('/settings', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT key, value, value_type FROM game_settings ORDER BY key`
    );
    const settings = {};
    rows.forEach(r => { settings[r.key] = r.value; });
    res.json({ success: true, settings });
  } catch (err) {
    console.error('Settings error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load settings.' });
  }
});

// ═══════════════════════════════════════════════════════
// GET /api/game/missions/progress
// ═══════════════════════════════════════════════════════
router.get('/missions/progress', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT mp.mission_id, mp.status, mp.started_at, mp.completed_at, mp.progress,
              m.name, m.coin_reward, m.xp_reward
       FROM mission_progress mp
       JOIN missions m ON m.id = mp.mission_id
       WHERE mp.user_id=$1`,
      [req.user.id]
    );
    res.json({ success: true, progress: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to load progress.' });
  }
});

module.exports = router;
