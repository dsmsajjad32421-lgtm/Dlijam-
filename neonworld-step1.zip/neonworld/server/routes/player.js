'use strict';
/**
 * PLAYER ROUTES
 * GET  /api/player/profile
 * POST /api/player/position
 * GET  /api/player/characters
 * POST /api/player/characters/equip
 * POST /api/player/characters/purchase
 * GET  /api/player/clothing
 * POST /api/player/clothing/equip
 * POST /api/player/clothing/unequip
 * POST /api/player/clothing/purchase
 * GET  /api/player/inventory
 */

const express = require('express');
const router  = express.Router();
const db      = require('../config/db');
const { requireAuth }   = require('../middleware/auth');
const { gameLimiter, SECURITY, sanitizeString } = require('../config/security');
const { validatePosition } = require('../utils/anticheat');
const { logAudit, AUDIT_ACTIONS } = require('../utils/audit');

// All player routes require auth
router.use(requireAuth);
router.use(gameLimiter);

// ═══════════════════════════════════════════════════════
// GET /api/player/profile
// ═══════════════════════════════════════════════════════
router.get('/profile', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT p.*, u.username, u.email, u.role,
              c.sprite_key as equipped_sprite_key,
              c.name       as equipped_char_name
       FROM profiles p
       JOIN users u ON u.id = p.user_id
       LEFT JOIN character_inventory ci ON ci.user_id = p.user_id AND ci.is_equipped = TRUE
       LEFT JOIN characters c ON c.id = ci.character_id
       WHERE p.user_id = $1`,
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Profile not found.' });
    }
    res.json({ success: true, profile: rows[0] });
  } catch (err) {
    console.error('Get profile error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load profile.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/player/position  — auto-save player position
// ═══════════════════════════════════════════════════════
router.post('/position', async (req, res) => {
  try {
    const { x, y, z, zone } = req.body;

    // Validate position server-side (anti-cheat)
    if (!validatePosition(
      parseFloat(x), parseFloat(y), parseFloat(z),
      { userId: req.user.id }
    )) {
      return res.status(400).json({ success: false, error: 'Invalid position.' });
    }

    const safeZone = sanitizeString(zone || 'neon_city', 50);

    await db.query(
      `UPDATE profiles SET pos_x=$1, pos_y=$2, pos_z=$3, current_zone=$4, updated_at=NOW()
       WHERE user_id=$5`,
      [parseFloat(x), parseFloat(y), parseFloat(z), safeZone, req.user.id]
    );

    res.json({ success: true });
  } catch (err) {
    console.error('Save position error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to save position.' });
  }
});

// ═══════════════════════════════════════════════════════
// GET /api/player/characters
// Returns all characters + which ones the player owns + equipped
// ═══════════════════════════════════════════════════════
router.get('/characters', async (req, res) => {
  try {
    // All enabled characters
    const { rows: all } = await db.query(
      `SELECT id, name, description, sprite_key, sprite_path, rarity,
              coin_price, is_default, unlock_level, sort_order
       FROM characters
       WHERE is_enabled = TRUE
       ORDER BY sort_order ASC, name ASC`
    );

    // Which ones this player owns
    const { rows: owned } = await db.query(
      `SELECT character_id, is_equipped
       FROM character_inventory
       WHERE user_id = $1`,
      [req.user.id]
    );

    const ownedIds   = owned.map(r => r.character_id);
    const equippedRow = owned.find(r => r.is_equipped);
    const equippedId  = equippedRow ? equippedRow.character_id : null;

    // Find equipped sprite key
    const equippedChar = all.find(c => c.id === equippedId);

    res.json({
      success:       true,
      all,
      owned:         ownedIds,
      equipped:      equippedId,
      equipped_key:  equippedChar ? equippedChar.sprite_key : null
    });
  } catch (err) {
    console.error('Get characters error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load characters.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/player/characters/equip
// ═══════════════════════════════════════════════════════
router.post('/characters/equip', async (req, res) => {
  try {
    const { characterId } = req.body;
    if (!characterId) {
      return res.status(400).json({ success: false, error: 'characterId is required.' });
    }

    // Check player owns this character
    const { rows: owned } = await db.query(
      `SELECT id FROM character_inventory
       WHERE user_id = $1 AND character_id = $2`,
      [req.user.id, characterId]
    );
    if (owned.length === 0) {
      return res.status(403).json({ success: false, error: 'You do not own this character.' });
    }

    const client = await db.getClient();
    try {
      await client.query('BEGIN');
      // Unequip all
      await client.query(
        `UPDATE character_inventory SET is_equipped = FALSE WHERE user_id = $1`,
        [req.user.id]
      );
      // Equip selected
      await client.query(
        `UPDATE character_inventory SET is_equipped = TRUE
         WHERE user_id = $1 AND character_id = $2`,
        [req.user.id, characterId]
      );
      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK'); throw e;
    } finally { client.release(); }

    res.json({ success: true, message: 'Character equipped!' });
  } catch (err) {
    console.error('Equip character error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to equip character.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/player/characters/purchase
// ═══════════════════════════════════════════════════════
router.post('/characters/purchase', async (req, res) => {
  try {
    const { characterId } = req.body;
    if (!characterId) {
      return res.status(400).json({ success: false, error: 'characterId is required.' });
    }

    // Get character info
    const { rows: chars } = await db.query(
      `SELECT id, name, coin_price, unlock_level, is_enabled
       FROM characters WHERE id = $1`,
      [characterId]
    );
    if (chars.length === 0 || !chars[0].is_enabled) {
      return res.status(404).json({ success: false, error: 'Character not found.' });
    }
    const character = chars[0];

    // Get player profile
    const { rows: profiles } = await db.query(
      `SELECT coins, level FROM profiles WHERE user_id = $1`, [req.user.id]
    );
    const profile = profiles[0];

    if (profile.level < character.unlock_level) {
      return res.status(403).json({
        success: false,
        error: `You need to be level ${character.unlock_level} to unlock this character.`
      });
    }
    if (profile.coins < character.coin_price) {
      return res.status(403).json({ success: false, error: 'Not enough coins.' });
    }

    // Check not already owned
    const { rows: alreadyOwned } = await db.query(
      `SELECT id FROM character_inventory WHERE user_id=$1 AND character_id=$2`,
      [req.user.id, characterId]
    );
    if (alreadyOwned.length > 0) {
      return res.status(409).json({ success: false, error: 'You already own this character.' });
    }

    // Transaction: deduct coins + add to inventory
    const client = await db.getClient();
    try {
      await client.query('BEGIN');
      await client.query(
        `UPDATE profiles SET coins = coins - $1, updated_at = NOW() WHERE user_id = $2`,
        [character.coin_price, req.user.id]
      );
      await client.query(
        `INSERT INTO character_inventory (user_id, character_id, is_equipped)
         VALUES ($1, $2, FALSE)`,
        [req.user.id, characterId]
      );
      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK'); throw e;
    } finally { client.release(); }

    // Return updated profile
    const { rows: updatedProfile } = await db.query(
      `SELECT coins, level, score, xp FROM profiles WHERE user_id = $1`, [req.user.id]
    );

    logAudit(AUDIT_ACTIONS.CHARACTER_UNLOCKED, {
      userId: req.user.id,
      characterId,
      characterName: character.name,
      coinCost: character.coin_price
    });

    res.json({
      success:  true,
      message:  `${character.name} unlocked!`,
      profile:  updatedProfile[0]
    });
  } catch (err) {
    console.error('Purchase character error:', err.message);
    res.status(500).json({ success: false, error: 'Purchase failed.' });
  }
});

// ═══════════════════════════════════════════════════════
// GET /api/player/clothing
// ═══════════════════════════════════════════════════════
router.get('/clothing', async (req, res) => {
  try {
    const { rows: all } = await db.query(
      `SELECT id, name, description, category, sprite_key, coin_price, unlock_level, sort_order
       FROM clothing WHERE is_enabled = TRUE ORDER BY category, sort_order`
    );
    const { rows: owned } = await db.query(
      `SELECT clothing_id, is_equipped FROM user_clothing WHERE user_id = $1`,
      [req.user.id]
    );
    res.json({
      success:  true,
      all,
      owned:    owned.map(r => r.clothing_id),
      equipped: owned.filter(r => r.is_equipped).map(r => r.clothing_id)
    });
  } catch (err) {
    console.error('Get clothing error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load clothing.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/player/clothing/equip
// ═══════════════════════════════════════════════════════
router.post('/clothing/equip', async (req, res) => {
  try {
    const { clothingId } = req.body;
    if (!clothingId) return res.status(400).json({ success: false, error: 'clothingId required.' });

    const { rows } = await db.query(
      `SELECT id FROM user_clothing WHERE user_id=$1 AND clothing_id=$2`,
      [req.user.id, clothingId]
    );
    if (rows.length === 0) return res.status(403).json({ success: false, error: 'You do not own this item.' });

    // Get category to unequip others of same category
    const { rows: catRows } = await db.query(
      `SELECT category FROM clothing WHERE id=$1`, [clothingId]
    );
    if (catRows.length > 0) {
      const { rows: sameCategory } = await db.query(
        `SELECT uc.clothing_id FROM user_clothing uc
         JOIN clothing cl ON cl.id = uc.clothing_id
         WHERE uc.user_id=$1 AND cl.category=$2 AND uc.is_equipped=TRUE`,
        [req.user.id, catRows[0].category]
      );
      for (const r of sameCategory) {
        await db.query(
          `UPDATE user_clothing SET is_equipped=FALSE WHERE user_id=$1 AND clothing_id=$2`,
          [req.user.id, r.clothing_id]
        );
      }
    }
    await db.query(
      `UPDATE user_clothing SET is_equipped=TRUE WHERE user_id=$1 AND clothing_id=$2`,
      [req.user.id, clothingId]
    );
    res.json({ success: true, message: 'Clothing equipped!' });
  } catch (err) {
    console.error('Equip clothing error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to equip clothing.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/player/clothing/unequip
// ═══════════════════════════════════════════════════════
router.post('/clothing/unequip', async (req, res) => {
  try {
    const { clothingId } = req.body;
    if (!clothingId) return res.status(400).json({ success: false, error: 'clothingId required.' });
    await db.query(
      `UPDATE user_clothing SET is_equipped=FALSE WHERE user_id=$1 AND clothing_id=$2`,
      [req.user.id, clothingId]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to unequip.' });
  }
});

// ═══════════════════════════════════════════════════════
// POST /api/player/clothing/purchase
// ═══════════════════════════════════════════════════════
router.post('/clothing/purchase', async (req, res) => {
  try {
    const { clothingId } = req.body;
    if (!clothingId) return res.status(400).json({ success: false, error: 'clothingId required.' });

    const { rows: items } = await db.query(
      `SELECT id, name, coin_price, unlock_level FROM clothing WHERE id=$1 AND is_enabled=TRUE`,
      [clothingId]
    );
    if (items.length === 0) return res.status(404).json({ success: false, error: 'Item not found.' });
    const item = items[0];

    const { rows: profiles } = await db.query(
      `SELECT coins, level FROM profiles WHERE user_id=$1`, [req.user.id]
    );
    const profile = profiles[0];

    if (profile.level < item.unlock_level) {
      return res.status(403).json({ success: false, error: `Need level ${item.unlock_level} to unlock.` });
    }
    if (profile.coins < item.coin_price) {
      return res.status(403).json({ success: false, error: 'Not enough coins.' });
    }

    const { rows: already } = await db.query(
      `SELECT id FROM user_clothing WHERE user_id=$1 AND clothing_id=$2`,
      [req.user.id, clothingId]
    );
    if (already.length > 0) return res.status(409).json({ success: false, error: 'Already owned.' });

    const client = await db.getClient();
    try {
      await client.query('BEGIN');
      await client.query(
        `UPDATE profiles SET coins=coins-$1, updated_at=NOW() WHERE user_id=$2`,
        [item.coin_price, req.user.id]
      );
      await client.query(
        `INSERT INTO user_clothing (user_id, clothing_id) VALUES ($1,$2)`,
        [req.user.id, clothingId]
      );
      await client.query('COMMIT');
    } catch (e) { await client.query('ROLLBACK'); throw e; }
    finally { client.release(); }

    const { rows: updated } = await db.query(
      `SELECT coins FROM profiles WHERE user_id=$1`, [req.user.id]
    );

    logAudit(AUDIT_ACTIONS.CLOTHING_UNLOCKED, {
      userId: req.user.id, clothingId, name: item.name, cost: item.coin_price
    });

    res.json({ success: true, message: `${item.name} purchased!`, profile: updated[0] });
  } catch (err) {
    console.error('Purchase clothing error:', err.message);
    res.status(500).json({ success: false, error: 'Purchase failed.' });
  }
});

// ═══════════════════════════════════════════════════════
// GET /api/player/inventory
// ═══════════════════════════════════════════════════════
router.get('/inventory', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT inv.quantity, it.id, it.name, it.description, it.item_type, it.sprite_key
       FROM inventory inv
       JOIN items it ON it.id = inv.item_id
       WHERE inv.user_id = $1 AND inv.quantity > 0
       ORDER BY it.name`,
      [req.user.id]
    );
    res.json({ success: true, items: rows });
  } catch (err) {
    console.error('Get inventory error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load inventory.' });
  }
});

module.exports = router;
