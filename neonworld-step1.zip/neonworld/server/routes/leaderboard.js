'use strict';
/**
 * LEADERBOARD ROUTES
 * GET /api/leaderboard?period=all_time&page=1
 * GET /api/leaderboard/rank  — the current player's own rank
 */

const express = require('express');
const router  = express.Router();
const db      = require('../config/db');
const { optionalAuth } = require('../middleware/auth');
const { generalLimiter } = require('../config/security');

router.use(generalLimiter);

const PAGE_SIZE = 20;

// ═══════════════════════════════════════════════════════
// GET /api/leaderboard
// ═══════════════════════════════════════════════════════
router.get('/', optionalAuth, async (req, res) => {
  try {
    const period = ['all_time', 'weekly', 'monthly'].includes(req.query.period)
      ? req.query.period : 'all_time';
    const page   = Math.max(1, parseInt(req.query.page) || 1);
    const offset = (page - 1) * PAGE_SIZE;

    let query;
    let params;

    if (period === 'all_time') {
      // All-time: rank by total score descending
      query = `
        SELECT
          u.username,
          p.display_name,
          p.level,
          p.score,
          p.coins,
          ROW_NUMBER() OVER (ORDER BY p.score DESC) AS rank_position
        FROM profiles p
        JOIN users u ON u.id = p.user_id
        WHERE u.is_banned = FALSE
        ORDER BY p.score DESC
        LIMIT $1 OFFSET $2
      `;
      params = [PAGE_SIZE, offset];

    } else if (period === 'weekly') {
      // Weekly: score earned in the past 7 days
      // We use profile score as a proxy for now;
      // a full weekly system uses a separate score_history table (added later)
      query = `
        SELECT
          u.username,
          p.display_name,
          p.level,
          p.score,
          ROW_NUMBER() OVER (ORDER BY p.score DESC) AS rank_position
        FROM profiles p
        JOIN users u ON u.id = p.user_id
        WHERE u.is_banned = FALSE
          AND p.updated_at >= NOW() - INTERVAL '7 days'
        ORDER BY p.score DESC
        LIMIT $1 OFFSET $2
      `;
      params = [PAGE_SIZE, offset];

    } else {
      // Monthly
      query = `
        SELECT
          u.username,
          p.display_name,
          p.level,
          p.score,
          ROW_NUMBER() OVER (ORDER BY p.score DESC) AS rank_position
        FROM profiles p
        JOIN users u ON u.id = p.user_id
        WHERE u.is_banned = FALSE
          AND p.updated_at >= NOW() - INTERVAL '30 days'
        ORDER BY p.score DESC
        LIMIT $1 OFFSET $2
      `;
      params = [PAGE_SIZE, offset];
    }

    const { rows: entries } = await db.query(query, params);

    // Total count for pagination
    const { rows: countRows } = await db.query(
      `SELECT COUNT(*) FROM profiles p
       JOIN users u ON u.id = p.user_id
       WHERE u.is_banned = FALSE`
    );
    const total     = parseInt(countRows[0].count);
    const totalPages = Math.ceil(total / PAGE_SIZE);

    // Logged-in player's own rank
    let myRank = null;
    if (req.user) {
      const { rows: myRankRows } = await db.query(
        `SELECT rank_position FROM (
           SELECT user_id,
                  ROW_NUMBER() OVER (ORDER BY score DESC) AS rank_position
           FROM profiles p2
           JOIN users u2 ON u2.id = p2.user_id
           WHERE u2.is_banned = FALSE
         ) ranked
         WHERE user_id = $1`,
        [req.user.id]
      );
      myRank = myRankRows[0]?.rank_position || null;
    }

    res.json({
      success:    true,
      period,
      page,
      totalPages,
      total,
      myRank,
      entries
    });
  } catch (err) {
    console.error('Leaderboard error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load leaderboard.' });
  }
});

// ═══════════════════════════════════════════════════════
// GET /api/leaderboard/rank  — current player's rank
// ═══════════════════════════════════════════════════════
router.get('/rank', optionalAuth, async (req, res) => {
  if (!req.user) return res.status(401).json({ success: false, error: 'Not authenticated.' });

  try {
    const { rows } = await db.query(
      `SELECT rank_pos, score, level FROM (
         SELECT p.user_id,
                p.score,
                p.level,
                ROW_NUMBER() OVER (ORDER BY p.score DESC) AS rank_pos
         FROM profiles p
         JOIN users u ON u.id = p.user_id
         WHERE u.is_banned = FALSE
       ) r
       WHERE user_id = $1`,
      [req.user.id]
    );

    res.json({
      success: true,
      rank:    rows[0]?.rank_pos  || null,
      score:   rows[0]?.score     || 0,
      level:   rows[0]?.level     || 1
    });
  } catch (err) {
    console.error('Rank error:', err.message);
    res.status(500).json({ success: false, error: 'Failed to load rank.' });
  }
});

module.exports = router;
