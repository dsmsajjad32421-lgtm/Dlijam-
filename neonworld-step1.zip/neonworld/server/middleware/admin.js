'use strict';
/**
 * ADMIN MIDDLEWARE
 * Must be used AFTER requireAuth.
 * Blocks anyone whose role is not admin or owner.
 */

const { SECURITY } = require('../config/security');
const { logAudit, AUDIT_ACTIONS } = require('../utils/audit');

const PRIVILEGED = [SECURITY.ROLES.ADMIN, SECURITY.ROLES.OWNER];

const requireAdmin = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ success: false, error: 'Not authenticated.' });
  }
  if (!PRIVILEGED.includes(req.user.role)) {
    logAudit(AUDIT_ACTIONS.UNAUTHORIZED_ADMIN_ATTEMPT, {
      userId:   req.user.id,
      username: req.user.username,
      role:     req.user.role,
      url:      req.originalUrl,
      ip:       req.ip
    });
    return res.status(403).json({ success: false, error: 'Admin access required.' });
  }
  next();
};

const requireOwner = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ success: false, error: 'Not authenticated.' });
  }
  if (req.user.role !== SECURITY.ROLES.OWNER) {
    return res.status(403).json({ success: false, error: 'Owner access required.' });
  }
  next();
};

module.exports = { requireAdmin, requireOwner };
