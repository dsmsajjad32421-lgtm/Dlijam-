'use strict';
/**
 * AUTH MIDDLEWARE
 * Checks that a valid JWT is present before allowing access to
 * protected routes. Token is read from either:
 *  1. HTTP-only cookie  "neonworld_token"  (most secure)
 *  2. Authorization: Bearer <token>  header  (for API clients)
 */

const jwt = require('jsonwebtoken');

const extractToken = (req) => {
  if (req.cookies && req.cookies.neonworld_token) {
    return req.cookies.neonworld_token;
  }
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) return auth.slice(7);
  return null;
};

/** Protect a route — request must be authenticated */
const requireAuth = (req, res, next) => {
  const token = extractToken(req);
  if (!token) {
    return res.status(401).json({ success: false, error: 'Not authenticated. Please log in.' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = {
      id:       decoded.id,
      username: decoded.username,
      email:    decoded.email,
      role:     decoded.role
    };
    next();
  } catch (err) {
    const msg = err.name === 'TokenExpiredError'
      ? 'Session expired. Please log in again.'
      : 'Invalid session. Please log in again.';
    return res.status(401).json({ success: false, error: msg });
  }
};

/** Optional auth — populates req.user if token exists, but never rejects */
const optionalAuth = (req, _res, next) => {
  const token = extractToken(req);
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = {
        id:       decoded.id,
        username: decoded.username,
        email:    decoded.email,
        role:     decoded.role
      };
    } catch (_) { req.user = null; }
  } else {
    req.user = null;
  }
  next();
};

module.exports = { requireAuth, optionalAuth };
