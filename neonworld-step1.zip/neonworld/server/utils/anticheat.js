'use strict';
/**
 * ANTI-CHEAT / SERVER-SIDE GAME VALIDATION
 *
 * RULE: The client NEVER determines rewards.
 * The client sends an ACTION → the server calculates the reward.
 * All limits below are the authoritative values.
 */

const { SECURITY } = require('../config/security');
const { logAudit, AUDIT_ACTIONS } = require('./audit');

// ── Per-action coin caps ──────────────────────────────────────────────────────
const COIN_CAPS = {
  mission_easy:       100,
  mission_medium:     300,
  mission_hard:       500,
  daily_bonus:        100,
  exploration:         50,
  npc_interaction:     20,
  item_collect:        30,
  race_win:           200,
  vehicle_stunt:       75,
  animal_interaction:  15,
  default:            100
};

// ── Per-action XP caps ────────────────────────────────────────────────────────
const XP_CAPS = {
  mission_easy:       200,
  mission_medium:     500,
  mission_hard:      1000,
  daily_bonus:        200,
  exploration:        100,
  level_area:         300,
  default:            200
};

// ── Minimum mission durations (seconds) ──────────────────────────────────────
const MISSION_MIN_DURATIONS = {
  mission_easy:   30,
  mission_medium: 90,
  mission_hard:  180,
  default:        30
};

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Validate and clamp a coin reward.
 * The server always calls this — never trusts the client's claimed amount.
 *
 * @returns {{ valid: boolean, coins: number, reason: string }}
 */
const validateCoinReward = (claimedCoins, action, context = {}) => {
  if (typeof claimedCoins !== 'number' || isNaN(claimedCoins)) {
    return { valid: false, coins: 0, reason: 'Non-numeric coin value' };
  }
  if (claimedCoins < 0) {
    return { valid: false, coins: 0, reason: 'Negative coins rejected' };
  }

  const cap = COIN_CAPS[action] ?? COIN_CAPS.default;

  if (claimedCoins > cap) {
    logAudit(AUDIT_ACTIONS.COIN_OVERFLOW_ATTEMPT, {
      ...context,
      claimedCoins,
      cap,
      action
    });
    return { valid: true, coins: cap, reason: `Clamped: ${claimedCoins} → ${cap}` };
  }

  return { valid: true, coins: claimedCoins, reason: 'OK' };
};

/**
 * Validate and clamp an XP reward.
 */
const validateXPReward = (claimedXP, action, context = {}) => {
  if (typeof claimedXP !== 'number' || isNaN(claimedXP)) {
    return { valid: false, xp: 0, reason: 'Non-numeric XP value' };
  }
  if (claimedXP < 0) {
    return { valid: false, xp: 0, reason: 'Negative XP rejected' };
  }

  const cap = XP_CAPS[action] ?? XP_CAPS.default;

  if (claimedXP > cap) {
    logAudit(AUDIT_ACTIONS.SUSPICIOUS_SCORE, {
      ...context,
      claimedXP,
      cap,
      action
    });
    return { valid: true, xp: cap, reason: `Clamped: ${claimedXP} → ${cap}` };
  }

  return { valid: true, xp: claimedXP, reason: 'OK' };
};

/**
 * Validate that a player position is inside the world bounds.
 */
const validatePosition = (x, y, z, context = {}) => {
  if (typeof x !== 'number' || typeof y !== 'number' || typeof z !== 'number') {
    return false;
  }
  const inBounds =
    Math.abs(x) <= SECURITY.WORLD_MAX_X &&
    Math.abs(z) <= SECURITY.WORLD_MAX_Z &&
    y >= SECURITY.WORLD_MIN_Y &&
    y <= SECURITY.WORLD_MAX_Y;

  if (!inBounds) {
    logAudit(AUDIT_ACTIONS.INVALID_POSITION, { ...context, x, y, z });
  }
  return inBounds;
};

/**
 * Compute player level from total XP.
 * This formula lives server-side and cannot be faked.
 *
 * Level   XP needed (cumulative)
 * 1       0
 * 2       100
 * 3       220
 * 4       364  … each level costs 20 % more than the last
 */
const calculateLevel = (totalXP) => {
  let level = 1;
  let xpForNext = 100;
  let accumulated = 0;

  while (totalXP >= accumulated + xpForNext && level < 100) {
    accumulated += xpForNext;
    level++;
    xpForNext = Math.floor(xpForNext * 1.2);
  }

  return {
    level,
    currentLevelXP: totalXP - accumulated,
    xpToNextLevel:  xpForNext,
    totalXP
  };
};

/**
 * Validate that enough real time has passed for a mission to be legit.
 *
 * @param {Date|string} startedAt  - when the mission was started (server recorded)
 * @param {string}      missionType - e.g. 'mission_easy'
 */
const validateMissionDuration = (startedAt, missionType) => {
  if (!startedAt) return { valid: false, reason: 'Mission not started' };

  const elapsed    = Date.now() - new Date(startedAt).getTime();
  const minSeconds = MISSION_MIN_DURATIONS[missionType] ?? MISSION_MIN_DURATIONS.default;
  const minMs      = minSeconds * 1000;

  if (elapsed < minMs) {
    return {
      valid: false,
      reason: `Too fast (${Math.floor(elapsed / 1000)}s elapsed, min ${minSeconds}s)`
    };
  }
  return { valid: true, reason: 'OK' };
};

module.exports = {
  validateCoinReward,
  validateXPReward,
  validatePosition,
  calculateLevel,
  validateMissionDuration,
  COIN_CAPS,
  XP_CAPS
};
