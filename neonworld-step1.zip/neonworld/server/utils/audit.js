'use strict';
/**
 * AUDIT LOGGING
 * Records important events for security review and debugging.
 * Phase 1: logs to console.
 * Phase 2 (after DB is ready): also writes to audit_logs table.
 */

const AUDIT_ACTIONS = {
  // Auth
  USER_REGISTER:             'USER_REGISTER',
  USER_LOGIN:                'USER_LOGIN',
  USER_LOGOUT:               'USER_LOGOUT',
  USER_LOGIN_FAILED:         'USER_LOGIN_FAILED',
  PASSWORD_RESET:            'PASSWORD_RESET',

  // Game economy (all server-side)
  MISSION_STARTED:           'MISSION_STARTED',
  MISSION_COMPLETE:          'MISSION_COMPLETE',
  COINS_EARNED:              'COINS_EARNED',
  COINS_SPENT:               'COINS_SPENT',
  XP_EARNED:                 'XP_EARNED',
  LEVEL_UP:                  'LEVEL_UP',
  ITEM_PURCHASED:            'ITEM_PURCHASED',
  CHARACTER_UNLOCKED:        'CHARACTER_UNLOCKED',
  CLOTHING_UNLOCKED:         'CLOTHING_UNLOCKED',

  // Wallet
  WALLET_CONNECTED:          'WALLET_CONNECTED',
  WALLET_DISCONNECTED:       'WALLET_DISCONNECTED',

  // Admin actions
  ADMIN_LOGIN:               'ADMIN_LOGIN',
  ADMIN_BAN_USER:            'ADMIN_BAN_USER',
  ADMIN_UNBAN_USER:          'ADMIN_UNBAN_USER',
  ADMIN_SUSPEND_USER:        'ADMIN_SUSPEND_USER',
  ADMIN_DELETE_USER:         'ADMIN_DELETE_USER',
  ADMIN_RESET_USER:          'ADMIN_RESET_USER',
  ADMIN_ADJUST_COINS:        'ADMIN_ADJUST_COINS',
  ADMIN_ADD_CHARACTER:       'ADMIN_ADD_CHARACTER',
  ADMIN_EDIT_CHARACTER:      'ADMIN_EDIT_CHARACTER',
  ADMIN_REMOVE_CHARACTER:    'ADMIN_REMOVE_CHARACTER',
  ADMIN_ADD_CLOTHING:        'ADMIN_ADD_CLOTHING',
  ADMIN_EDIT_CLOTHING:       'ADMIN_EDIT_CLOTHING',
  ADMIN_REMOVE_CLOTHING:     'ADMIN_REMOVE_CLOTHING',
  ADMIN_ADD_MISSION:         'ADMIN_ADD_MISSION',
  ADMIN_UPDATE_SETTINGS:     'ADMIN_UPDATE_SETTINGS',
  ADMIN_PUBLISH_UPDATE:      'ADMIN_PUBLISH_UPDATE',
  ADMIN_ADD_ANNOUNCEMENT:    'ADMIN_ADD_ANNOUNCEMENT',
  ADMIN_EDIT_ANNOUNCEMENT:   'ADMIN_EDIT_ANNOUNCEMENT',
  ADMIN_DELETE_ANNOUNCEMENT: 'ADMIN_DELETE_ANNOUNCEMENT',

  // Security flags
  SUSPICIOUS_SCORE:              'SUSPICIOUS_SCORE',
  UNAUTHORIZED_ADMIN_ATTEMPT:    'UNAUTHORIZED_ADMIN_ATTEMPT',
  RATE_LIMIT_HIT:                'RATE_LIMIT_HIT',
  INVALID_POSITION:              'INVALID_POSITION',
  COIN_OVERFLOW_ATTEMPT:         'COIN_OVERFLOW_ATTEMPT'
};

/**
 * Write an audit entry.
 * @param {string} action  - one of AUDIT_ACTIONS
 * @param {object} data    - any extra context (userId, ip, etc.)
 */
const logAudit = async (action, data = {}) => {
  const entry = {
    action,
    timestamp: new Date().toISOString(),
    ...data
  };

  // Always log to console (visible in server terminal)
  console.log(`📋 AUDIT [${action}]`, JSON.stringify(entry));

  // ── DB logging — activated in Step 2 once tables exist ──
  // try {
  //   const db = require('../config/db');
  //   await db.query(
  //     `INSERT INTO audit_logs (action, user_id, ip_address, details, created_at)
  //      VALUES ($1, $2, $3, $4, NOW())`,
  //     [action, data.userId || null, data.ip || null, JSON.stringify(data)]
  //   );
  // } catch (err) {
  //   console.error('⚠️  Audit DB write failed:', err.message);
  // }
};

module.exports = { logAudit, AUDIT_ACTIONS };
