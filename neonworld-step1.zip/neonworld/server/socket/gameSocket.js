'use strict';
/**
 * GAME SOCKET — REAL-TIME MULTIPLAYER
 *
 * All movement, chat, and live game events go through here.
 * Security rules:
 *  • Positions are validated server-side before broadcasting.
 *  • Coins/XP are NEVER awarded through sockets — use REST /api/game/* instead.
 *  • Chat messages are sanitised and length-capped.
 */

const { validatePosition } = require('../utils/anticheat');

const MAX_WORLD = 500;

module.exports = function attachGameSocket(io) {

  // Track connected players in memory:  socketId → { username, zone, x, y, z }
  const players = new Map();

  io.on('connection', (socket) => {
    console.log(`🟢 Socket connected: ${socket.id}`);

    // ── Join a world zone ──────────────────────────────────────────────────
    socket.on('join_zone', ({ zone = 'neon_city', username = 'Unknown', characterId = 'pink' } = {}) => {
      // Leave previous zone if any
      const prev = players.get(socket.id);
      if (prev) socket.leave(prev.zone);

      socket.join(zone);

      const playerData = {
        id: socket.id,
        username: String(username).slice(0, 20).replace(/[<>]/g, ''),
        characterId,
        zone,
        x: 0, y: 0, z: 0,
        rotation: 0,
        animation: 'idle'
      };
      players.set(socket.id, playerData);

      // Tell the arriving player about everyone already in the zone
      const zonemates = [];
      players.forEach((p, id) => {
        if (id !== socket.id && p.zone === zone) zonemates.push(p);
      });
      socket.emit('zone_snapshot', { players: zonemates });

      // Tell zonemates someone arrived
      socket.to(zone).emit('player_joined', playerData);
      console.log(`Player "${playerData.username}" joined zone: ${zone}`);
    });

    // ── Player movement ────────────────────────────────────────────────────
    socket.on('player_move', (data) => {
      const player = players.get(socket.id);
      if (!player) return;

      // Clamp to world bounds (teleport prevention)
      const x = Math.max(-MAX_WORLD, Math.min(MAX_WORLD, Number(data.x) || 0));
      const z = Math.max(-MAX_WORLD, Math.min(MAX_WORLD, Number(data.z) || 0));
      const y = Math.max(-50,         Math.min(200,       Number(data.y) || 0));

      if (!validatePosition(x, y, z, { socketId: socket.id, username: player.username })) return;

      // Update server-side record
      player.x = x; player.y = y; player.z = z;
      player.rotation  = Number(data.rotation)  || 0;
      player.animation = String(data.animation || 'idle').slice(0, 20);

      // Broadcast to others in same zone (NOT back to sender)
      socket.to(player.zone).emit('other_player_move', {
        id:          socket.id,
        x, y, z,
        rotation:  player.rotation,
        animation: player.animation
      });
    });

    // ── Chat ───────────────────────────────────────────────────────────────
    socket.on('chat_message', ({ message = '', zone = 'neon_city' } = {}) => {
      const player = players.get(socket.id);
      if (!player) return;

      const clean = String(message)
        .trim()
        .replace(/[<>]/g, '')  // strip HTML
        .slice(0, 200);        // max 200 chars

      if (!clean) return;

      io.to(player.zone).emit('chat_message', {
        id:        socket.id,
        username:  player.username,
        message:   clean,
        timestamp: Date.now()
      });
    });

    // ── Player action (emote, interact) ────────────────────────────────────
    socket.on('player_action', ({ action = '' } = {}) => {
      const player = players.get(socket.id);
      if (!player) return;

      const allowed = ['wave', 'sit', 'dance', 'interact'];
      if (!allowed.includes(action)) return;

      socket.to(player.zone).emit('player_action', {
        id: socket.id,
        action
      });
    });

    // ── Disconnect ─────────────────────────────────────────────────────────
    socket.on('disconnect', () => {
      const player = players.get(socket.id);
      if (player) {
        io.to(player.zone).emit('player_left', { id: socket.id });
        players.delete(socket.id);
      }
      console.log(`🔴 Socket disconnected: ${socket.id}`);
    });
  });
};
