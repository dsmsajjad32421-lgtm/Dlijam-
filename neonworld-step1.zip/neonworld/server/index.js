'use strict';

// Load .env FIRST before anything else
require('dotenv').config();

const express    = require('express');
const http       = require('http');
const path       = require('path');
const cors       = require('cors');
const helmet     = require('helmet');
const morgan     = require('morgan');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const { Server } = require('socket.io');

// ── Our own modules ──────────────────────────────
const { generalLimiter } = require('./config/security');

// Routes — wrapped so missing files don't crash startup
function tryRoute(filePath) {
  try { return require(filePath); }
  catch (e) { return null; }
}
const authRoutes        = tryRoute('./routes/auth');
const playerRoutes      = tryRoute('./routes/player');
const gameRoutes        = tryRoute('./routes/game');
const leaderboardRoutes = tryRoute('./routes/leaderboard');
const adminRoutes       = tryRoute('./routes/admin');
const walletRoutes      = tryRoute('./routes/wallet');

// ── App + HTTP server ────────────────────────────
const app    = express();
const server = http.createServer(app);

// ── Socket.io ────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: process.env.NODE_ENV === 'production'
      ? (process.env.CLIENT_URL || false)
      : '*',
    methods: ['GET', 'POST'],
    credentials: true
  }
});
app.set('io', io); // make io available in routes

// ── Global middleware ─────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? (process.env.CLIENT_URL || false)
    : '*',
  credentials: true
}));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser(process.env.COOKIE_SECRET));
if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev')); // HTTP request logging in dev mode
}
app.use(generalLimiter); // rate limit everything

// ── Static files ──────────────────────────────────
app.use(express.static(path.join(__dirname, '../client')));
app.use('/admin', express.static(path.join(__dirname, '../admin')));

// ── Public API endpoints ──────────────────────────
app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    status: 'online',
    game: 'Neon World',
    version: process.env.GAME_VERSION || '1.0.0',
    environment: process.env.NODE_ENV,
    timestamp: new Date().toISOString(),
    message: '🌆 Neon World server is live!'
  });
});

app.get('/api/info', (_req, res) => {
  res.json({
    success: true,
    gameName: 'Neon World',
    version: process.env.GAME_VERSION,
    startingCoins: Number(process.env.STARTING_COINS) || 100,
    maxPlayersPerZone: Number(process.env.MAX_PLAYERS_PER_ZONE) || 50,
    features: [
      'open-world', 'multiplayer', 'missions', 'leaderboard',
      'character-customization', 'clothing', 'vehicles',
      'day-night-cycle', 'weather', 'wallet-connect',
      'admin-panel', 'audit-logs', 'anti-cheat'
    ]
  });
});

// ── Mount route files (only if they exist) ─────────
if (authRoutes)        app.use('/api/auth',        authRoutes);
if (playerRoutes)      app.use('/api/player',      playerRoutes);
if (gameRoutes)        app.use('/api/game',        gameRoutes);
if (leaderboardRoutes) app.use('/api/leaderboard', leaderboardRoutes);
if (adminRoutes)       app.use('/api/admin',       adminRoutes);
if (walletRoutes)      app.use('/api/wallet',      walletRoutes);

// ── SPA fallback — serve index.html for all other GET requests ──
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '../client/index.html'));
});

// ── Global error handler ──────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  console.error('🔴 Unhandled error:', {
    message: err.message,
    url: req.url,
    method: req.method,
    timestamp: new Date().toISOString(),
    stack: process.env.NODE_ENV !== 'production' ? err.stack : undefined
  });
  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production'
      ? 'An error occurred. Please try again.'
      : err.message
  });
});

// ═══════════════════════════════════════════════════
// SOCKET.IO — REAL-TIME MULTIPLAYER
// ═══════════════════════════════════════════════════
require('./socket/gameSocket')(io);

// ═══════════════════════════════════════════════════
// START SERVER
// ═══════════════════════════════════════════════════
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  const line = '═'.repeat(42);
  console.log(`\n╔${line}╗`);
  console.log(`║${'      🌆  N E O N   W O R L D  🌆      '.padEnd(42)}║`);
  console.log(`╠${line}╣`);
  console.log(`║  ✅  Status  : ONLINE${' '.repeat(20)}║`);
  console.log(`║  🔌  Port    : ${PORT}${' '.repeat(36 - String(PORT).length)}║`);
  console.log(`║  🌍  Mode    : ${process.env.NODE_ENV}${' '.repeat(42 - 14 - process.env.NODE_ENV.length)}║`);
  console.log(`║  🏷️   Version : ${process.env.GAME_VERSION || '1.0.0'}${' '.repeat(36 - (process.env.GAME_VERSION || '1.0.0').length)}║`);
  console.log(`╠${line}╣`);
  console.log(`║  📡  /api/health  → server status${' '.repeat(8)}║`);
  console.log(`║  📡  /api/info    → game config${' '.repeat(10)}║`);
  console.log(`╚${line}╝\n`);
});

// ── Graceful shutdown ──
process.on('SIGTERM', () => {
  console.log('SIGTERM received — shutting down gracefully');
  server.close(() => process.exit(0));
});
process.on('uncaughtException',  e => console.error('💥 uncaughtException:', e.message));
process.on('unhandledRejection', e => console.error('💥 unhandledRejection:', e));
