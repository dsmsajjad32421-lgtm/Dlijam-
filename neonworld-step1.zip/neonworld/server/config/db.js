'use strict';
/**
 * DATABASE CONNECTION
 * Manages the PostgreSQL connection pool.
 * A "pool" keeps several connections open so the server
 * doesn't need to reconnect on every single request.
 */

const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // SSL is required by most cloud PostgreSQL providers
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false,
  max: 20,                     // max simultaneous DB connections
  idleTimeoutMillis: 30000,    // close idle connections after 30 s
  connectionTimeoutMillis: 5000 // fail if can't connect in 5 s
});

// Test the connection on startup
pool.connect((err, client, release) => {
  if (err) {
    console.warn('⚠️  Database not connected. Normal until Step 2 (DB setup).');
    console.warn('   Error:', err.message);
    return;
  }
  release();
  console.log('✅ Database connected successfully!');
});

/**
 * Run a parameterised query.
 * @example
 *   const { rows } = await db.query(
 *     'SELECT * FROM users WHERE id = $1',
 *     [userId]
 *   );
 */
const query = async (text, params) => {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    const ms = Date.now() - start;
    if (ms > 1000) {
      console.warn(`⚠️  Slow query (${ms}ms):`, text);
    }
    return result;
  } catch (error) {
    console.error('🔴 DB query error:', {
      message: error.message,
      query: text,
      timestamp: new Date().toISOString()
    });
    throw error;
  }
};

/**
 * Get a client for multi-step transactions.
 * Always call client.release() in a finally block!
 * @example
 *   const client = await db.getClient();
 *   try {
 *     await client.query('BEGIN');
 *     await client.query('UPDATE ...');
 *     await client.query('COMMIT');
 *   } catch(e) {
 *     await client.query('ROLLBACK');
 *     throw e;
 *   } finally {
 *     client.release();
 *   }
 */
const getClient = () => pool.connect();

module.exports = { query, getClient, pool };
