'use strict';
/**
 * SECURITY CONFIGURATION
 * Central place for all rate limiters, constants, and security helpers.
 */

const rateLimit = require('express-rate-limit');

// ── Rate Limiters ─────────────────────────────────────────────────────────────
// Prevent brute-force and DDoS attacks.

/** General API — 100 requests per 15 minutes */
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests. Try again in 15 minutes.' }
});

/** Auth (login / register) — 10 attempts per 15 minutes */
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  message: { success: false, error: 'Too many login attempts. Try again in 15 minutes.' }
});

/** Admin endpoints — 20 requests per 15 minutes */
const adminLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many admin requests.' }
});

/** Game actions — 300 per minute (frequent events like movement) */
const gameLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Slow down — too many game actions.' }
});

// ── Security Constants ────────────────────────────────────────────────────────
const SECURITY = {
  // Passwords
  PASSWORD_MIN_LENGTH: 8,
  // Must have: lowercase, uppercase, digit
  PASSWORD_REGEX: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/,
  BCRYPT_ROUNDS: 12,

  // Usernames
  USERNAME_MIN: 3,
  USERNAME_MAX: 20,
  USERNAME_REGEX: /^[a-zA-Z0-9_-]+$/,

  // JWT
  JWT_ALGORITHM: 'HS256',

  // Upload limits
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/png', 'image/webp'],
  MAX_UPLOAD_SIZE_BYTES: 5 * 1024 * 1024, // 5 MB

  // Game world — used by anti-cheat
  WORLD_MAX_X:  500,
  WORLD_MAX_Z:  500,
  WORLD_MIN_Y:  -50,
  WORLD_MAX_Y:  200,
  MAX_SPEED_UPS: 20, // units per second

  // Economy limits per single action
  MAX_COINS_PER_ACTION: 1000,
  MAX_XP_PER_ACTION:    500,

  // Session
  COOKIE_MAX_AGE_MS: 7 * 24 * 60 * 60 * 1000, // 7 days

  // Roles (ordered lowest → highest privilege)
  ROLES: {
    PLAYER:    'player',
    MODERATOR: 'moderator',
    ADMIN:     'admin',
    OWNER:     'owner'
  }
};

// ── Helpers ────────────────────────────────────────────────────────────────────
/** Strip HTML angle-brackets and trim. Safe for DB storage. */
const sanitizeString = (str, maxLen = 1000) => {
  if (typeof str !== 'string') return '';
  return str.trim().replace(/[<>]/g, '').slice(0, maxLen);
};

/** Basic email format check */
const isValidEmail = (email) =>
  typeof email === 'string' &&
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) &&
  email.length <= 254;

module.exports = {
  generalLimiter,
  authLimiter,
  adminLimiter,
  gameLimiter,
  SECURITY,
  sanitizeString,
  isValidEmail
};
