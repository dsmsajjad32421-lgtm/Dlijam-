-- ============================================================
-- NEON WORLD — COMPLETE DATABASE SCHEMA
-- Run this file once to create all tables.
-- Command: psql -U postgres -d neonworld -f database/schema.sql
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─────────────────────────────────────────────────────────────
-- USERS  (accounts & auth)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  email           VARCHAR(254) UNIQUE NOT NULL,
  username        VARCHAR(20)  UNIQUE NOT NULL,
  password_hash   TEXT         NOT NULL,
  role            VARCHAR(20)  NOT NULL DEFAULT 'player'
                               CHECK (role IN ('player','moderator','admin','owner')),
  is_banned       BOOLEAN      NOT NULL DEFAULT FALSE,
  is_suspended    BOOLEAN      NOT NULL DEFAULT FALSE,
  suspend_until   TIMESTAMPTZ,
  email_verified  BOOLEAN      NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  last_login_at   TIMESTAMPTZ,
  last_login_ip   INET
);

-- ─────────────────────────────────────────────────────────────
-- PROFILES  (game stats per user)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS profiles (
  id                  UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID        UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  display_name        VARCHAR(30),
  avatar_character_id UUID,                   -- FK set after characters table exists
  level               INT         NOT NULL DEFAULT 1,
  xp                  BIGINT      NOT NULL DEFAULT 0,
  coins               BIGINT      NOT NULL DEFAULT 100,
  score               BIGINT      NOT NULL DEFAULT 0,
  missions_completed  INT         NOT NULL DEFAULT 0,
  total_play_time_s   BIGINT      NOT NULL DEFAULT 0,
  current_zone        VARCHAR(50) NOT NULL DEFAULT 'neon_city',
  pos_x               FLOAT       NOT NULL DEFAULT 0,
  pos_y               FLOAT       NOT NULL DEFAULT 0,
  pos_z               FLOAT       NOT NULL DEFAULT 0,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- CHARACTERS  (available game characters — managed by admin)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS characters (
  id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(50) NOT NULL,
  description   TEXT,
  sprite_key    VARCHAR(100) NOT NULL,        -- key used by frontend to load sprites
  sprite_path   VARCHAR(255),                 -- path inside assets/characters/
  rarity        VARCHAR(20)  NOT NULL DEFAULT 'common'
                             CHECK (rarity IN ('common','rare','epic','legendary')),
  coin_price    INT          NOT NULL DEFAULT 0,
  is_default    BOOLEAN      NOT NULL DEFAULT FALSE,  -- free starting character
  is_enabled    BOOLEAN      NOT NULL DEFAULT TRUE,
  unlock_level  INT          NOT NULL DEFAULT 1,      -- min player level to unlock
  sort_order    INT          NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Add FK now that characters table exists
ALTER TABLE profiles
  ADD CONSTRAINT fk_profile_character
  FOREIGN KEY (avatar_character_id) REFERENCES characters(id) ON DELETE SET NULL;

-- ─────────────────────────────────────────────────────────────
-- CHARACTER INVENTORY  (which characters a user owns)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS character_inventory (
  id           UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID        NOT NULL REFERENCES users(id)      ON DELETE CASCADE,
  character_id UUID        NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  is_equipped  BOOLEAN     NOT NULL DEFAULT FALSE,
  unlocked_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, character_id)
);

-- ─────────────────────────────────────────────────────────────
-- CLOTHING  (all clothing items — managed by admin)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clothing (
  id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(50) NOT NULL,
  description   TEXT,
  category      VARCHAR(30) NOT NULL
                CHECK (category IN ('top','bottom','shoes','hat','glasses','accessory','full_outfit')),
  sprite_key    VARCHAR(100) NOT NULL,
  sprite_path   VARCHAR(255),
  coin_price    INT         NOT NULL DEFAULT 0,
  is_enabled    BOOLEAN     NOT NULL DEFAULT TRUE,
  unlock_level  INT         NOT NULL DEFAULT 1,
  sort_order    INT         NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- USER CLOTHING  (which clothes a user owns)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_clothing (
  id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID        NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  clothing_id UUID        NOT NULL REFERENCES clothing(id) ON DELETE CASCADE,
  is_equipped BOOLEAN     NOT NULL DEFAULT FALSE,
  unlocked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, clothing_id)
);

-- ─────────────────────────────────────────────────────────────
-- ITEMS  (collectibles, powerups, etc.)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS items (
  id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(50) NOT NULL,
  description TEXT,
  item_type   VARCHAR(30) NOT NULL
              CHECK (item_type IN ('collectible','powerup','key_item','vehicle_part','decoration')),
  sprite_key  VARCHAR(100),
  coin_price  INT         NOT NULL DEFAULT 0,
  is_enabled  BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- INVENTORY  (items a user holds)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS inventory (
  id        UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id   UUID        NOT NULL REFERENCES users(id)  ON DELETE CASCADE,
  item_id   UUID        NOT NULL REFERENCES items(id)  ON DELETE CASCADE,
  quantity  INT         NOT NULL DEFAULT 1 CHECK (quantity >= 0),
  UNIQUE (user_id, item_id)
);

-- ─────────────────────────────────────────────────────────────
-- MISSIONS
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS missions (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            VARCHAR(100) NOT NULL,
  description     TEXT,
  mission_type    VARCHAR(30)  NOT NULL
                  CHECK (mission_type IN ('mission_easy','mission_medium','mission_hard','daily','weekly','special')),
  zone            VARCHAR(50)  NOT NULL DEFAULT 'neon_city',
  objectives      JSONB        NOT NULL DEFAULT '[]',   -- array of objective objects
  coin_reward     INT          NOT NULL DEFAULT 100,
  xp_reward       INT          NOT NULL DEFAULT 200,
  item_reward_id  UUID         REFERENCES items(id) ON DELETE SET NULL,
  min_level       INT          NOT NULL DEFAULT 1,
  is_enabled      BOOLEAN      NOT NULL DEFAULT TRUE,
  is_repeatable   BOOLEAN      NOT NULL DEFAULT FALSE,
  sort_order      INT          NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- MISSION PROGRESS  (per-user mission state)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS mission_progress (
  id           UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID        NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  mission_id   UUID        NOT NULL REFERENCES missions(id) ON DELETE CASCADE,
  status       VARCHAR(20) NOT NULL DEFAULT 'in_progress'
               CHECK (status IN ('in_progress','completed','failed','abandoned')),
  started_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  progress     JSONB       NOT NULL DEFAULT '{}',   -- objective completion state
  UNIQUE (user_id, mission_id)
);

-- ─────────────────────────────────────────────────────────────
-- LEADERBOARD CACHE  (pre-computed rankings)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS leaderboard_cache (
  id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID        UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  username      VARCHAR(20) NOT NULL,
  score         BIGINT      NOT NULL DEFAULT 0,
  level         INT         NOT NULL DEFAULT 1,
  rank_position INT,
  period        VARCHAR(20) NOT NULL DEFAULT 'all_time'
                CHECK (period IN ('all_time','weekly','monthly')),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- WALLETS  (public address only — no private keys ever)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wallets (
  id             UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id        UUID        UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  public_address VARCHAR(100),        -- e.g. ETH address "0x..."
  wallet_type    VARCHAR(30),         -- e.g. "metamask", "walletconnect"
  connected_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  disconnected_at TIMESTAMPTZ
);

-- ─────────────────────────────────────────────────────────────
-- ANNOUNCEMENTS  (admin-published in-game messages)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS announcements (
  id           UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  title        VARCHAR(100) NOT NULL,
  body         TEXT         NOT NULL,
  type         VARCHAR(20)  NOT NULL DEFAULT 'info'
               CHECK (type IN ('info','warning','event','update','maintenance')),
  is_published BOOLEAN      NOT NULL DEFAULT FALSE,
  publish_at   TIMESTAMPTZ,           -- schedule for the future (NULL = immediate)
  expires_at   TIMESTAMPTZ,           -- auto-hide after this date
  created_by   UUID         REFERENCES users(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- GAME SETTINGS  (admin-controlled — fetched by all clients)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS game_settings (
  key         VARCHAR(100) PRIMARY KEY,
  value       TEXT         NOT NULL,
  value_type  VARCHAR(20)  NOT NULL DEFAULT 'string'
              CHECK (value_type IN ('string','number','boolean','json')),
  description TEXT,
  updated_by  UUID         REFERENCES users(id) ON DELETE SET NULL,
  updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- GAME UPDATES  (version history — admin publishes patch notes)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS game_updates (
  id           UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  version      VARCHAR(20) NOT NULL,
  title        VARCHAR(100) NOT NULL,
  patch_notes  TEXT,
  is_published BOOLEAN     NOT NULL DEFAULT FALSE,
  published_at TIMESTAMPTZ,
  created_by   UUID        REFERENCES users(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- AUDIT LOGS  (security & admin action trail)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
  id         BIGSERIAL   PRIMARY KEY,
  action     VARCHAR(80) NOT NULL,
  user_id    UUID        REFERENCES users(id) ON DELETE SET NULL,
  ip_address INET,
  details    JSONB       NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- INDEXES  (speed up common queries)
-- ─────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_users_email    ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_profiles_user  ON profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_profiles_score ON profiles(score DESC);
CREATE INDEX IF NOT EXISTS idx_char_inv_user  ON character_inventory(user_id);
CREATE INDEX IF NOT EXISTS idx_user_cloth     ON user_clothing(user_id);
CREATE INDEX IF NOT EXISTS idx_inventory_user ON inventory(user_id);
CREATE INDEX IF NOT EXISTS idx_mission_prog   ON mission_progress(user_id, mission_id);
CREATE INDEX IF NOT EXISTS idx_lb_score       ON leaderboard_cache(score DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action   ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_user     ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created  ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_announce_pub   ON announcements(is_published, publish_at);

-- ─────────────────────────────────────────────────────────────
-- updated_at auto-update trigger
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'users','profiles','characters','clothing','missions',
    'announcements','game_settings','game_updates'
  ] LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trg_%s_updated_at ON %I;
       CREATE TRIGGER trg_%s_updated_at
         BEFORE UPDATE ON %I
         FOR EACH ROW EXECUTE FUNCTION update_updated_at();',
      t, t, t, t
    );
  END LOOP;
END $$;
