'use strict';
/**
 * DATABASE SEED
 * Inserts starter data: admin user, default characters (your PNGs),
 * starter clothing, default game settings.
 *
 * Run: node database/seed.js
 */

require('dotenv').config();
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');
const db = require('../server/config/db');

async function seed() {
  console.log('🌱 Starting database seed...\n');

  // ── 1. Admin / Owner account ───────────────────────────────────────────────
  const adminEmail    = process.env.ADMIN_EMAIL    || 'admin@neonworld.com';
  const adminUsername = process.env.ADMIN_USERNAME || 'neonworldadmin';
  const adminPassword = process.env.ADMIN_PASSWORD || 'Admin123!Change';

  const passwordHash = await bcrypt.hash(adminPassword, 12);

  const { rows: existingAdmin } = await db.query(
    'SELECT id FROM users WHERE email = $1', [adminEmail]
  );

  let adminId;
  if (existingAdmin.length > 0) {
    adminId = existingAdmin[0].id;
    console.log('ℹ️  Admin account already exists — skipping.');
  } else {
    adminId = uuid();
    await db.query(
      `INSERT INTO users (id, email, username, password_hash, role, email_verified)
       VALUES ($1, $2, $3, $4, 'owner', TRUE)`,
      [adminId, adminEmail, adminUsername, passwordHash]
    );
    await db.query(
      `INSERT INTO profiles (user_id, display_name, level, xp, coins, score)
       VALUES ($1, $2, 100, 999999, 999999, 999999)`,
      [adminId, adminUsername]
    );
    console.log(`✅ Admin account created: ${adminEmail}`);
  }

  // ── 2. Default Characters (your uploaded PNGs) ────────────────────────────
  const characters = [
    {
      id: uuid(),
      name: 'Pink Goggles',
      description: 'A mysterious figure in a purple hoodie, always spotting opportunities through neon goggles.',
      sprite_key: 'pink_goggles',
      sprite_path: 'assets/characters/pink-goggles/',
      rarity: 'epic',
      coin_price: 0,
      is_default: true,
      unlock_level: 1,
      sort_order: 1
    },
    {
      id: uuid(),
      name: 'Blue Shadow',
      description: 'A blue android in a dark trench coat. Holds a mirror that shows another world.',
      sprite_key: 'blue_shadow',
      sprite_path: 'assets/characters/blue-shadow/',
      rarity: 'legendary',
      coin_price: 500,
      is_default: false,
      unlock_level: 5,
      sort_order: 2
    },
    {
      id: uuid(),
      name: 'Travel Buddy',
      description: 'The blue-red chibi explorer. Never goes anywhere without the trusty suitcase.',
      sprite_key: 'travel_buddy',
      sprite_path: 'assets/characters/travel-buddy/',
      rarity: 'rare',
      coin_price: 250,
      is_default: false,
      unlock_level: 3,
      sort_order: 3
    },
    {
      id: uuid(),
      name: 'Neon Hero',
      description: 'The caped hero in yellow and red. Battles the forces of darkness in the neon city.',
      sprite_key: 'neon_hero',
      sprite_path: 'assets/characters/neon-hero/',
      rarity: 'legendary',
      coin_price: 1000,
      is_default: false,
      unlock_level: 10,
      sort_order: 4
    }
  ];

  for (const c of characters) {
    const { rows } = await db.query(
      'SELECT id FROM characters WHERE sprite_key = $1', [c.sprite_key]
    );
    if (rows.length === 0) {
      await db.query(
        `INSERT INTO characters
           (id, name, description, sprite_key, sprite_path, rarity,
            coin_price, is_default, unlock_level, sort_order)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [c.id, c.name, c.description, c.sprite_key, c.sprite_path,
         c.rarity, c.coin_price, c.is_default, c.unlock_level, c.sort_order]
      );
      console.log(`✅ Character created: ${c.name}`);
    } else {
      console.log(`ℹ️  Character exists: ${c.name}`);
    }
  }

  // ── 3. Default Clothing ───────────────────────────────────────────────────
  const clothing = [
    { name: 'Purple Hoodie',      category: 'top',        sprite_key: 'purple_hoodie',      coin_price: 0,   unlock_level: 1 },
    { name: 'Neon Pink Goggles',  category: 'glasses',    sprite_key: 'neon_pink_goggles',  coin_price: 0,   unlock_level: 1 },
    { name: 'Dark Trench Coat',   category: 'full_outfit', sprite_key: 'dark_trench',        coin_price: 150, unlock_level: 3 },
    { name: 'Neon Cape',          category: 'accessory',  sprite_key: 'neon_cape',          coin_price: 200, unlock_level: 5 },
    { name: 'Yellow Hero Suit',   category: 'full_outfit', sprite_key: 'yellow_hero',        coin_price: 300, unlock_level: 8 },
    { name: 'Cyberpunk Jacket',   category: 'top',        sprite_key: 'cyber_jacket',       coin_price: 120, unlock_level: 2 },
    { name: 'Neon Sneakers',      category: 'shoes',      sprite_key: 'neon_sneakers',      coin_price:  80, unlock_level: 1 },
    { name: 'Holo Visor',         category: 'hat',        sprite_key: 'holo_visor',         coin_price: 175, unlock_level: 4 },
    { name: 'Neon Backpack',      category: 'accessory',  sprite_key: 'neon_backpack',      coin_price:  90, unlock_level: 2 },
    { name: 'Traveller Suitcase', category: 'accessory',  sprite_key: 'traveller_suitcase', coin_price: 100, unlock_level: 3 }
  ];

  for (const [i, cl] of clothing.entries()) {
    const { rows } = await db.query(
      'SELECT id FROM clothing WHERE sprite_key = $1', [cl.sprite_key]
    );
    if (rows.length === 0) {
      await db.query(
        `INSERT INTO clothing (name, category, sprite_key, coin_price, unlock_level, sort_order)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [cl.name, cl.category, cl.sprite_key, cl.coin_price, cl.unlock_level, i + 1]
      );
      console.log(`✅ Clothing created: ${cl.name}`);
    }
  }

  // ── 4. Default Missions ───────────────────────────────────────────────────
  const missions = [
    {
      name: 'First Steps',
      description: 'Explore the Neon City district and find 3 glowing orbs.',
      mission_type: 'mission_easy',
      zone: 'neon_city',
      objectives: JSON.stringify([
        { id: 1, type: 'collect', target: 'glowing_orb', count: 3, label: 'Collect 3 glowing orbs' }
      ]),
      coin_reward: 50, xp_reward: 100, min_level: 1, is_repeatable: false, sort_order: 1
    },
    {
      name: 'City Tour',
      description: 'Visit 5 different neon landmarks across the city.',
      mission_type: 'mission_easy',
      zone: 'neon_city',
      objectives: JSON.stringify([
        { id: 1, type: 'visit', target: 'neon_landmark', count: 5, label: 'Visit 5 landmarks' }
      ]),
      coin_reward: 75, xp_reward: 150, min_level: 1, is_repeatable: false, sort_order: 2
    },
    {
      name: 'Farm Life',
      description: 'Interact with 3 animals at the farm.',
      mission_type: 'mission_easy',
      zone: 'farm',
      objectives: JSON.stringify([
        { id: 1, type: 'interact', target: 'animal', count: 3, label: 'Interact with 3 animals' }
      ]),
      coin_reward: 60, xp_reward: 120, min_level: 1, is_repeatable: true, sort_order: 3
    },
    {
      name: 'Daily Bonus',
      description: 'Log in and collect your daily bonus.',
      mission_type: 'daily',
      zone: 'any',
      objectives: JSON.stringify([
        { id: 1, type: 'login', target: 'daily', count: 1, label: 'Claim daily bonus' }
      ]),
      coin_reward: 50, xp_reward: 50, min_level: 1, is_repeatable: true, sort_order: 100
    },
    {
      name: 'Street Racer',
      description: 'Complete a full lap of the neon highway in a vehicle.',
      mission_type: 'mission_medium',
      zone: 'highway',
      objectives: JSON.stringify([
        { id: 1, type: 'vehicle_lap', target: 'neon_highway', count: 1, label: 'Complete 1 highway lap' }
      ]),
      coin_reward: 200, xp_reward: 300, min_level: 3, is_repeatable: false, sort_order: 10
    }
  ];

  for (const m of missions) {
    const { rows } = await db.query(
      'SELECT id FROM missions WHERE name = $1', [m.name]
    );
    if (rows.length === 0) {
      await db.query(
        `INSERT INTO missions
           (name, description, mission_type, zone, objectives,
            coin_reward, xp_reward, min_level, is_repeatable, sort_order)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [m.name, m.description, m.mission_type, m.zone,
         m.objectives, m.coin_reward, m.xp_reward,
         m.min_level, m.is_repeatable, m.sort_order]
      );
      console.log(`✅ Mission created: ${m.name}`);
    }
  }

  // ── 5. Game Settings ──────────────────────────────────────────────────────
  const settings = [
    { key: 'starting_coins',       value: '100',  value_type: 'number', description: 'Coins given to new players' },
    { key: 'daily_bonus_coins',    value: '50',   value_type: 'number', description: 'Daily login coin bonus' },
    { key: 'xp_multiplier',        value: '1',    value_type: 'number', description: 'Global XP multiplier (1 = normal, 2 = double XP)' },
    { key: 'coin_multiplier',      value: '1',    value_type: 'number', description: 'Global coin multiplier' },
    { key: 'max_players_per_zone', value: '50',   value_type: 'number', description: 'Max players in one zone' },
    { key: 'game_version',         value: '1.0.0', value_type: 'string', description: 'Current game version' },
    { key: 'maintenance_mode',     value: 'false', value_type: 'boolean', description: 'Set true to lock out all players' },
    { key: 'weather_enabled',      value: 'true',  value_type: 'boolean', description: 'Enable dynamic weather' },
    { key: 'day_night_enabled',    value: 'true',  value_type: 'boolean', description: 'Enable day/night cycle' },
    { key: 'pvp_enabled',          value: 'false', value_type: 'boolean', description: 'Enable PvP combat' },
    { key: 'wallet_connect_enabled', value: 'true', value_type: 'boolean', description: 'Enable wallet connection feature' },
    { key: 'leaderboard_visible',  value: 'true',  value_type: 'boolean', description: 'Show global leaderboard' }
  ];

  for (const s of settings) {
    const { rows } = await db.query(
      'SELECT key FROM game_settings WHERE key = $1', [s.key]
    );
    if (rows.length === 0) {
      await db.query(
        `INSERT INTO game_settings (key, value, value_type, description)
         VALUES ($1,$2,$3,$4)`,
        [s.key, s.value, s.value_type, s.description]
      );
      console.log(`✅ Setting: ${s.key} = ${s.value}`);
    }
  }

  // ── 6. Welcome Announcement ───────────────────────────────────────────────
  const { rows: annRows } = await db.query(
    "SELECT id FROM announcements WHERE title = 'Welcome to Neon World!'"
  );
  if (annRows.length === 0) {
    await db.query(
      `INSERT INTO announcements (title, body, type, is_published, created_by)
       VALUES ($1, $2, 'info', TRUE, $3)`,
      [
        'Welcome to Neon World!',
        'The neon city is open! Explore, complete missions, earn coins, and compete on the leaderboard. New updates coming soon!',
        adminId
      ]
    );
    console.log('✅ Welcome announcement created');
  }

  console.log('\n🎉 Seed complete! Your Neon World is ready.\n');
  process.exit(0);
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err.message);
  process.exit(1);
});
