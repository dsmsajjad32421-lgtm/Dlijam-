/**
 * NEON WORLD — SOCKET CLIENT
 * Manages the real-time Socket.io connection for multiplayer.
 * Other game systems emit events through NeonSocket.
 */

const NeonSocket = (() => {

  let socket = null;
  let currentZone = 'neon_city';
  const otherPlayers = new Map();   // socketId → { mesh, data }
  const listeners = {};             // event → [callbacks]

  // ── Connect ────────────────────────────────────────────────────────────────
  function connect() {
    if (socket && socket.connected) return;

    socket = io({
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 2000
    });

    socket.on('connect', () => {
      console.log('🟢 Socket connected:', socket.id);
      emit('socket_connected', { id: socket.id });
    });

    socket.on('disconnect', (reason) => {
      console.log('🔴 Socket disconnected:', reason);
      emit('socket_disconnected', { reason });
    });

    socket.on('connect_error', (err) => {
      console.warn('⚠️  Socket connection error:', err.message);
    });

    // ── Game events from server ──────────────────────────────────────────
    socket.on('zone_snapshot', (data) => {
      // Other players already in the zone when we arrived
      emit('zone_snapshot', data);
    });

    socket.on('player_joined', (data) => {
      emit('player_joined', data);
    });

    socket.on('player_left', (data) => {
      otherPlayers.delete(data.id);
      emit('player_left', data);
    });

    socket.on('other_player_move', (data) => {
      emit('other_player_move', data);
    });

    socket.on('player_action', (data) => {
      emit('player_action', data);
    });

    socket.on('chat_message', (data) => {
      emit('chat_message', data);
    });
  }

  // ── Join a zone ────────────────────────────────────────────────────────────
  function joinZone(zone, username, characterId) {
    currentZone = zone;
    if (socket) {
      socket.emit('join_zone', { zone, username, characterId });
    }
  }

  // ── Send player movement ───────────────────────────────────────────────────
  function sendMove(x, y, z, rotation, animation) {
    if (!socket || !socket.connected) return;
    socket.emit('player_move', {
      x, y, z, rotation, animation,
      zone: currentZone
    });
  }

  // ── Send chat message ──────────────────────────────────────────────────────
  function sendChat(message) {
    if (!socket || !socket.connected) return;
    socket.emit('chat_message', { message, zone: currentZone });
  }

  // ── Send player action (emote etc.) ───────────────────────────────────────
  function sendAction(action) {
    if (!socket || !socket.connected) return;
    socket.emit('player_action', { action, zone: currentZone });
  }

  // ── Simple internal event bus ──────────────────────────────────────────────
  function on(event, cb) {
    if (!listeners[event]) listeners[event] = [];
    listeners[event].push(cb);
  }

  function off(event, cb) {
    if (!listeners[event]) return;
    listeners[event] = listeners[event].filter(fn => fn !== cb);
  }

  function emit(event, data) {
    (listeners[event] || []).forEach(cb => {
      try { cb(data); } catch (e) { console.error('Socket listener error:', e); }
    });
  }

  // ── Getters ────────────────────────────────────────────────────────────────
  const isConnected = () => socket && socket.connected;
  const getZone     = () => currentZone;
  const getSocketId = () => socket ? socket.id : null;

  return {
    connect,
    joinZone,
    sendMove,
    sendChat,
    sendAction,
    on,
    off,
    isConnected,
    getZone,
    getSocketId,
    otherPlayers
  };
})();

window.NeonSocket = NeonSocket;
