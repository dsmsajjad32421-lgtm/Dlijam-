/**
 * NEON WORLD — API CLIENT
 * All calls to the backend REST API go through this file.
 * Never call fetch() directly in other files — use NeonAPI instead.
 */

const NeonAPI = (() => {

  const BASE = '/api';

  /** Internal fetch wrapper */
  async function request(method, path, body = null) {
    const opts = {
      method,
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include'   // send cookies (JWT)
    };
    if (body) opts.body = JSON.stringify(body);

    try {
      const res  = await fetch(BASE + path, opts);
      const data = await res.json();

      if (!res.ok) {
        console.warn(`API ${method} ${path} →`, res.status, data.error);
      }
      return data;          // always return the parsed JSON
    } catch (err) {
      console.error(`API ${method} ${path} failed:`, err.message);
      return { success: false, error: 'Network error. Please check your connection.' };
    }
  }

  const get  = (path)       => request('GET',    path);
  const post = (path, body) => request('POST',   path, body);
  const put  = (path, body) => request('PUT',    path, body);
  const del  = (path)       => request('DELETE', path);

  return {
    // ── Health ──────────────────────────────────────────────
    health: () => get('/health'),
    info:   () => get('/info'),

    // ── Auth ────────────────────────────────────────────────
    register: (username, email, password) =>
      post('/auth/register', { username, email, password }),

    login: (emailOrUsername, password) =>
      post('/auth/login', { emailOrUsername, password }),

    logout: () => post('/auth/logout'),

    me: () => get('/auth/me'),   // get current logged-in user

    // ── Player ──────────────────────────────────────────────
    getProfile:  ()      => get('/player/profile'),
    savePosition: (x, y, z, zone) =>
      post('/player/position', { x, y, z, zone }),

    // ── Characters ──────────────────────────────────────────
    getCharacters:    ()   => get('/player/characters'),
    equipCharacter:   (id) => post('/player/characters/equip', { characterId: id }),
    purchaseCharacter:(id) => post('/player/characters/purchase', { characterId: id }),

    // ── Clothing ────────────────────────────────────────────
    getClothing:    () => get('/player/clothing'),
    equipClothing:  (id) => post('/player/clothing/equip',   { clothingId: id }),
    unequipClothing:(id) => post('/player/clothing/unequip', { clothingId: id }),
    purchaseClothing:(id)=> post('/player/clothing/purchase',{ clothingId: id }),

    // ── Missions ────────────────────────────────────────────
    getMissions:       ()     => get('/game/missions'),
    startMission:      (id)   => post('/game/missions/start',    { missionId: id }),
    completeMission:   (id)   => post('/game/missions/complete', { missionId: id }),
    getMissionProgress:()     => get('/game/missions/progress'),

    // ── Game events (all rewards calculated server-side) ────
    collectItem: (itemType, zone) =>
      post('/game/collect', { itemType, zone }),

    interactNPC: (npcId, zone) =>
      post('/game/npc-interact', { npcId, zone }),

    interactAnimal: (animalType, zone) =>
      post('/game/animal-interact', { animalType, zone }),

    claimDailyBonus: () =>
      post('/game/daily-bonus'),

    // ── Leaderboard ─────────────────────────────────────────
    getLeaderboard: (period = 'all_time', page = 1) =>
      get(`/leaderboard?period=${period}&page=${page}`),

    // ── Announcements ───────────────────────────────────────
    getAnnouncements: () => get('/game/announcements'),

    // ── Game settings ───────────────────────────────────────
    getSettings: () => get('/game/settings'),

    // ── Wallet ──────────────────────────────────────────────
    connectWallet: (publicAddress, walletType) =>
      post('/wallet/connect', { publicAddress, walletType }),

    disconnectWallet: () => post('/wallet/disconnect'),

    getWallet: () => get('/wallet'),

    // ── Inventory ───────────────────────────────────────────
    getInventory: () => get('/player/inventory'),

    // ── Admin (only works for admin/owner accounts) ──────────
    admin: {
      getUsers:      (page = 1, search = '') =>
        get(`/admin/users?page=${page}&search=${encodeURIComponent(search)}`),
      getUser:       (id)   => get(`/admin/users/${id}`),
      banUser:       (id, reason)  => post(`/admin/users/${id}/ban`,     { reason }),
      unbanUser:     (id)          => post(`/admin/users/${id}/unban`),
      suspendUser:   (id, hours, reason) =>
        post(`/admin/users/${id}/suspend`, { hours, reason }),
      deleteUser:    (id)   => del(`/admin/users/${id}`),
      adjustCoins:   (id, amount, reason) =>
        post(`/admin/users/${id}/coins`, { amount, reason }),

      getCharacters: ()     => get('/admin/characters'),
      addCharacter:  (data) => post('/admin/characters', data),
      editCharacter: (id, data) => put(`/admin/characters/${id}`, data),
      toggleCharacter:(id, enabled) =>
        put(`/admin/characters/${id}/toggle`, { is_enabled: enabled }),

      getClothing:   ()     => get('/admin/clothing'),
      addClothing:   (data) => post('/admin/clothing', data),
      editClothing:  (id, data) => put(`/admin/clothing/${id}`, data),

      getMissions:   ()     => get('/admin/missions'),
      addMission:    (data) => post('/admin/missions', data),

      getSettings:   ()     => get('/admin/settings'),
      updateSetting: (key, value) => put('/admin/settings', { key, value }),

      getAnnouncements:      ()     => get('/admin/announcements'),
      createAnnouncement:    (data) => post('/admin/announcements', data),
      editAnnouncement:      (id, data) => put(`/admin/announcements/${id}`, data),
      deleteAnnouncement:    (id)   => del(`/admin/announcements/${id}`),
      publishAnnouncement:   (id)   => post(`/admin/announcements/${id}/publish`),

      getAuditLogs:  (page = 1) => get(`/admin/audit-logs?page=${page}`),

      publishUpdate: (data) => post('/admin/updates', data),
      getUpdates:    ()     => get('/admin/updates')
    }
  };
})();

// Make globally available
window.NeonAPI = NeonAPI;
