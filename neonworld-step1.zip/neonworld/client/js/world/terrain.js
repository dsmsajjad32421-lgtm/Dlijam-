/**
 * NEON WORLD — TERRAIN
 * Builds the physical ground plane, hills, water, roads, and
 * coloured zone materials (grass, soil, city concrete).
 * The world is 1000×1000 units. Zones:
 *
 *   centre          → neon city (concrete)
 *   north           → farm / grass
 *   south           → beach / water
 *   east            → hills / forest
 *   west            → industrial / soil
 */

const NeonTerrain = (() => {

  // ── Materials ──────────────────────────────────────────────────────────────
  function buildMaterials() {
    return {
      // Neon city concrete — dark with subtle blue tint
      concrete: new THREE.MeshLambertMaterial({ color: 0x0d0d1e }),

      // Grass — muted green for the farm zone
      grass: new THREE.MeshLambertMaterial({ color: 0x1a3a1a }),

      // Soil — brown earth
      soil: new THREE.MeshLambertMaterial({ color: 0x2a1a0a }),

      // Sand / beach
      sand: new THREE.MeshLambertMaterial({ color: 0x2a2010 }),

      // Road asphalt
      road: new THREE.MeshLambertMaterial({ color: 0x080810 }),

      // Road markings (yellow)
      roadMark: new THREE.MeshLambertMaterial({ color: 0xffe600, emissive: 0xffe600, emissiveIntensity: 0.4 }),

      // Water — emissive neon blue plane
      water: new THREE.MeshLambertMaterial({
        color:     0x001a33,
        emissive:  0x003366,
        emissiveIntensity: 0.3,
        transparent: true,
        opacity: 0.85
      }),

      // Mountain rock
      rock: new THREE.MeshLambertMaterial({ color: 0x1a1520 }),
    };
  }

  // ── Ground plane (flat base) ───────────────────────────────────────────────
  function buildGround(mat) {
    const geo  = new THREE.PlaneGeometry(1000, 1000, 1, 1);
    const mesh = new THREE.Mesh(geo, mat.concrete);
    mesh.rotation.x  = -Math.PI / 2;
    mesh.receiveShadow = true;
    mesh.name = 'ground_base';
    NeonScene.add(mesh);
  }

  // ── Zone patches ─────────────────────────────────────────────────────────
  function buildZonePatch(mat, color, x, z, w, h, yOff = 0.01) {
    const geo  = new THREE.PlaneGeometry(w, h);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.rotation.x   = -Math.PI / 2;
    mesh.position.set(x, yOff, z);
    mesh.receiveShadow = true;
    NeonScene.add(mesh);
    return mesh;
  }

  // ── Roads ─────────────────────────────────────────────────────────────────
  function buildRoad(mat, x, z, length, width, horizontal = true) {
    const geo  = new THREE.PlaneGeometry(
      horizontal ? length : width,
      horizontal ? width  : length
    );
    const mesh = new THREE.Mesh(geo, mat.road);
    mesh.rotation.x   = -Math.PI / 2;
    mesh.position.set(x, 0.02, z);
    mesh.receiveShadow = true;
    NeonScene.add(mesh);

    // Centre dashes
    const dashCount = Math.floor((horizontal ? length : length) / 12);
    for (let i = 0; i < dashCount; i++) {
      const dashGeo  = new THREE.PlaneGeometry(4, 0.25);
      const dashMesh = new THREE.Mesh(dashGeo, mat.roadMark);
      dashMesh.rotation.x = -Math.PI / 2;
      const offset = -length / 2 + 6 + i * 12;
      dashMesh.position.set(
        horizontal ? x + offset : x,
        0.03,
        horizontal ? z : z + offset
      );
      NeonScene.add(dashMesh);
    }
  }

  // ── Hills ─────────────────────────────────────────────────────────────────
  function buildHill(x, z, radius, height, mat) {
    const geo = new THREE.ConeGeometry(radius, height, 8);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, height / 2, z);
    mesh.castShadow    = true;
    mesh.receiveShadow = true;
    NeonScene.add(mesh);
    return mesh;
  }

  // ── Water plane ───────────────────────────────────────────────────────────
  let waterMesh = null;

  function buildWater(mat) {
    const geo  = new THREE.PlaneGeometry(250, 200, 1, 1);
    waterMesh  = new THREE.Mesh(geo, mat.water);
    waterMesh.rotation.x  = -Math.PI / 2;
    waterMesh.position.set(0, -0.5, 280);   // south zone
    waterMesh.receiveShadow = false;
    waterMesh.name = 'water';
    NeonScene.add(waterMesh);

    // Add neon underwater glow
    NeonLighting.addNeonLight(0, -1, 280, 0x003399, 3, 80);
  }

  // ── Water animation ───────────────────────────────────────────────────────
  function animateWater(delta, now) {
    if (!waterMesh) return;
    // Gentle vertical bob
    waterMesh.position.y = -0.5 + Math.sin(now * 0.0008) * 0.12;
    // Slight pulse on emissive
    waterMesh.material.emissiveIntensity = 0.25 + Math.sin(now * 0.001) * 0.12;
  }

  // ── Main build ────────────────────────────────────────────────────────────
  function build() {
    const mat = buildMaterials();

    // 1. Base ground
    buildGround(mat);

    // 2. Zone patches — layered on top of the base
    // Farm (north, green)
    buildZonePatch(mat.grass,  0x1a3a1a, 0,    -280, 350, 200);
    // Beach (south)
    buildZonePatch(mat.sand,   0x2a2010, 0,     280, 350, 100);
    // Industrial west (soil)
    buildZonePatch(mat.soil,   0x2a1a0a, -280,   0,  200, 400);
    // Hills east
    buildZonePatch(mat.rock,   0x1a1520,  280,   0,  200, 400);

    // 3. Main roads — neon city grid
    // N-S highway
    buildRoad(mat,   0, 0, 600, 14, false);
    // E-W highway
    buildRoad(mat,   0, 0, 600, 14, true);
    // Ring road (4 segments)
    buildRoad(mat,   0, -120, 300, 10, true);
    buildRoad(mat,   0,  120, 300, 10, true);
    buildRoad(mat, -120,   0, 240, 10, false);
    buildRoad(mat,  120,   0, 240, 10, false);
    // Farm road (north)
    buildRoad(mat,  0, -180, 120, 6, true);
    // Beach road (south)
    buildRoad(mat,  0,  200, 120, 6, true);

    // 4. Hills (east zone)
    buildHill( 300,  -60,  40, 55, mat.rock);
    buildHill( 340,   40,  30, 40, mat.rock);
    buildHill( 260,   10,  50, 65, mat.rock);
    buildHill( 320,  -130, 35, 48, mat.rock);
    buildHill( 380,   80,  25, 35, mat.rock);
    // Smaller rocks
    buildHill( 250,  -90,  18, 22, mat.rock);
    buildHill( 290,   90,  15, 20, mat.rock);

    // 5. Water (south)
    buildWater(mat);

    // 6. Register water animation
    NeonScene.onUpdate((delta, now) => animateWater(delta, now));

    console.log('✅ Terrain built');
  }

  return { build };
})();

window.NeonTerrain = NeonTerrain;
