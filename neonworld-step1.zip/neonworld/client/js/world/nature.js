/**
 * NEON WORLD — NATURE
 * Trees, bushes, farm crops, and animals (cows, goats).
 * All built from primitive geometry — no external models needed.
 * Animals have a basic wander AI updated each frame.
 */

const NeonNature = (() => {

  const animals = [];   // { mesh, zone, speed, dir, wanderTimer }

  // ── Materials ──────────────────────────────────────────────────────────────
  const MAT = {
    trunkDark:  new THREE.MeshLambertMaterial({ color: 0x1a0e05 }),
    leaf:       new THREE.MeshLambertMaterial({ color: 0x0d2210 }),
    leafNeon:   new THREE.MeshLambertMaterial({ color: 0x003322, emissive: 0x001a0e, emissiveIntensity: 0.3 }),
    crop:       new THREE.MeshLambertMaterial({ color: 0x1a2a08 }),
    cowBody:    new THREE.MeshLambertMaterial({ color: 0x222222 }),
    cowSpot:    new THREE.MeshLambertMaterial({ color: 0xdddddd }),
    goatBody:   new THREE.MeshLambertMaterial({ color: 0xbbaa99 }),
    horn:       new THREE.MeshLambertMaterial({ color: 0xccbb88 }),
  };

  // ── Tree ─────────────────────────────────────────────────────────────────
  function makeTree(x, z, scale = 1, neon = false) {
    const group = new THREE.Group();
    const leafMat = neon ? MAT.leafNeon : MAT.leaf;

    // Trunk
    const trGeo  = new THREE.CylinderGeometry(0.3 * scale, 0.5 * scale, 4 * scale, 6);
    const trMesh = new THREE.Mesh(trGeo, MAT.trunkDark);
    trMesh.position.y = 2 * scale;
    trMesh.castShadow = true;
    group.add(trMesh);

    // Canopy (three stacked cones)
    [[6, 5, 4], [5, 4.5, 6.5], [4, 3.5, 8.5]].forEach(([r, h, y]) => {
      const cGeo  = new THREE.ConeGeometry(r * scale, h * scale, 7);
      const cMesh = new THREE.Mesh(cGeo, leafMat);
      cMesh.position.y = y * scale;
      cMesh.castShadow = true;
      group.add(cMesh);
    });

    if (neon) {
      NeonLighting.addNeonLight(x, 5 * scale, z, 0x00ff88, 1.5, 12);
    }

    group.position.set(x, 0, z);
    NeonScene.add(group);
    return group;
  }

  // ── Bush ──────────────────────────────────────────────────────────────────
  function makeBush(x, z) {
    const geo  = new THREE.SphereGeometry(1.5 + Math.random(), 5, 4);
    const mesh = new THREE.Mesh(geo, MAT.leaf);
    mesh.position.set(x, 1, z);
    mesh.castShadow = true;
    NeonScene.add(mesh);
  }

  // ── Farm crops (rows) ─────────────────────────────────────────────────────
  function makeCropRow(startX, z, count = 6) {
    for (let i = 0; i < count; i++) {
      const x   = startX + i * 3;
      const geo  = new THREE.ConeGeometry(0.5, 2, 4);
      const mesh = new THREE.Mesh(geo, MAT.crop);
      mesh.position.set(x, 1, z);
      NeonScene.add(mesh);
    }
  }

  // ── Cow ───────────────────────────────────────────────────────────────────
  function makeCow(x, z) {
    const group = new THREE.Group();

    // Body
    const bGeo  = new THREE.BoxGeometry(3, 2, 1.5);
    const bMesh = new THREE.Mesh(bGeo, MAT.cowBody);
    bMesh.position.y = 1.8;
    bMesh.castShadow = true;
    group.add(bMesh);

    // White spot
    const sGeo  = new THREE.BoxGeometry(1, 0.8, 1.6);
    const sMesh = new THREE.Mesh(sGeo, MAT.cowSpot);
    sMesh.position.set(0.4, 2.2, 0);
    group.add(sMesh);

    // Head
    const hGeo  = new THREE.BoxGeometry(1.2, 1.2, 1.2);
    const hMesh = new THREE.Mesh(hGeo, MAT.cowBody);
    hMesh.position.set(1.8, 2.4, 0);
    hMesh.castShadow = true;
    group.add(hMesh);

    // Legs (4)
    [[-0.8, -1], [-0.8, 1], [0.8, -1], [0.8, 1]].forEach(([lx, lz]) => {
      const lGeo  = new THREE.BoxGeometry(0.4, 1.6, 0.4);
      const lMesh = new THREE.Mesh(lGeo, MAT.cowBody);
      lMesh.position.set(lx, 0.8, lz);
      group.add(lMesh);
    });

    // Ears
    [-0.5, 0.5].forEach(ez => {
      const eGeo  = new THREE.BoxGeometry(0.1, 0.5, 0.5);
      const eMesh = new THREE.Mesh(eGeo, MAT.cowSpot);
      eMesh.position.set(1.8, 3, ez);
      group.add(eMesh);
    });

    group.position.set(x, 0, z);
    NeonScene.add(group);

    animals.push({
      mesh: group,
      speed: 0.5 + Math.random() * 0.5,
      dir: Math.random() * Math.PI * 2,
      wanderTimer: Math.random() * 3,
      zone: { minX: x - 30, maxX: x + 30, minZ: z - 30, maxZ: z + 30 }
    });

    return group;
  }

  // ── Goat ──────────────────────────────────────────────────────────────────
  function makeGoat(x, z) {
    const group = new THREE.Group();

    // Body
    const bGeo  = new THREE.BoxGeometry(2, 1.5, 1);
    const bMesh = new THREE.Mesh(bGeo, MAT.goatBody);
    bMesh.position.y = 1.5;
    bMesh.castShadow = true;
    group.add(bMesh);

    // Head
    const hGeo  = new THREE.BoxGeometry(0.9, 0.9, 0.9);
    const hMesh = new THREE.Mesh(hGeo, MAT.goatBody);
    hMesh.position.set(1.2, 2.0, 0);
    group.add(hMesh);

    // Horns
    [-0.3, 0.3].forEach(hz => {
      const hornGeo  = new THREE.ConeGeometry(0.1, 0.7, 4);
      const hornMesh = new THREE.Mesh(hornGeo, MAT.horn);
      hornMesh.position.set(1.1, 2.7, hz);
      hornMesh.rotation.z = 0.2 * (hz > 0 ? 1 : -1);
      group.add(hornMesh);
    });

    // Legs (4)
    [[-0.5, -0.3], [-0.5, 0.3], [0.5, -0.3], [0.5, 0.3]].forEach(([lx, lz]) => {
      const lGeo  = new THREE.BoxGeometry(0.3, 1.2, 0.3);
      const lMesh = new THREE.Mesh(lGeo, MAT.goatBody);
      lMesh.position.set(lx, 0.6, lz);
      group.add(lMesh);
    });

    group.position.set(x, 0, z);
    NeonScene.add(group);

    animals.push({
      mesh: group,
      speed: 0.8 + Math.random() * 0.8,
      dir: Math.random() * Math.PI * 2,
      wanderTimer: Math.random() * 2,
      zone: { minX: x - 25, maxX: x + 25, minZ: z - 25, maxZ: z + 25 }
    });

    return group;
  }

  // ── Per-frame animal wander AI ─────────────────────────────────────────────
  function updateAnimals(delta) {
    for (const a of animals) {
      a.wanderTimer -= delta;

      if (a.wanderTimer <= 0) {
        // Pick a new random direction
        a.dir = Math.random() * Math.PI * 2;
        a.wanderTimer = 1.5 + Math.random() * 3;
      }

      // Move
      const nx = a.mesh.position.x + Math.sin(a.dir) * a.speed * delta;
      const nz = a.mesh.position.z + Math.cos(a.dir) * a.speed * delta;

      // Keep inside zone
      if (nx > a.zone.minX && nx < a.zone.maxX &&
          nz > a.zone.minZ && nz < a.zone.maxZ) {
        a.mesh.position.x = nx;
        a.mesh.position.z = nz;
        a.mesh.rotation.y = -a.dir;
      } else {
        // Hit boundary — turn around
        a.dir += Math.PI + (Math.random() - 0.5) * 0.8;
      }
    }
  }

  // ── Main build ────────────────────────────────────────────────────────────
  function build() {
    // Trees — east hills
    for (let i = 0; i < 30; i++) {
      makeTree(
        220 + Math.random() * 140,
        -150 + Math.random() * 300,
        0.8 + Math.random() * 0.6,
        Math.random() < 0.1   // 10% neon trees
      );
    }

    // Trees — west zone
    for (let i = 0; i < 20; i++) {
      makeTree(-220 - Math.random() * 100, -150 + Math.random() * 300, 0.7 + Math.random() * 0.5);
    }

    // Trees — farm north edges
    for (let i = 0; i < 15; i++) {
      makeTree(-160 + Math.random() * 320, -340 + Math.random() * 60, 0.8 + Math.random() * 0.4);
    }

    // Bushes near farms
    for (let i = 0; i < 40; i++) {
      makeBush(
        -120 + Math.random() * 240,
        -160 + Math.random() * 100
      );
    }

    // Farm crop rows
    for (let row = 0; row < 6; row++) {
      makeCropRow(-100 + row * 6, -240, 8);
      makeCropRow(-60  + row * 6, -260, 6);
    }

    // Cows — farm zone
    makeCow(-90, -240);
    makeCow(-60, -250);
    makeCow(-110,-220);
    makeCow(-40, -235);
    makeCow(-80, -260);

    // Goats — farm and hills
    makeGoat(-50,  -230);
    makeGoat(-120, -215);
    makeGoat( 220, -40 );
    makeGoat( 260,  30 );
    makeGoat( 240,  80 );

    // Register animal AI
    NeonScene.onUpdate(delta => updateAnimals(delta));

    console.log('✅ Nature built — trees, farms, cows, goats');
  }

  return { build };
})();

window.NeonNature = NeonNature;
