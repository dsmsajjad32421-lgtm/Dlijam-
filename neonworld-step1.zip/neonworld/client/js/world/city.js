/**
 * NEON WORLD — CITY
 * Builds the neon city: skyscrapers, mid-rise blocks, shops,
 * neon signs, and atmospheric lighting.
 * Everything is procedural geometry — no external models needed.
 */

const NeonCity = (() => {

  // Sign text labels (purely decorative geometry boxes)
  const SIGN_COLORS = [0xff2d78, 0x00d4ff, 0xbf00ff, 0x00ff88, 0xffe600, 0xff6a00];

  // ── Emissive neon material ─────────────────────────────────────────────────
  function neonMat(color) {
    return new THREE.MeshLambertMaterial({
      color,
      emissive: color,
      emissiveIntensity: 1.2
    });
  }

  // ── Dark building material ─────────────────────────────────────────────────
  function buildingMat(shade = 0x0a0a1e) {
    return new THREE.MeshLambertMaterial({ color: shade });
  }

  // ── Window strip material ──────────────────────────────────────────────────
  function windowMat(color = 0x1a3366) {
    return new THREE.MeshLambertMaterial({
      color,
      emissive: color,
      emissiveIntensity: 0.5
    });
  }

  // ── Single building ───────────────────────────────────────────────────────
  function makeBuilding(x, z, w, d, h, accentColor) {
    const group = new THREE.Group();

    // Main body
    const bodyGeo  = new THREE.BoxGeometry(w, h, d);
    const bodyMesh = new THREE.Mesh(bodyGeo, buildingMat());
    bodyMesh.position.y = h / 2;
    bodyMesh.castShadow    = true;
    bodyMesh.receiveShadow = true;
    group.add(bodyMesh);

    // Window rows (thin emissive strips on each face)
    const windowH   = 0.8;
    const windowGap = 3;
    const floors    = Math.floor(h / windowGap);

    for (let f = 1; f < floors; f++) {
      const y = f * windowGap;

      // Front + back windows
      [z + d / 2 + 0.01, z - d / 2 - 0.01].forEach((wz, i) => {
        const wGeo  = new THREE.PlaneGeometry(w - 1, windowH);
        const wMesh = new THREE.Mesh(wGeo, windowMat(accentColor));
        wMesh.position.set(0, y, wz - z);
        if (i === 1) wMesh.rotation.y = Math.PI;
        group.add(wMesh);
      });

      // Side windows
      [x + w / 2 + 0.01, x - w / 2 - 0.01].forEach((wx, i) => {
        const wGeo  = new THREE.PlaneGeometry(d - 1, windowH);
        const wMesh = new THREE.Mesh(wGeo, windowMat(accentColor));
        wMesh.position.set(wx - x, y, 0);
        wMesh.rotation.y = Math.PI / 2 * (i === 0 ? 1 : -1);
        group.add(wMesh);
      });
    }

    // Rooftop neon trim
    const rimGeo  = new THREE.BoxGeometry(w + 0.3, 0.3, d + 0.3);
    const rimMesh = new THREE.Mesh(rimGeo, neonMat(accentColor));
    rimMesh.position.y = h + 0.15;
    group.add(rimMesh);

    // Neon sign on front face (coloured box stand-in)
    const signColor = SIGN_COLORS[Math.floor(Math.random() * SIGN_COLORS.length)];
    const signGeo   = new THREE.BoxGeometry(w * 0.6, 1.5, 0.25);
    const signMesh  = new THREE.Mesh(signGeo, neonMat(signColor));
    signMesh.position.set(0, h * 0.6, d / 2 + 0.2);
    group.add(signMesh);

    // Point light from the sign
    NeonLighting.addNeonLight(x, h * 0.6, z + d / 2 + 2, signColor, 2.5, 25);

    group.position.set(x, 0, z);
    NeonScene.add(group);
    return group;
  }

  // ── Shop / low-rise block ─────────────────────────────────────────────────
  function makeShop(x, z, color) {
    const w = 8 + Math.random() * 4;
    const d = 7 + Math.random() * 3;
    const h = 5 + Math.random() * 4;

    const group = new THREE.Group();
    const bodyGeo  = new THREE.BoxGeometry(w, h, d);
    const bodyMesh = new THREE.Mesh(bodyGeo, buildingMat(0x0c0c20));
    bodyMesh.position.y   = h / 2;
    bodyMesh.castShadow    = true;
    bodyMesh.receiveShadow = true;
    group.add(bodyMesh);

    // Neon awning
    const awningGeo  = new THREE.BoxGeometry(w + 1, 0.2, 2.5);
    const awningMesh = new THREE.Mesh(awningGeo, neonMat(color));
    awningMesh.position.set(0, 3.5, d / 2 + 1);
    group.add(awningMesh);

    NeonLighting.addNeonLight(x, 4, z + d / 2 + 2, color, 2, 18);

    group.position.set(x, 0, z);
    NeonScene.add(group);
  }

  // ── House (for residential / farm area) ───────────────────────────────────
  function makeHouse(x, z) {
    const group = new THREE.Group();

    // Body
    const bodyGeo  = new THREE.BoxGeometry(10, 5, 8);
    const bodyMesh = new THREE.Mesh(bodyGeo, buildingMat(0x0e0e1a));
    bodyMesh.position.y   = 2.5;
    bodyMesh.castShadow    = true;
    bodyMesh.receiveShadow = true;
    group.add(bodyMesh);

    // Roof
    const roofGeo  = new THREE.ConeGeometry(7.5, 3.5, 4);
    const roofMesh = new THREE.Mesh(roofGeo, buildingMat(0x150015));
    roofMesh.position.y = 5 + 1.75;
    roofMesh.rotation.y = Math.PI / 4;
    group.add(roofMesh);

    // Door
    const doorGeo  = new THREE.BoxGeometry(1.5, 2.8, 0.2);
    const doorMesh = new THREE.Mesh(doorGeo, new THREE.MeshLambertMaterial({ color: 0x1a0a00 }));
    doorMesh.position.set(0, 1.4, 4.1);
    group.add(doorMesh);

    // Window glow
    const wGeo  = new THREE.BoxGeometry(2, 1.5, 0.1);
    const wMesh = new THREE.Mesh(wGeo, windowMat(0x112244));
    wMesh.position.set(3, 3, 4.1);
    group.add(wMesh);

    group.position.set(x, 0, z);
    NeonScene.add(group);
  }

  // ── Street lamp ───────────────────────────────────────────────────────────
  function makeLamp(x, z, color = 0x00d4ff) {
    const group = new THREE.Group();

    // Pole
    const poleGeo  = new THREE.CylinderGeometry(0.1, 0.1, 8, 6);
    const poleMesh = new THREE.Mesh(poleGeo,
      new THREE.MeshLambertMaterial({ color: 0x111122 }));
    poleMesh.position.y = 4;
    group.add(poleMesh);

    // Head
    const headGeo  = new THREE.SphereGeometry(0.5, 6, 6);
    const headMesh = new THREE.Mesh(headGeo, neonMat(color));
    headMesh.position.y = 8.5;
    group.add(headMesh);

    NeonLighting.addNeonLight(x, 8, z, color, 2, 20);

    group.position.set(x, 0, z);
    NeonScene.add(group);
  }

  // ── Main build ────────────────────────────────────────────────────────────
  function build() {
    // === SKYSCRAPERS — city core ===
    const towers = [
      { x:  30, z:  30, w: 16, d: 14, h: 90,  c: 0xff2d78 },
      { x: -40, z:  20, w: 14, d: 12, h: 110, c: 0x00d4ff },
      { x:  60, z: -30, w: 18, d: 16, h: 75,  c: 0xbf00ff },
      { x: -60, z: -40, w: 20, d: 18, h: 130, c: 0x00ff88 },
      { x:  20, z: -60, w: 12, d: 12, h: 60,  c: 0xffe600 },
      { x: -20, z:  60, w: 14, d: 14, h: 85,  c: 0xff6a00 },
      { x:  80, z:  50, w: 16, d: 12, h: 95,  c: 0x00d4ff },
      { x: -80, z:  40, w: 14, d: 16, h: 70,  c: 0xff2d78 },
      { x:  50, z:  80, w: 12, d: 10, h: 55,  c: 0xbf00ff },
      { x: -50, z: -70, w: 18, d: 14, h: 100, c: 0x00ff88 },
    ];
    towers.forEach(t => makeBuilding(t.x, t.z, t.w, t.d, t.h, t.c));

    // === MID-RISE BLOCKS — surrounding the core ===
    const midrise = [
      { x:  110, z:  20 }, { x: -110, z:  30 }, { x:  100, z: -50 },
      { x:  -90, z: -60 }, { x:   40, z: 110 }, { x:  -50, z: 100 },
      { x:   70, z: -90 }, { x:  -70, z: -80 },
    ];
    midrise.forEach((b, i) => makeBuilding(
      b.x, b.z,
      10 + (i % 3) * 3,
      8  + (i % 2) * 2,
      25 + i * 3,
      SIGN_COLORS[i % SIGN_COLORS.length]
    ));

    // === SHOPS — street level along roads ===
    const shopPositions = [
      [20, -18, 0xff2d78], [-20, -18, 0x00d4ff],
      [20,  18, 0xbf00ff], [-20,  18, 0x00ff88],
      [18,  -5, 0xffe600], [-18,  -5, 0xff6a00],
      [18,   5, 0xff2d78], [-18,   5, 0x00d4ff],
    ];
    shopPositions.forEach(([x, z, c]) => makeShop(x, z, c));

    // === HOUSES — north/farm zone ===
    const housePositions = [
      [-80, -200], [-50, -220], [-20, -200], [10, -215],
      [40,  -200], [70, -220],  [100, -200],
    ];
    housePositions.forEach(([x, z]) => makeHouse(x, z));

    // === STREET LAMPS — along main roads ===
    const lampColors = [0xff2d78, 0x00d4ff, 0xbf00ff, 0x00ff88];
    for (let i = -200; i <= 200; i += 30) {
      makeLamp( 8, i, lampColors[Math.abs(Math.floor(i / 30)) % lampColors.length]);
      makeLamp(-8, i, lampColors[(Math.abs(Math.floor(i / 30)) + 2) % lampColors.length]);
    }
    for (let i = -200; i <= 200; i += 30) {
      makeLamp(i,  8, lampColors[Math.abs(Math.floor(i / 30)) % lampColors.length]);
      makeLamp(i, -8, lampColors[(Math.abs(Math.floor(i / 30)) + 1) % lampColors.length]);
    }

    console.log('✅ Neon city built');
  }

  return { build };
})();

window.NeonCity = NeonCity;
