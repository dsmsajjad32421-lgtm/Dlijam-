/**
 * NEON WORLD — WEATHER
 * Rain particles, dynamic fog density, and weather state machine.
 * States: clear → cloudy → rain → storm → clear
 */

const NeonWeather = (() => {

  let state        = 'clear';    // clear | cloudy | rain | storm
  let stateTimer   = 60;         // seconds until next weather change
  let rainSystem   = null;
  let rainEnabled  = true;

  const MAX_RAIN_DROPS = 800;

  // ── Rain particle system ──────────────────────────────────────────────────
  function createRainSystem() {
    const positions = new Float32Array(MAX_RAIN_DROPS * 3);

    for (let i = 0; i < MAX_RAIN_DROPS; i++) {
      positions[i * 3]     = (Math.random() - 0.5) * 200; // x
      positions[i * 3 + 1] = Math.random() * 60;          // y
      positions[i * 3 + 2] = (Math.random() - 0.5) * 200; // z
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const mat = new THREE.PointsMaterial({
      color:       0x4488cc,
      size:        0.15,
      transparent: true,
      opacity:     0.6,
      depthWrite:  false
    });

    const points = new THREE.Points(geo, mat);
    points.name  = 'rain';
    points.visible = false;
    NeonScene.add(points);
    return points;
  }

  // ── Animate rain ──────────────────────────────────────────────────────────
  function animateRain(delta, intensity = 1) {
    if (!rainSystem || !rainSystem.visible) return;

    const pos   = rainSystem.geometry.attributes.position;
    const speed = 25 * intensity;

    for (let i = 0; i < MAX_RAIN_DROPS; i++) {
      pos.array[i * 3 + 1] -= speed * delta;

      // Reset drop to top when it hits the ground
      if (pos.array[i * 3 + 1] < 0) {
        pos.array[i * 3]     = (Math.random() - 0.5) * 200;
        pos.array[i * 3 + 1] = 55 + Math.random() * 10;
        pos.array[i * 3 + 2] = (Math.random() - 0.5) * 200;
      }
    }
    pos.needsUpdate = true;

    // Follow camera roughly so rain always surrounds the player
    if (NeonCamera.getCamera()) {
      const cam = NeonCamera.getCamera();
      rainSystem.position.x = cam.position.x;
      rainSystem.position.z = cam.position.z;
    }
  }

  // ── Set weather state ─────────────────────────────────────────────────────
  function setState(newState) {
    state = newState;
    const fog = NeonScene.get().fog;

    switch (state) {
      case 'clear':
        if (rainSystem) rainSystem.visible = false;
        if (fog) fog.density = NeonRenderer.getQualityCfg().fogDensity;
        break;

      case 'cloudy':
        if (rainSystem) rainSystem.visible = false;
        if (fog) fog.density = NeonRenderer.getQualityCfg().fogDensity * 1.8;
        break;

      case 'rain':
        if (rainSystem) {
          rainSystem.visible = true;
          rainSystem.material.opacity = 0.5;
        }
        if (fog) fog.density = NeonRenderer.getQualityCfg().fogDensity * 2.5;
        break;

      case 'storm':
        if (rainSystem) {
          rainSystem.visible = true;
          rainSystem.material.opacity = 0.8;
        }
        if (fog) fog.density = NeonRenderer.getQualityCfg().fogDensity * 4;
        break;
    }

    console.log(`🌦️ Weather → ${state}`);
  }

  // ── Weather state machine ─────────────────────────────────────────────────
  const TRANSITIONS = {
    clear:  ['clear', 'clear', 'cloudy'],
    cloudy: ['clear', 'cloudy', 'rain'],
    rain:   ['cloudy', 'rain', 'storm'],
    storm:  ['rain', 'rain', 'clear']
  };

  function advanceWeather() {
    const options = TRANSITIONS[state];
    const next    = options[Math.floor(Math.random() * options.length)];
    setState(next);
    // Next change in 30–120 seconds (in-game)
    stateTimer = 30 + Math.random() * 90;
  }

  // ── Per-frame update ──────────────────────────────────────────────────────
  function update(delta) {
    if (!rainEnabled) return;

    stateTimer -= delta;
    if (stateTimer <= 0) advanceWeather();

    const intensity = state === 'storm' ? 2 : 1;
    animateRain(delta, intensity);
  }

  // ── Initialise ────────────────────────────────────────────────────────────
  function init() {
    rainSystem = createRainSystem();
    NeonScene.onUpdate(update);
    // Start with clear weather
    setState('clear');
    stateTimer = 60;
    console.log('✅ Weather system initialised');
  }

  const getState      = () => state;
  const setRainEnabled = (v) => {
    rainEnabled = v;
    if (!v && rainSystem) rainSystem.visible = false;
  };

  return { init, setState, getState, setRainEnabled };
})();

window.NeonWeather = NeonWeather;
