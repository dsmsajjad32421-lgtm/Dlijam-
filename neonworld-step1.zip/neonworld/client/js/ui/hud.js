/**
 * NEON WORLD — HUD
 * Updates the top HUD elements from player state.
 * Called by main.js after API data loads.
 */

const NeonHUD = (() => {

  // ── DOM refs ───────────────────────────────────────────────────────────────
  const els = {};

  function init() {
    els.username  = document.getElementById('hud-username');
    els.level     = document.getElementById('hud-level');
    els.xpFill    = document.getElementById('hud-xp-fill');
    els.coins     = document.getElementById('hud-coins');
    els.score     = document.getElementById('hud-score');
    els.zoneName  = document.getElementById('hud-zone-name');
    els.ui        = document.getElementById('game-ui');

    // Announcement banner
    const closeBtn = document.getElementById('announcement-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', hideAnnouncement);
    }

    // Bottom buttons
    document.getElementById('btn-inventory')?.addEventListener('click',
      () => NeonMenu.open('inventory'));
    document.getElementById('btn-missions')?.addEventListener('click',
      () => NeonMenu.open('missions'));
    document.getElementById('btn-leaderboard')?.addEventListener('click',
      () => NeonMenu.open('leaderboard'));
    document.getElementById('btn-settings')?.addEventListener('click',
      () => NeonMenu.open('settings'));
    document.getElementById('btn-social')?.addEventListener('click',
      () => NeonMenu.open('social'));

    // Chat button
    document.getElementById('btn-chat')?.addEventListener('click', toggleChat);
    document.getElementById('chat-send')?.addEventListener('click', sendChat);
    const chatInput = document.getElementById('chat-input');
    chatInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') sendChat();
    });

    // Socket chat listener
    NeonSocket.on('chat_message', addChatMessage);

    console.log('✅ HUD initialised');
  }

  // ── Update all HUD fields from a profile object ────────────────────────────
  function update(profile) {
    if (!profile) return;

    if (els.username) els.username.textContent = profile.display_name || profile.username || 'Player';
    if (els.level)    els.level.textContent    = profile.level || 1;
    if (els.coins)    els.coins.textContent    = formatNumber(profile.coins || 0);
    if (els.score)    els.score.textContent    = formatNumber(profile.score || 0);

    // XP bar
    if (els.xpFill) {
      const pct = profile.xp_to_next_level > 0
        ? Math.min(100, (profile.current_level_xp / profile.xp_to_next_level) * 100)
        : 0;
      els.xpFill.style.width = pct + '%';
    }
  }

  // ── Animate a coin change (flash the coin count) ──────────────────────────
  function animateCoins(newTotal, gained) {
    if (els.coins) {
      els.coins.textContent = formatNumber(newTotal);
      els.coins.style.color = gained > 0 ? 'var(--neon-green)' : 'var(--neon-pink)';
      setTimeout(() => { els.coins.style.color = ''; }, 800);
    }
  }

  // ── Zone name ─────────────────────────────────────────────────────────────
  function setZone(name) {
    if (els.zoneName) els.zoneName.textContent = name;
  }

  // ── Show / hide the game UI ───────────────────────────────────────────────
  function show() {
    if (els.ui) {
      els.ui.classList.remove('hidden');
      document.getElementById('btn-chat')?.classList.remove('hidden');
    }
  }

  function hide() {
    if (els.ui) els.ui.classList.add('hidden');
  }

  // ── Announcement banner ───────────────────────────────────────────────────
  function showAnnouncement(text) {
    const banner = document.getElementById('announcement-banner');
    const textEl = document.getElementById('announcement-text');
    if (banner && textEl) {
      textEl.textContent = text;
      banner.classList.remove('hidden');
      // Auto-hide after 8 seconds
      setTimeout(hideAnnouncement, 8000);
    }
  }

  function hideAnnouncement() {
    document.getElementById('announcement-banner')?.classList.add('hidden');
  }

  // ── Floating damage / reward text ─────────────────────────────────────────
  function floatText(text, color = '#00ff88', x, y) {
    const el = document.createElement('div');
    el.textContent = text;
    el.style.cssText = `
      position:fixed;
      left:${x || 50}%;
      top:${y || 45}%;
      transform:translate(-50%,-50%);
      color:${color};
      font-family:var(--font-display);
      font-size:1.4rem;
      font-weight:700;
      text-shadow:0 0 12px ${color};
      pointer-events:none;
      z-index:300;
      animation:float-up 1.2s ease forwards;
    `;
    document.body.appendChild(el);

    // Inline keyframe — simpler than adding a stylesheet
    el.animate([
      { opacity: 1, transform: 'translate(-50%,-50%)' },
      { opacity: 0, transform: 'translate(-50%,-200%)' }
    ], { duration: 1200, easing: 'ease-out' }).onfinish = () => el.remove();
  }

  // ── Chat ──────────────────────────────────────────────────────────────────
  function toggleChat() {
    const box = document.getElementById('chat-box');
    box?.classList.toggle('hidden');
  }

  function sendChat() {
    const input = document.getElementById('chat-input');
    if (!input || !input.value.trim()) return;
    NeonSocket.sendChat(input.value.trim());
    input.value = '';
  }

  function addChatMessage({ username, message }) {
    const msgs = document.getElementById('chat-messages');
    if (!msgs) return;

    const line = document.createElement('div');
    line.className = 'chat-line';
    line.innerHTML = `<span class="chat-user">${escapeHTML(username)}:</span> ${escapeHTML(message)}`;
    msgs.appendChild(line);
    msgs.scrollTop = msgs.scrollHeight;

    // Keep only last 50 messages
    while (msgs.children.length > 50) msgs.removeChild(msgs.firstChild);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  function formatNumber(n) {
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
    if (n >= 1_000)     return (n / 1_000).toFixed(1) + 'K';
    return String(n);
  }

  function escapeHTML(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  return {
    init,
    update,
    animateCoins,
    setZone,
    show,
    hide,
    showAnnouncement,
    floatText
  };
})();

window.NeonHUD = NeonHUD;
