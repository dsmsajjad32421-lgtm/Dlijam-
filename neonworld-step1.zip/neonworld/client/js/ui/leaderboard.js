/**
 * NEON WORLD — LEADERBOARD UI
 * Standalone leaderboard that can also be embedded in the menu.
 */

const NeonLeaderboard = (() => {

  async function fetch(period = 'all_time', page = 1) {
    return await NeonAPI.getLeaderboard(period, page);
  }

  return { fetch };
})();

window.NeonLeaderboard = NeonLeaderboard;
