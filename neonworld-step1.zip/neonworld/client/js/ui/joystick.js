/**
 * NEON WORLD — VIRTUAL JOYSTICK
 * Touch-based joystick for mobile movement.
 * Outputs normalised X/Y values (-1 to 1) to NeonMovement.
 */

const NeonJoystick = (() => {

  let base     = null;
  let knob     = null;
  let zone     = null;
  let active   = false;
  let touchId  = null;

  const MAX_RADIUS = 38; // pixels from centre

  function init() {
    base = document.getElementById('joystick-base');
    knob = document.getElementById('joystick-knob');
    zone = document.getElementById('joystick-zone');

    if (!base || !knob) {
      console.warn('Joystick elements not found');
      return;
    }

    zone.addEventListener('touchstart',  onStart, { passive: false });
    zone.addEventListener('touchmove',   onMove,  { passive: false });
    zone.addEventListener('touchend',    onEnd,   { passive: false });
    zone.addEventListener('touchcancel', onEnd,   { passive: false });

    console.log('✅ Joystick initialised');
  }

  function onStart(e) {
    e.preventDefault();
    if (active) return;

    const t  = e.changedTouches[0];
    touchId  = t.identifier;
    active   = true;
    base.classList.add('active');

    processTouch(t);
  }

  function onMove(e) {
    e.preventDefault();
    for (const t of e.changedTouches) {
      if (t.identifier === touchId) { processTouch(t); break; }
    }
  }

  function onEnd(e) {
    for (const t of e.changedTouches) {
      if (t.identifier === touchId) {
        active  = false;
        touchId = null;
        base.classList.remove('active');

        // Reset knob to centre
        knob.style.transform = 'translate(-50%, -50%)';
        NeonMovement.setJoystick(0, 0);
        break;
      }
    }
  }

  function processTouch(t) {
    const rect = base.getBoundingClientRect();
    const cx   = rect.left + rect.width  / 2;
    const cy   = rect.top  + rect.height / 2;

    let dx = t.clientX - cx;
    let dy = t.clientY - cy;

    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > MAX_RADIUS) {
      dx = dx / dist * MAX_RADIUS;
      dy = dy / dist * MAX_RADIUS;
    }

    // Move the knob visually
    knob.style.transform =
      `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;

    // Normalise to -1 / 1 and send to movement
    NeonMovement.setJoystick(
      dx / MAX_RADIUS,
      dy / MAX_RADIUS
    );
  }

  return { init };
})();

window.NeonJoystick = NeonJoystick;
