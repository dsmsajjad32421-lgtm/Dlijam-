/**
 * NEON WORLD — MENU SYSTEM
 * All in-game modal menus: inventory, missions, character select,
 * clothing, settings, social.
 */

const NeonMenu = (() => {

  let currentMenu = null;

  // ── Open a menu ────────────────────────────────────────────────────────────
  async function open(menuName) {
    currentMenu = menuName;
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modal-content');
    overlay.classList.remove('hidden');

    switch (menuName) {
      case 'inventory':  await renderInventory(content);  break;
      case 'missions':   await renderMissions(content);   break;
      case 'leaderboard': await renderLeaderboard(content); break;
      case 'settings':   renderSettings(content);         break;
      case 'social':     renderSocial(content);           break;
      case 'characters': await renderCharacters(content); break;
      case 'clothing':   await renderClothing(content);   break;
      default:           content.innerHTML = '<p style="color:#fff">Menu coming soon.</p>';
    }

    document.getElementById('modal-close')
      .onclick = close;
    overlay.onclick = (e) => { if (e.target === overlay) close(); };
  }

  function close() {
    document.getElementById('modal-overlay').classList.add('hidden');
    currentMenu = null;
  }

  // ── Section header helper ─────────────────────────────────────────────────
  function header(title, subtitle = '') {
    return `
      <div style="margin-bottom:20px;border-bottom:1px solid rgba(0,212,255,0.2);padding-bottom:12px">
        <h2 style="font-family:var(--font-display);font-size:1.1rem;color:var(--neon-blue);letter-spacing:3px">${title}</h2>
        ${subtitle ? `<p style="font-family:var(--font-body);color:rgba(255,255,255,0.5);font-size:0.8rem;margin-top:4px">${subtitle}</p>` : ''}
      </div>
    `;
  }

  // ── Card grid helper ──────────────────────────────────────────────────────
  function cardGrid(items, renderItem) {
    return `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px">
      ${items.map(renderItem).join('')}
    </div>`;
  }

  // ── INVENTORY ────────────────────────────────────────────────────────────
  async function renderInventory(el) {
    el.innerHTML = header('🎒 Inventory', 'Your items and equipment') +
      `<div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">
        <button class="tab-btn active-tab" onclick="NeonMenu.switchTab('characters','inv')">Characters</button>
        <button class="tab-btn" onclick="NeonMenu.switchTab('clothing','inv')">Clothing</button>
        <button class="tab-btn" onclick="NeonMenu.switchTab('items','inv')">Items</button>
      </div>
      <div id="inv-tab-content"><div id="inv-spinner" style="color:rgba(255,255,255,0.4);text-align:center;padding:30px">Loading…</div></div>`;

    injectTabStyles();
    await loadCharacterTab();
  }

  async function loadCharacterTab() {
    const el = document.getElementById('inv-tab-content');
    if (!el) return;
    el.innerHTML = '<p style="color:rgba(255,255,255,0.4);text-align:center;padding:20px">Loading characters…</p>';

    const data = await NeonAPI.getCharacters();
    if (!data.success) {
      el.innerHTML = `<p style="color:var(--neon-pink)">Error loading characters.</p>`; return;
    }

    const { owned = [], all = [] } = data;

    el.innerHTML = cardGrid(all, (c) => {
      const isOwned    = owned.includes(c.id);
      const isEquipped = data.equipped === c.id;
      const locked     = !isOwned;

      return `
        <div style="
          background:${isEquipped ? 'rgba(0,212,255,0.15)' : 'rgba(255,255,255,0.04)'};
          border:1px solid ${isEquipped ? 'var(--neon-blue)' : 'rgba(255,255,255,0.1)'};
          border-radius:8px;padding:12px;text-align:center;cursor:pointer;
          transition:all 0.2s;
        " onclick="NeonMenu.selectCharacter('${c.id}','${c.sprite_key}')">
          <div style="
            width:56px;height:72px;margin:0 auto 8px;
            background:rgba(255,255,255,0.06);border-radius:6px;
            display:flex;align-items:center;justify-content:center;
            font-size:1.8rem;
          ">${locked ? '🔒' : '🎭'}</div>
          <div style="font-family:var(--font-display);font-size:0.65rem;color:#fff;margin-bottom:4px">${c.name}</div>
          <div style="font-size:0.7rem;color:${isEquipped ? 'var(--neon-green)' : isOwned ? 'var(--neon-blue)' : 'rgba(255,255,255,0.4)'}">
            ${isEquipped ? '✓ Equipped' : isOwned ? 'Owned' : `◈ ${c.coin_price}`}
          </div>
          ${isEquipped ? '' : `
            <button onclick="event.stopPropagation();NeonMenu.${isOwned ? 'equipChar' : 'buyChar'}('${c.id}')"
              style="margin-top:8px;padding:4px 10px;border-radius:4px;border:none;cursor:pointer;
              font-size:0.7rem;font-family:var(--font-display);
              background:${isOwned ? 'var(--neon-blue)' : 'var(--neon-pink)'};color:#000">
              ${isOwned ? 'Equip' : 'Buy'}
            </button>
          `}
        </div>`;
    });
  }

  async function selectCharacter(id, spriteKey) {
    await NeonCharacter.spawn(spriteKey,
      NeonCharacter.getSprite()?.position.x || 0,
      0,
      NeonCharacter.getSprite()?.position.z || 0
    );
  }

  async function equipChar(id) {
    const res = await NeonAPI.equipCharacter(id);
    if (res.success) {
      NeonHUD.floatText('Character equipped!', 'var(--neon-green)');
      await loadCharacterTab();
    }
  }

  async function buyChar(id) {
    const res = await NeonAPI.purchaseCharacter(id);
    if (res.success) {
      NeonHUD.floatText(`+Character unlocked!`, 'var(--neon-green)');
      NeonHUD.update(res.profile);
      await loadCharacterTab();
    } else {
      NeonHUD.floatText('Not enough coins', 'var(--neon-pink)');
    }
  }

  // ── MISSIONS ──────────────────────────────────────────────────────────────
  async function renderMissions(el) {
    el.innerHTML = header('📋 Missions', 'Complete missions to earn coins and XP') +
      '<p style="color:rgba(255,255,255,0.4);text-align:center;padding:20px">Loading…</p>';

    const data = await NeonAPI.getMissions();
    if (!data.success) {
      el.innerHTML += '<p style="color:var(--neon-pink)">Error loading missions.</p>'; return;
    }

    const mList = (data.missions || []).map(m => `
      <div style="
        background:rgba(255,255,255,0.04);
        border:1px solid rgba(${m.status === 'completed' ? '0,255,136' : '0,212,255'},0.2);
        border-radius:8px;padding:14px;margin-bottom:10px;
      ">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
          <div>
            <div style="font-family:var(--font-display);font-size:0.8rem;color:#fff;margin-bottom:4px">${m.name}</div>
            <div style="font-size:0.78rem;color:rgba(255,255,255,0.5);line-height:1.4">${m.description}</div>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-size:0.7rem;color:var(--neon-yellow)">◈ ${m.coin_reward}</div>
            <div style="font-size:0.7rem;color:var(--neon-purple)">✦ ${m.xp_reward} XP</div>
          </div>
        </div>
        ${m.status === 'completed'
          ? `<div style="margin-top:8px;font-size:0.7rem;color:var(--neon-green)">✓ Completed</div>`
          : m.status === 'in_progress'
          ? `<button onclick="NeonMissions.complete('${m.id}')"
               style="margin-top:8px;padding:5px 12px;border-radius:4px;border:none;cursor:pointer;
               background:var(--neon-green);color:#000;font-family:var(--font-display);font-size:0.7rem">
               Complete</button>`
          : `<button onclick="NeonMissions.start('${m.id}')"
               style="margin-top:8px;padding:5px 12px;border-radius:4px;border:none;cursor:pointer;
               background:var(--neon-blue);color:#000;font-family:var(--font-display);font-size:0.7rem">
               Start</button>`
        }
      </div>`).join('');

    el.querySelector('p:last-child')?.remove();
    el.innerHTML = header('📋 Missions', 'Complete missions to earn coins and XP') + mList;
  }

  // ── LEADERBOARD ──────────────────────────────────────────────────────────
  async function renderLeaderboard(el) {
    el.innerHTML = header('🏆 Leaderboard') +
      '<p style="color:rgba(255,255,255,0.4);text-align:center;padding:20px">Loading…</p>';

    const data = await NeonAPI.getLeaderboard('all_time', 1);
    if (!data.success || !data.entries) {
      el.innerHTML = header('🏆 Leaderboard') +
        '<p style="color:rgba(255,255,255,0.5);text-align:center;padding:20px">No data yet.</p>';
      return;
    }

    const rows = data.entries.map((e, i) => `
      <div style="display:flex;align-items:center;gap:12px;padding:10px;
        background:rgba(255,255,255,0.03);border-radius:6px;margin-bottom:6px;
        border-left:2px solid ${i === 0 ? 'var(--neon-yellow)' : i === 1 ? 'rgba(192,192,192,0.8)' : i === 2 ? 'rgba(205,127,50,0.8)' : 'rgba(255,255,255,0.1)'}">
        <div style="font-family:var(--font-display);font-size:0.9rem;color:var(--neon-blue);min-width:28px">
          ${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`}
        </div>
        <div style="flex:1">
          <div style="font-family:var(--font-display);font-size:0.75rem;color:#fff">${escapeHTML(e.username)}</div>
          <div style="font-size:0.7rem;color:rgba(255,255,255,0.4)">Level ${e.level}</div>
        </div>
        <div style="font-family:var(--font-display);font-size:0.8rem;color:var(--neon-yellow)">
          ✦ ${formatNumber(e.score)}
        </div>
      </div>`).join('');

    el.innerHTML = header('🏆 Leaderboard', `Top ${data.entries.length} players`) + rows;
  }

  // ── SETTINGS ──────────────────────────────────────────────────────────────
  function renderSettings(el) {
    el.innerHTML = header('⚙️ Settings') + `
      <div style="display:flex;flex-direction:column;gap:14px">
        <div>
          <label style="font-family:var(--font-display);font-size:0.7rem;color:var(--neon-blue);display:block;margin-bottom:6px">
            GRAPHICS QUALITY
          </label>
          <select onchange="NeonRenderer.setQuality(this.value)"
            style="width:100%;background:rgba(255,255,255,0.06);border:1px solid rgba(0,212,255,0.3);
            border-radius:6px;padding:8px;color:#fff;font-family:var(--font-body)">
            <option value="low">Low (best for older phones)</option>
            <option value="medium" selected>Medium (recommended)</option>
            <option value="high">High (PC)</option>
          </select>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-family:var(--font-display);font-size:0.7rem;color:rgba(255,255,255,0.7)">Weather Effects</span>
          <input type="checkbox" checked onchange="NeonWeather.setRainEnabled(this.checked)"
            style="width:18px;height:18px;cursor:pointer">
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-family:var(--font-display);font-size:0.7rem;color:rgba(255,255,255,0.7)">Day/Night Cycle</span>
          <input type="checkbox" checked onchange="NeonLighting.setEnabled(this.checked)"
            style="width:18px;height:18px;cursor:pointer">
        </div>
        <hr style="border-color:rgba(255,255,255,0.08)"/>
        <button onclick="NeonMenu.confirmLogout()"
          style="padding:10px;background:rgba(255,45,120,0.15);border:1px solid var(--neon-pink);
          border-radius:6px;color:var(--neon-pink);font-family:var(--font-display);font-size:0.75rem;
          cursor:pointer;letter-spacing:2px">
          LOG OUT
        </button>
      </div>`;
  }

  async function confirmLogout() {
    if (confirm('Log out of Neon World?')) {
      await NeonAPI.logout();
      window.location.href = '/login.html';
    }
  }

  // ── SOCIAL ────────────────────────────────────────────────────────────────
  function renderSocial(el) {
    el.innerHTML = header('👥 Players Online') +
      '<p style="color:rgba(255,255,255,0.5);font-family:var(--font-body);text-align:center;padding:20px">Multiplayer player list coming in Step 20.</p>';
  }

  // ── Tab switcher ──────────────────────────────────────────────────────────
  function switchTab(tab, context) {
    if (context === 'inv') {
      if (tab === 'characters') loadCharacterTab();
      // clothing and items tabs added in later steps
    }
  }

  // ── Style injection for tabs ───────────────────────────────────────────────
  function injectTabStyles() {
    if (document.getElementById('tab-style')) return;
    const s = document.createElement('style');
    s.id = 'tab-style';
    s.textContent = `
      .tab-btn {
        padding:6px 14px;border-radius:20px;border:1px solid rgba(0,212,255,0.3);
        background:rgba(255,255,255,0.04);color:rgba(255,255,255,0.6);
        font-family:var(--font-display);font-size:0.65rem;cursor:pointer;
        letter-spacing:1px;transition:all 0.2s;
      }
      .tab-btn:hover, .active-tab {
        background:rgba(0,212,255,0.15);
        border-color:var(--neon-blue);
        color:#fff;
      }
    `;
    document.head.appendChild(s);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  function escapeHTML(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
  function formatNumber(n) {
    if (n >= 1_000_000) return (n/1_000_000).toFixed(1)+'M';
    if (n >= 1_000)     return (n/1_000).toFixed(1)+'K';
    return String(n);
  }

  return {
    open, close, switchTab,
    selectCharacter, equipChar, buyChar,
    confirmLogout
  };
})();

window.NeonMenu = NeonMenu;
