/**
 * NEON WORLD — LIGHTING
 * Sets up the full lighting rig:
 *   • Ambient (sky fill)
 *   • Directional (sun / moon)
 *   • Hemisphere (ground bounce)
 *   • Point lights for neon signs  ← added by the city builder
 *   • Day/night cycle updated every frame
 */

const NeonLighting = (() => {

  let ambient     = null;
  let sun         = null;
  let hemisphere  = null;
  let timeOfDay   = 8;          // 0–24 hours
  let daySpeed    = 0.5;        // in-game hours per real second (0.5 = 48 min day)
  let enabled     = true;

  // Neon colour palette for night lighting
  const NEON_COLORS = [
    0xff2d78,   // pink
    0x00d4ff,   // blue
    0xbf00ff,   // purple
    0x00ff88,   // green
  ];

  // ── Initialise ────────────────────────────────────────────────────────────
  function init() {
    const scene = NeonScene.get();

    // 1. Ambient — base fill, prevents absolute black
    ambient = new THREE.AmbientLight(0x111133, 0.4);
    scene.add(ambient);

    // 2. Hemisphere — sky/ground colour bounce
    hemisphere = new THREE.HemisphereLight(
      0x0a0a33,   // sky colour (dark blue night sky)
      0x050510,   // ground colour
      0.6
    );
    scene.add(hemisphere);

    // 3. Directional sun/moon
    sun = new THREE.DirectionalLight(0xffffff, 1.0);
    sun.position.set(200, 400, 100);
    sun.castShadow = NeonRenderer.getQualityCfg().shadowMap;

    if (sun.castShadow) {
      const s = NeonRenderer.getQualityCfg().shadowSize;
      sun.shadow.mapSize.set(s, s);
      sun.shadow.camera.near   = 10;
      sun.shadow.camera.far    = 800;
      sun.shadow.camera.left   = -200;
      sun.shadow.camera.right  =  200;
      sun.shadow.camera.top    =  200;
      sun.shadow.camera.bottom = -200;
      sun.shadow.bias = -0.001;
    }
    scene.add(sun);

    // Register per-frame update
    NeonScene.onUpdate(update);

    console.log('✅ Lighting initialised');
  }

  // ── Per-frame update — day/night cycle ────────────────────────────────────
  function update(delta) {
    if (!enabled) return;

    timeOfDay = (timeOfDay + delta * daySpeed) % 24;

    const t    = timeOfDay / 24;               // 0–1
    const angle = t * Math.PI * 2 - Math.PI / 2;  // -π/2 to 3π/2

    // Sun position arcs across the sky
    sun.position.set(
      Math.cos(angle) * 300,
      Math.sin(angle) * 300,
      100
    );

    // Brightness: peaks at noon (t=0.5), zero at midnight (t=0/1)
    const sunHeight  = Math.max(0, Math.sin(angle));  // 0 → 1
    const isDay      = sunHeight > 0.05;
    const isDusk     = sunHeight < 0.25 && sunHeight > 0;

    if (isDay) {
      // Daytime — warm sun
      sun.intensity = sunHeight * 1.4;
      sun.color.setHSL(0.1, 0.3, 0.9);         // warm white
      ambient.color.setHSL(0.62, 0.4, 0.04 + sunHeight * 0.08);
      ambient.intensity = 0.3 + sunHeight * 0.5;
      hemisphere.skyColor.setHSL(0.6, 0.5, 0.05 + sunHeight * 0.3);

    } else if (isDusk) {
      // Dusk / dawn — orange tones
      sun.intensity = sunHeight * 1.2;
      sun.color.setHSL(0.05, 0.8, 0.7);        // orange
      ambient.color.setHSL(0.0, 0.4, 0.04);
      ambient.intensity = 0.25;
      hemisphere.skyColor.setHSL(0.05, 0.5, 0.06);

    } else {
      // Night — neon-tinted darkness
      sun.intensity = 0.05;                     // moon glow
      sun.color.setHSL(0.65, 0.3, 0.6);        // cool blue moonlight
      ambient.color.setHSL(0.7, 0.5, 0.03);
      ambient.intensity = 0.15;
      hemisphere.skyColor.setHSL(0.7, 0.6, 0.02);
    }

    // Update fog colour to match sky
    if (NeonScene.get().fog) {
      const fogLum = isDay ? 0.03 + sunHeight * 0.04 : 0.01;
      NeonScene.get().fog.color.setHSL(0.65, 0.5, fogLum);
    }
  }

  // ── Add a neon point light (called by city builder) ───────────────────────
  function addNeonLight(x, y, z, color = 0xff2d78, intensity = 3, distance = 30) {
    const light = new THREE.PointLight(color, intensity, distance);
    light.position.set(x, y, z);
    light.castShadow = false; // point light shadows are expensive
    NeonScene.add(light);
    return light;
  }

  // ── Add a neon spot light (for dramatic signs) ────────────────────────────
  function addNeonSpot(x, y, z, targetX, targetZ, color = 0x00d4ff) {
    const spot = new THREE.SpotLight(color, 4, 60, Math.PI / 6, 0.5);
    spot.position.set(x, y, z);
    spot.target.position.set(targetX, 0, targetZ);
    NeonScene.add(spot);
    NeonScene.add(spot.target);
    return spot;
  }

  const getTimeOfDay = () => timeOfDay;
  const isNight      = () => timeOfDay < 6 || timeOfDay > 20;
  const setDaySpeed  = (s) => { daySpeed = s; };
  const setEnabled   = (v) => { enabled = v; };

  return {
    init,
    addNeonLight,
    addNeonSpot,
    getTimeOfDay,
    isNight,
    setDaySpeed,
    setEnabled,
    NEON_COLORS
  };
})();

window.NeonLighting = NeonLighting;
