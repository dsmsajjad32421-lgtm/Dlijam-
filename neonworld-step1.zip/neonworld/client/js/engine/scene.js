/**
 * NEON WORLD — SCENE
 * Creates and owns the THREE.Scene.
 * Manages fog, background colour, and the render loop.
 */

const NeonScene = (() => {

  let scene    = null;
  let animId   = null;
  let lastTime = 0;
  const updateCallbacks = [];   // systems register here to receive delta

  // ── Initialise ────────────────────────────────────────────────────────────
  function init() {
    scene = new THREE.Scene();

    // Deep void colour — the neon sky gradient is drawn by the skybox/shader
    // For now a flat dark blue-black
    scene.background = new THREE.Color(0x060612);

    // Atmospheric fog — adds depth and hides the world edge
    const fogColor = new THREE.Color(0x0a0a22);
    scene.fog = new THREE.FogExp2(fogColor, NeonRenderer.getQualityCfg().fogDensity);

    console.log('✅ Scene initialised');
    return scene;
  }

  // ── Register a per-frame callback ─────────────────────────────────────────
  // Usage: NeonScene.onUpdate(delta => { /* move things */ });
  function onUpdate(cb) {
    updateCallbacks.push(cb);
  }

  // ── Render loop ───────────────────────────────────────────────────────────
  function startLoop() {
    const renderer = NeonRenderer.getRenderer();
    const camera   = NeonCamera.getCamera();

    function loop(now) {
      animId = requestAnimationFrame(loop);

      const delta = Math.min((now - lastTime) / 1000, 0.1); // cap at 100 ms
      lastTime = now;

      // Run all registered update callbacks
      for (let i = 0; i < updateCallbacks.length; i++) {
        try { updateCallbacks[i](delta, now); }
        catch (e) { console.error('Update callback error:', e); }
      }

      renderer.render(scene, camera);
    }

    lastTime = performance.now();
    animId   = requestAnimationFrame(loop);
    console.log('✅ Render loop started');
  }

  function stopLoop() {
    if (animId) cancelAnimationFrame(animId);
  }

  // ── Add / remove helpers ──────────────────────────────────────────────────
  const add    = (obj) => scene.add(obj);
  const remove = (obj) => scene.remove(obj);
  const get    = ()    => scene;

  return { init, onUpdate, startLoop, stopLoop, add, remove, get };
})();

window.NeonScene = NeonScene;
