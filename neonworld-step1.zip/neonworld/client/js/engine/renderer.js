/**
 * NEON WORLD — RENDERER
 * Creates and manages the Three.js WebGL renderer.
 * Supports three quality tiers: low / medium / high
 * Auto-detects mobile and applies performance settings.
 */

const NeonRenderer = (() => {

  let renderer = null;
  let quality  = 'medium';
  let canvas   = null;

  // ── Quality presets ────────────────────────────────────────────────────────
  const QUALITY = {
    low: {
      antialias:   false,
      shadowMap:   false,
      pixelRatio:  0.75,
      shadowSize:  512,
      fogDensity:  0.025,
      label:       'Low'
    },
    medium: {
      antialias:   true,
      shadowMap:   true,
      pixelRatio:  Math.min(window.devicePixelRatio, 1.5),
      shadowSize:  1024,
      fogDensity:  0.018,
      label:       'Medium'
    },
    high: {
      antialias:   true,
      shadowMap:   true,
      pixelRatio:  Math.min(window.devicePixelRatio, 2),
      shadowSize:  2048,
      fogDensity:  0.012,
      label:       'High'
    }
  };

  // ── Detect if the device is mobile ────────────────────────────────────────
  function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i
      .test(navigator.userAgent) || window.innerWidth < 768;
  }

  // ── Initialise ────────────────────────────────────────────────────────────
  function init() {
    canvas = document.getElementById('game-canvas');

    // Auto pick quality tier
    quality = isMobile() ? 'low' : 'medium';
    const q = QUALITY[quality];

    renderer = new THREE.WebGLRenderer({
      canvas,
      antialias:        q.antialias,
      powerPreference:  'high-performance',
      alpha:            false
    });

    renderer.setPixelRatio(q.pixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);

    // Shadows
    renderer.shadowMap.enabled = q.shadowMap;
    renderer.shadowMap.type    = THREE.PCFSoftShadowMap;

    // Colour space — correct gamma for bright neon colours
    renderer.outputEncoding = THREE.sRGBEncoding;

    // Tone mapping — gives the neon glow a cinematic feel
    renderer.toneMapping         = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    // Handle window resize
    window.addEventListener('resize', onResize);

    console.log(`✅ Renderer init — quality: ${q.label}, pixel ratio: ${q.pixelRatio}`);
    return renderer;
  }

  function onResize() {
    if (!renderer) return;
    renderer.setSize(window.innerWidth, window.innerHeight);
    // Camera aspect is updated in camera.js via the same event
  }

  // ── Change quality at runtime ─────────────────────────────────────────────
  function setQuality(tier) {
    if (!QUALITY[tier] || !renderer) return;
    quality        = tier;
    const q        = QUALITY[tier];
    renderer.setPixelRatio(q.pixelRatio);
    renderer.shadowMap.enabled = q.shadowMap;
    console.log(`🔧 Quality changed to: ${q.label}`);
  }

  const getRenderer  = ()  => renderer;
  const getQuality   = ()  => quality;
  const getQualityCfg = () => QUALITY[quality];

  return { init, setQuality, getRenderer, getQuality, getQualityCfg, isMobile };
})();

window.NeonRenderer = NeonRenderer;
