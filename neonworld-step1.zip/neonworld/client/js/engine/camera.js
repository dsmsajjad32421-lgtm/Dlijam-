/**
 * NEON WORLD — CAMERA
 * Third-person follow camera with smooth lerp.
 * Supports mouse drag (PC) and touch drag (mobile) for orbit.
 */

const NeonCamera = (() => {

  let camera   = null;
  let target   = null;    // THREE.Object3D to follow (the player)

  // Camera orbit state
  let yaw      = 0;       // horizontal angle (radians)
  let pitch    = 0.35;    // vertical angle
  let distance = 12;      // distance behind player

  const MIN_PITCH    =  0.1;
  const MAX_PITCH    =  1.2;
  const MIN_DISTANCE =  4;
  const MAX_DISTANCE = 30;

  // Smooth follow
  const LERP_SPEED = 8;
  const camPos     = new THREE.Vector3();
  const lookAt     = new THREE.Vector3();

  // Drag tracking
  let dragging   = false;
  let lastX      = 0;
  let lastY      = 0;

  // ── Initialise ─────────────────────────────────────────────────────────────
  function init() {
    camera = new THREE.PerspectiveCamera(
      60,                                         // FOV
      window.innerWidth / window.innerHeight,     // aspect
      0.1,                                        // near clip
      1000                                        // far clip
    );
    camera.position.set(0, 10, 20);

    // Resize handler
    window.addEventListener('resize', () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
    });

    // ── Input — mouse ────────────────────────────────────────────────────────
    const canvas = document.getElementById('game-canvas');

    canvas.addEventListener('mousedown', (e) => {
      // Only right-click or middle-click orbits; left click is action
      if (e.button === 2 || e.button === 1) {
        dragging = true; lastX = e.clientX; lastY = e.clientY;
      }
    });
    window.addEventListener('mouseup',   () => { dragging = false; });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      yaw   -= (e.clientX - lastX) * 0.005;
      pitch  = Math.max(MIN_PITCH, Math.min(MAX_PITCH,
                 pitch + (e.clientY - lastY) * 0.004));
      lastX = e.clientX; lastY = e.clientY;
    });

    // Scroll wheel = zoom
    canvas.addEventListener('wheel', (e) => {
      distance = Math.max(MIN_DISTANCE,
                 Math.min(MAX_DISTANCE, distance + e.deltaY * 0.02));
    }, { passive: true });

    canvas.addEventListener('contextmenu', e => e.preventDefault());

    // ── Input — touch ────────────────────────────────────────────────────────
    // Two-finger drag = orbit camera (one finger is joystick)
    let touches = {};
    canvas.addEventListener('touchstart', (e) => {
      for (const t of e.changedTouches) {
        touches[t.identifier] = { x: t.clientX, y: t.clientY };
      }
    }, { passive: true });

    canvas.addEventListener('touchmove', (e) => {
      // Two-finger pinch / drag for camera
      const ids = Object.keys(touches);
      if (ids.length === 2 && e.touches.length === 2) {
        const ta = e.touches[0], tb = e.touches[1];
        const dx = ta.clientX - tb.clientX;
        const dy = ta.clientY - tb.clientY;
        const newDist = Math.sqrt(dx*dx + dy*dy);

        const prev = touches._pinchDist;
        if (prev) {
          distance = Math.max(MIN_DISTANCE,
                     Math.min(MAX_DISTANCE, distance - (newDist - prev) * 0.05));
        }
        touches._pinchDist = newDist;
        return;
      }

      // Single finger on the RIGHT half of the screen = orbit
      for (const t of e.changedTouches) {
        if (t.clientX < window.innerWidth * 0.55) continue; // left side = joystick
        const prev = touches[t.identifier];
        if (!prev) continue;
        yaw   -= (t.clientX - prev.x) * 0.006;
        pitch  = Math.max(MIN_PITCH, Math.min(MAX_PITCH,
                   pitch + (t.clientY - prev.y) * 0.005));
        touches[t.identifier] = { x: t.clientX, y: t.clientY };
      }
    }, { passive: true });

    canvas.addEventListener('touchend', (e) => {
      for (const t of e.changedTouches) delete touches[t.identifier];
      if (Object.keys(touches).filter(k => k !== '_pinchDist').length < 2) {
        delete touches._pinchDist;
      }
    }, { passive: true });

    // Register per-frame update
    NeonScene.onUpdate(update);

    console.log('✅ Camera initialised');
    return camera;
  }

  // ── Per-frame update ───────────────────────────────────────────────────────
  function update(delta) {
    if (!camera) return;
    if (!target) {
      // No player yet — orbit around origin
      camera.position.set(
        Math.sin(yaw) * distance * Math.cos(pitch),
        distance * Math.sin(pitch),
        Math.cos(yaw) * distance * Math.cos(pitch)
      );
      camera.lookAt(0, 1, 0);
      return;
    }

    const tx = target.position.x;
    const ty = target.position.y + 1.5;  // look at chest height
    const tz = target.position.z;

    // Desired camera position
    const desiredX = tx + Math.sin(yaw)   * distance * Math.cos(pitch);
    const desiredY = ty + Math.sin(pitch) * distance;
    const desiredZ = tz + Math.cos(yaw)   * distance * Math.cos(pitch);

    // Smooth lerp
    const lf = 1 - Math.exp(-LERP_SPEED * delta);
    camPos.set(desiredX, desiredY, desiredZ);
    camera.position.lerp(camPos, lf);

    lookAt.set(tx, ty, tz);
    camera.lookAt(lookAt);
  }

  // ── Public API ─────────────────────────────────────────────────────────────
  const getCamera    = ()  => camera;
  const setTarget    = (t) => { target = t; };
  const setYaw       = (y) => { yaw = y; };
  const getYaw       = ()  => yaw;

  return { init, getCamera, setTarget, setYaw, getYaw };
})();

window.NeonCamera = NeonCamera;
