/**
 * NEON WORLD — VEHICLE SYSTEM
 * Full vehicle implementation in Step 15.
 * Placeholder so the game loads without errors.
 */

const NeonVehicles = (() => {

  const vehicles = [];  // active vehicle meshes

  function init() {
    // Placeholder vehicle — a glowing neon car shape
    const group = new THREE.Group();

    // Body
    const bodyGeo  = new THREE.BoxGeometry(4, 1.2, 2);
    const bodyMesh = new THREE.Mesh(bodyGeo,
      new THREE.MeshLambertMaterial({ color: 0x110022, emissive: 0x220044, emissiveIntensity: 0.3 }));
    bodyMesh.position.y = 1;
    bodyMesh.castShadow = true;
    group.add(bodyMesh);

    // Cab
    const cabGeo  = new THREE.BoxGeometry(2.4, 0.9, 1.8);
    const cabMesh = new THREE.Mesh(cabGeo,
      new THREE.MeshLambertMaterial({ color: 0x0a001a }));
    cabMesh.position.set(-0.2, 1.85, 0);
    group.add(cabMesh);

    // Neon underglow
    [0xff2d78, 0x00d4ff].forEach((c, i) => {
      NeonLighting.addNeonLight(i === 0 ? -2 : 2, 0.3, 0, c, 2, 8);
    });

    // Wheels (4)
    [[-1.2, -1.1], [-1.2, 1.1], [1.2, -1.1], [1.2, 1.1]].forEach(([wx, wz]) => {
      const wGeo  = new THREE.CylinderGeometry(0.45, 0.45, 0.3, 8);
      const wMesh = new THREE.Mesh(wGeo,
        new THREE.MeshLambertMaterial({ color: 0x111111 }));
      wMesh.rotation.z = Math.PI / 2;
      wMesh.position.set(wx, 0.45, wz);
      group.add(wMesh);
    });

    // Park it on the side of the road
    group.position.set(18, 0, -30);
    NeonScene.add(group);
    vehicles.push(group);

    // Vehicle button
    document.getElementById('btn-vehicle')?.addEventListener('touchstart', (e) => {
      e.preventDefault();
      NeonHUD.floatText('Vehicles — Step 15', 'var(--neon-purple)');
    }, { passive: false });

    console.log('✅ Vehicle system initialised (placeholder)');
  }

  return { init };
})();

window.NeonVehicles = NeonVehicles;
