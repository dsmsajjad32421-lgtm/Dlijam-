/**
 * NEON WORLD — MISSION SYSTEM (CLIENT)
 * Talks to /api/game/missions/* endpoints.
 * All reward calculations happen on the server.
 */

const NeonMissions = (() => {

  let activeMission = null;

  async function start(missionId) {
    const res = await NeonAPI.startMission(missionId);
    if (res.success) {
      activeMission = res.mission;
      showTracker(res.mission);
      NeonHUD.floatText('Mission started!', 'var(--neon-blue)');
      NeonMenu.close();
    } else {
      NeonHUD.floatText(res.error || 'Cannot start mission', 'var(--neon-pink)');
    }
  }

  async function complete(missionId) {
    const res = await NeonAPI.completeMission(missionId || activeMission?.id);
    if (res.success) {
      activeMission = null;
      hideTracker();
      NeonHUD.floatText(`+${res.coins} coins!`, 'var(--neon-yellow)');
      NeonHUD.floatText(`+${res.xp} XP`, 'var(--neon-purple)');
      if (res.profile) NeonHUD.update(res.profile);
      NeonMenu.close();
    } else {
      NeonHUD.floatText(res.error || 'Mission not ready', 'var(--neon-pink)');
    }
  }

  function showTracker(mission) {
    const tracker = document.getElementById('mission-tracker');
    const nameEl  = document.getElementById('mission-name');
    const objEl   = document.getElementById('mission-objectives');
    if (!tracker) return;

    nameEl.textContent = mission.name;
    objEl.innerHTML = (mission.objectives || []).map(o =>
      `<div style="font-size:0.72rem;color:rgba(255,255,255,0.6);margin-top:4px">▸ ${o.label}</div>`
    ).join('');
    tracker.classList.remove('hidden');
  }

  function hideTracker() {
    document.getElementById('mission-tracker')?.classList.add('hidden');
  }

  // Listen for the interact event (triggered by mobile button or E key)
  document.addEventListener('neon:interact', () => {
    if (activeMission) complete(activeMission.id);
  });

  return { start, complete };
})();

window.NeonMissions = NeonMissions;
