/**
 * NEON WORLD — INVENTORY SYSTEM (CLIENT)
 * Manages local inventory state, syncs with server.
 */

const NeonInventory = (() => {

  let inventory = [];
  let clothing  = [];

  async function load() {
    const [invRes, clothRes] = await Promise.all([
      NeonAPI.getInventory(),
      NeonAPI.getClothing()
    ]);
    if (invRes.success)   inventory = invRes.items   || [];
    if (clothRes.success) clothing  = clothRes.items || [];
  }

  const getInventory = () => inventory;
  const getClothing  = () => clothing;

  return { load, getInventory, getClothing };
})();

window.NeonInventory = NeonInventory;
