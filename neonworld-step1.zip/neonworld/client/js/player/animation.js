/**
 * NEON WORLD — ANIMATION
 * Manages sprite sheet frame cycling for characters.
 * When you have sprite sheets (multiple frames per image),
 * this system steps through them at the right frame rate.
 *
 * For now we load single-frame PNGs per animation state.
 * Future: replace with sprite sheets for smoother motion.
 */

const NeonAnimation = (() => {

  // ── Other player sprites (multiplayer) ────────────────────────────────────
  const remotePlayers = new Map(); // socketId → { sprite, nameTag }

  // ── Remote player mesh ────────────────────────────────────────────────────
  function createRemoteSprite(id, characterId = 'pink_goggles') {
    const def = NeonCharacter.CHARACTER_DEFS[characterId]
             || NeonCharacter.CHARACTER_DEFS['pink_goggles'];

    // Simple coloured sprite as placeholder
    const canvas  = document.createElement('canvas');
    canvas.width  = 64; canvas.height = 96;
    const ctx     = canvas.getContext('2d');

    ctx.fillStyle = '#' + def.glowColor.toString(16).padStart(6, '0') + '88';
    ctx.beginPath();
    ctx.ellipse(32, 64, 18, 28, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(32, 28, 14, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    const tex  = new THREE.CanvasTexture(canvas);
    const mat  = new THREE.SpriteMaterial({ map: tex, transparent: true, alphaTest: 0.1 });
    const spr  = new THREE.Sprite(mat);
    spr.scale.set(1.6, 2.4, 1);
    spr.name = `remote_${id}`;
    NeonScene.add(spr);

    remotePlayers.set(id, { sprite: spr });
    return spr;
  }

  // ── Update or create remote player ────────────────────────────────────────
  function updateRemotePlayer(data) {
    let entry = remotePlayers.get(data.id);

    if (!entry) {
      createRemoteSprite(data.id, data.characterId);
      entry = remotePlayers.get(data.id);
    }

    if (entry) {
      entry.sprite.position.set(data.x, data.y, data.z);
    }
  }

  // ── Remove remote player ──────────────────────────────────────────────────
  function removeRemotePlayer(id) {
    const entry = remotePlayers.get(id);
    if (entry) {
      NeonScene.remove(entry.sprite);
      remotePlayers.delete(id);
    }
  }

  // ── Initialise socket listeners for remote players ────────────────────────
  function init() {
    NeonSocket.on('player_joined',      data => createRemoteSprite(data.id, data.characterId));
    NeonSocket.on('player_left',        data => removeRemotePlayer(data.id));
    NeonSocket.on('other_player_move',  data => updateRemotePlayer(data));
    NeonSocket.on('zone_snapshot', ({ players }) => {
      players.forEach(p => createRemoteSprite(p.id, p.characterId));
    });

    console.log('✅ Animation / remote player system initialised');
  }

  return { init, updateRemotePlayer, removeRemotePlayer };
})();

window.NeonAnimation = NeonAnimation;
