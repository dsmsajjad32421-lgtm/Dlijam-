/**
 * NEON WORLD — CHARACTER SYSTEM
 *
 * Your PNG characters are rendered as billboard sprites —
 * they always face the camera, keeping your original artwork intact.
 *
 * Each character folder (assets/characters/<key>/) should contain:
 *   idle.png   walk.png   run.png   jump.png
 *
 * The character is a THREE.Sprite with a canvas-drawn texture.
 * A shadow circle is placed under the sprite.
 */

const NeonCharacter = (() => {

  // ── Character definitions ─────────────────────────────────────────────────
  // These match the DB seed. Add new characters here AND in seed.js.
  const CHARACTER_DEFS = {
    pink_goggles: {
      name:        'Pink Goggles',
      folder:      'assets/characters/pink-goggles/',
      scale:       2.2,
      glowColor:   0xff2d78,
      shadowColor: '#ff2d7833'
    },
    blue_shadow: {
      name:        'Blue Shadow',
      folder:      'assets/characters/blue-shadow/',
      scale:       2.4,
      glowColor:   0x00d4ff,
      shadowColor: '#00d4ff33'
    },
    travel_buddy: {
      name:        'Travel Buddy',
      folder:      'assets/characters/travel-buddy/',
      scale:       1.8,
      glowColor:   0x00ff88,
      shadowColor: '#00ff8833'
    },
    neon_hero: {
      name:        'Neon Hero',
      folder:      'assets/characters/neon-hero/',
      scale:       2.6,
      glowColor:   0xff6a00,
      shadowColor: '#ff6a0033'
    }
  };

  let currentSprite  = null;   // THREE.Sprite
  let shadowMesh     = null;   // flat circle under character
  let currentDef     = null;
  let currentAnim    = 'idle';
  let textureCache   = {};     // path → THREE.Texture

  // ── Load a texture (with cache) ───────────────────────────────────────────
  function loadTex(path) {
    if (textureCache[path]) return Promise.resolve(textureCache[path]);

    return new Promise((resolve) => {
      const loader = new THREE.TextureLoader();
      loader.load(
        path,
        (tex) => { textureCache[path] = tex; resolve(tex); },
        undefined,
        () => {
          // PNG not found yet — create a coloured placeholder
          const canvas  = document.createElement('canvas');
          canvas.width  = 128; canvas.height = 128;
          const ctx     = canvas.getContext('2d');

          // Draw a simple character stand-in
          ctx.fillStyle = '#0a0a1e';
          ctx.fillRect(0, 0, 128, 128);

          // Body
          ctx.fillStyle = currentDef
            ? '#' + currentDef.glowColor.toString(16).padStart(6, '0')
            : '#ff2d78';
          ctx.beginPath();
          ctx.ellipse(64, 80, 30, 40, 0, 0, Math.PI * 2);
          ctx.fill();

          // Head
          ctx.beginPath();
          ctx.ellipse(64, 38, 24, 24, 0, 0, Math.PI * 2);
          ctx.fill();

          // Eyes
          ctx.fillStyle = '#000';
          ctx.fillRect(52, 30, 8, 8);
          ctx.fillRect(68, 30, 8, 8);
          ctx.fillStyle = '#fff';
          ctx.fillRect(54, 32, 4, 4);
          ctx.fillRect(70, 32, 4, 4);

          // Neon outline glow
          ctx.strokeStyle = ctx.fillStyle = '#fff';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.ellipse(64, 38, 24, 24, 0, 0, Math.PI * 2);
          ctx.stroke();

          const tex = new THREE.CanvasTexture(canvas);
          textureCache[path] = tex;
          resolve(tex);
        }
      );
    });
  }

  // ── Create shadow circle under character ──────────────────────────────────
  function createShadow(color) {
    if (shadowMesh) NeonScene.remove(shadowMesh);

    const geo  = new THREE.CircleGeometry(0.8, 16);
    const mat  = new THREE.MeshBasicMaterial({
      color:       0x000000,
      transparent: true,
      opacity:     0.4,
      depthWrite:  false
    });
    shadowMesh = new THREE.Mesh(geo, mat);
    shadowMesh.rotation.x = -Math.PI / 2;
    NeonScene.add(shadowMesh);
  }

  // ── Spawn / switch character ───────────────────────────────────────────────
  async function spawn(spriteKey, x = 0, y = 0, z = 0) {
    const def = CHARACTER_DEFS[spriteKey];
    if (!def) {
      console.warn('Unknown character key:', spriteKey);
      return;
    }
    currentDef = def;

    // Remove previous sprite
    if (currentSprite) NeonScene.remove(currentSprite);

    // Load idle texture
    const tex = await loadTex(def.folder + 'idle.png');

    const mat  = new THREE.SpriteMaterial({
      map:         tex,
      transparent: true,
      alphaTest:   0.1
    });
    currentSprite = new THREE.Sprite(mat);
    currentSprite.scale.set(def.scale, def.scale * 1.5, 1);
    currentSprite.position.set(x, def.scale * 0.75, z);
    currentSprite.name = 'player_sprite';

    NeonScene.add(currentSprite);
    createShadow(def.shadowColor);

    // Neon glow beneath sprite
    NeonLighting.addNeonLight(x, 0.5, z, def.glowColor, 1.5, 6);

    // Tell camera to follow this sprite
    NeonCamera.setTarget(currentSprite);

    console.log(`✅ Character spawned: ${def.name}`);
    return currentSprite;
  }

  // ── Switch animation frame ─────────────────────────────────────────────────
  async function setAnimation(animName) {
    if (!currentDef || !currentSprite) return;
    if (animName === currentAnim) return;
    currentAnim = animName;

    const valid = ['idle', 'walk', 'run', 'jump'];
    const name  = valid.includes(animName) ? animName : 'idle';
    const path  = currentDef.folder + name + '.png';

    const tex = await loadTex(path);
    currentSprite.material.map = tex;
    currentSprite.material.needsUpdate = true;
  }

  // ── Update shadow position each frame ─────────────────────────────────────
  NeonScene.onUpdate(() => {
    if (!currentSprite || !shadowMesh) return;
    shadowMesh.position.set(
      currentSprite.position.x,
      0.01,
      currentSprite.position.z
    );
  });

  // ── Public API ─────────────────────────────────────────────────────────────
  const getSprite    = ()  => currentSprite;
  const getDef       = ()  => currentDef;
  const getAnimation = ()  => currentAnim;

  return {
    CHARACTER_DEFS,
    spawn,
    setAnimation,
    getSprite,
    getDef,
    getAnimation
  };
})();

window.NeonCharacter = NeonCharacter;
