/**
 * NEON WORLD — PLAYER MOVEMENT
 * Handles keyboard (PC) and joystick (mobile) input.
 * Moves the character sprite and sends position to the server.
 */

const NeonMovement = (() => {

  // ── Input state ───────────────────────────────────────────────────────────
  const keys = {
    forward:  false, // W / ArrowUp
    backward: false, // S / ArrowDown
    left:     false, // A / ArrowLeft
    right:    false, // D / ArrowRight
    run:      false, // Shift
    jump:     false  // Space
  };

  // Joystick input (set by joystick.js)
  let joyX = 0;   // -1 to 1
  let joyY = 0;   // -1 to 1

  // Movement constants
  const WALK_SPEED   = 5;
  const RUN_SPEED    = 10;
  const SPRINT_SPEED = 16;
  const JUMP_IMPULSE = 8;
  const GRAVITY      = 18;

  // Player state
  let velY      = 0;
  let isGrounded = true;
  let isJumping  = false;

  // Network throttle — send position every 50 ms max
  let netTimer = 0;
  const NET_INTERVAL = 0.05;

  // ── Keyboard listeners ────────────────────────────────────────────────────
  function initKeyboard() {
    const MAP = {
      KeyW:        'forward',  ArrowUp:    'forward',
      KeyS:        'backward', ArrowDown:  'backward',
      KeyA:        'left',     ArrowLeft:  'left',
      KeyD:        'right',    ArrowRight: 'right',
      ShiftLeft:   'run',      ShiftRight: 'run',
      Space:       'jump'
    };

    window.addEventListener('keydown', (e) => {
      if (MAP[e.code]) { keys[MAP[e.code]] = true; e.preventDefault(); }
    });
    window.addEventListener('keyup', (e) => {
      if (MAP[e.code]) keys[MAP[e.code]] = false;
    });
  }

  // ── Joystick input (called by joystick.js) ────────────────────────────────
  function setJoystick(x, y) {
    joyX = x;
    joyY = y;
  }

  // ── Mobile button handlers ────────────────────────────────────────────────
  function initMobileButtons() {
    const btnJump     = document.getElementById('btn-jump');
    const btnRun      = document.getElementById('btn-run');
    const btnInteract = document.getElementById('btn-interact');

    if (btnJump) {
      btnJump.addEventListener('touchstart', (e) => {
        e.preventDefault();
        keys.jump = true;
      }, { passive: false });
      btnJump.addEventListener('touchend', () => { keys.jump = false; });
    }

    if (btnRun) {
      btnRun.addEventListener('touchstart', (e) => {
        e.preventDefault();
        keys.run = !keys.run; // toggle sprint
        btnRun.classList.toggle('active', keys.run);
      }, { passive: false });
    }

    if (btnInteract) {
      btnInteract.addEventListener('touchstart', (e) => {
        e.preventDefault();
        triggerInteract();
      }, { passive: false });
    }
  }

  // ── Interaction trigger ───────────────────────────────────────────────────
  function triggerInteract() {
    // Will be picked up by missions.js and npc system
    document.dispatchEvent(new CustomEvent('neon:interact'));
  }

  // ── Per-frame movement update ─────────────────────────────────────────────
  function update(delta) {
    const sprite = NeonCharacter.getSprite();
    if (!sprite) return;

    // ── Direction from keyboard OR joystick ──
    let moveX = 0;
    let moveZ = 0;

    if (keys.forward  || joyY < -0.2) moveZ -= 1;
    if (keys.backward || joyY >  0.2) moveZ += 1;
    if (keys.left     || joyX < -0.2) moveX -= 1;
    if (keys.right    || joyX >  0.2) moveX += 1;

    // Use joystick magnitude for fine speed
    if (Math.abs(joyX) > 0.2 || Math.abs(joyY) > 0.2) {
      moveX = joyX;
      moveZ = joyY;
    }

    // Normalise diagonal movement
    const len = Math.sqrt(moveX * moveX + moveZ * moveZ);
    if (len > 1) { moveX /= len; moveZ /= len; }

    const moving = len > 0.1;

    // ── Speed tier ──
    let speed = WALK_SPEED;
    if (keys.run && moving) speed = Math.abs(joyX) > 0.8 || Math.abs(joyY) > 0.8
      ? SPRINT_SPEED : RUN_SPEED;

    // ── Rotate with camera yaw ──
    const camYaw = NeonCamera.getYaw();
    const rotX   = moveX * Math.cos(camYaw) - moveZ * Math.sin(camYaw);
    const rotZ   = moveX * Math.sin(camYaw) + moveZ * Math.cos(camYaw);

    // ── Apply movement ──
    sprite.position.x += rotX * speed * delta;
    sprite.position.z += rotZ * speed * delta;

    // World bounds clamp
    sprite.position.x = Math.max(-490, Math.min(490, sprite.position.x));
    sprite.position.z = Math.max(-490, Math.min(490, sprite.position.z));

    // ── Gravity + jump ──
    if (keys.jump && isGrounded && !isJumping) {
      velY      = JUMP_IMPULSE;
      isGrounded = false;
      isJumping  = true;
      keys.jump  = false;
    }

    if (!isGrounded) {
      velY -= GRAVITY * delta;
      sprite.position.y += velY * delta;

      if (sprite.position.y <= (NeonCharacter.getDef()?.scale ?? 2) * 0.75) {
        sprite.position.y = (NeonCharacter.getDef()?.scale ?? 2) * 0.75;
        velY      = 0;
        isGrounded = true;
        isJumping  = false;
      }
    }

    // ── Animation state ──
    let anim = 'idle';
    if (isJumping || !isGrounded) {
      anim = 'jump';
    } else if (moving) {
      anim = (speed >= RUN_SPEED) ? 'run' : 'walk';
    }
    NeonCharacter.setAnimation(anim);

    // ── Face direction of movement ──
    if (moving) {
      const targetAngle = Math.atan2(rotX, rotZ);
      // Slight scale flip for left/right sprite mirroring
      sprite.scale.x = rotX < 0
        ? -Math.abs(sprite.scale.x)
        :  Math.abs(sprite.scale.x);
    }

    // ── Network: throttled position send ──
    netTimer += delta;
    if (netTimer >= NET_INTERVAL) {
      netTimer = 0;
      NeonSocket.sendMove(
        sprite.position.x,
        sprite.position.y,
        sprite.position.z,
        0,    // rotation (billboard sprites don't need server-side rotation)
        anim
      );
    }
  }

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    initKeyboard();
    initMobileButtons();
    NeonScene.onUpdate(update);
    console.log('✅ Movement system initialised');
  }

  return { init, setJoystick, triggerInteract };
})();

window.NeonMovement = NeonMovement;
