/**
 * NEON WORLD — MAIN GAME BOOTSTRAP
 *
 * Starts every system in the correct order:
 *   1. Check server health
 *   2. Check if user is logged in
 *   3. Init Three.js (renderer → scene → lighting → camera)
 *   4. Build world (terrain → city → nature → weather)
 *   5. Spawn player character
 *   6. Init movement + joystick
 *   7. Init HUD
 *   8. Connect socket + join zone
 *   9. Load announcements
 *   10. Start render loop
 */

(async function NeonWorldMain() {

  // ── Loading helpers ─────────────────────────────────────────────────────────
  const loadBar    = document.getElementById('load-bar');
  const loadStatus = document.getElementById('load-status');
  const loadScreen = document.getElementById('loading-screen');

  function progress(pct, msg) {
    if (loadBar)    loadBar.style.width = pct + '%';
    if (loadStatus) loadStatus.textContent = msg;
  }

  function hideLoader() {
    loadScreen.classList.add('fade-out');
    setTimeout(() => { loadScreen.style.display = 'none'; }, 650);
  }

  // ── STEP 1 — Server health check ────────────────────────────────────────────
  progress(5, 'Connecting to server…');
  try {
    const health = await NeonAPI.health();
    if (!health.success) throw new Error('Server offline');
    console.log('✅ Server:', health.message);
  } catch (e) {
    progress(0, '⚠️  Cannot reach server. Retrying…');
    setTimeout(() => window.location.reload(), 4000);
    return;
  }

  // ── STEP 2 — Auth check ─────────────────────────────────────────────────────
  progress(10, 'Checking account…');
  let profile = null;

  try {
    const meRes = await NeonAPI.me();
    if (!meRes.success) {
      // Not logged in → redirect to login page
      window.location.href = '/login.html';
      return;
    }
    profile = meRes.profile;
    console.log('✅ Logged in as:', meRes.user.username);
  } catch (e) {
    window.location.href = '/login.html';
    return;
  }

  // ── STEP 3 — Game settings from server ─────────────────────────────────────
  progress(15, 'Loading game settings…');
  let settings = {};
  try {
    const sRes = await NeonAPI.getSettings();
    if (sRes.success) settings = sRes.settings || {};

    // Maintenance mode check
    if (settings.maintenance_mode === 'true') {
      progress(0, '🔧 Server is under maintenance. Please check back later.');
      return;
    }
  } catch (e) { /* use defaults */ }

  // ── STEP 4 — Three.js renderer ──────────────────────────────────────────────
  progress(20, 'Starting 3D engine…');
  NeonRenderer.init();

  // ── STEP 5 — Scene ─────────────────────────────────────────────────────────
  progress(25, 'Building scene…');
  NeonScene.init();

  // ── STEP 6 — Lighting ──────────────────────────────────────────────────────
  progress(30, 'Setting up neon lights…');
  NeonLighting.init();

  // ── STEP 7 — Camera ─────────────────────────────────────────────────────────
  progress(35, 'Calibrating camera…');
  NeonCamera.init();

  // ── STEP 8 — World ──────────────────────────────────────────────────────────
  progress(45, 'Laying terrain…');
  NeonTerrain.build();

  progress(55, 'Building neon city…');
  NeonCity.build();

  progress(65, 'Planting trees and animals…');
  NeonNature.build();

  progress(72, 'Initialising weather…');
  NeonWeather.init();

  // ── STEP 9 — Player character ───────────────────────────────────────────────
  progress(80, 'Spawning your character…');

  // Get the character the player has equipped
  let charKey = 'pink_goggles'; // default
  try {
    const charRes = await NeonAPI.getCharacters();
    if (charRes.success && charRes.equipped_key) {
      charKey = charRes.equipped_key;
    }
  } catch (e) { /* use default */ }

  const startX = profile?.pos_x || 0;
  const startZ = profile?.pos_z || 0;
  await NeonCharacter.spawn(charKey, startX, 0, startZ);

  // ── STEP 10 — Movement + joystick ──────────────────────────────────────────
  progress(85, 'Wiring controls…');
  NeonMovement.init();
  NeonJoystick.init();
  NeonAnimation.init();

  // ── STEP 11 — HUD ──────────────────────────────────────────────────────────
  progress(88, 'Loading HUD…');
  NeonHUD.init();
  NeonHUD.update({
    display_name:      profile?.display_name || profile?.username,
    level:             profile?.level || 1,
    coins:             profile?.coins || 0,
    score:             profile?.score || 0,
    current_level_xp:  0,
    xp_to_next_level:  100
  });

  // ── STEP 12 — Vehicles ──────────────────────────────────────────────────────
  progress(90, 'Parking vehicles…');
  NeonVehicles.init();

  // ── STEP 13 — Socket (multiplayer) ─────────────────────────────────────────
  progress(93, 'Connecting multiplayer…');
  NeonSocket.connect();

  // Wait briefly for socket to connect before joining zone
  await new Promise(r => setTimeout(r, 600));

  const zone = profile?.current_zone || 'neon_city';
  NeonSocket.joinZone(zone, profile?.display_name || profile?.username, charKey);
  NeonHUD.setZone(formatZoneName(zone));

  // ── STEP 14 — Announcements ─────────────────────────────────────────────────
  progress(96, 'Checking announcements…');
  try {
    const annRes = await NeonAPI.getAnnouncements();
    if (annRes.success && annRes.announcements?.length > 0) {
      const latest = annRes.announcements[0];
      setTimeout(() => NeonHUD.showAnnouncement(`📢 ${latest.title}: ${latest.body}`), 2000);
    }
  } catch (e) { /* no announcements */ }

  // ── STEP 15 — Daily bonus check ─────────────────────────────────────────────
  try {
    const dailyRes = await NeonAPI.claimDailyBonus();
    if (dailyRes.success && dailyRes.coins > 0) {
      setTimeout(() => {
        NeonHUD.floatText(`+${dailyRes.coins} daily bonus!`, 'var(--neon-yellow)');
        NeonHUD.animateCoins(dailyRes.new_total, dailyRes.coins);
      }, 3000);
    }
  } catch (e) { /* already claimed today */ }

  // ── STEP 16 — Start render loop ─────────────────────────────────────────────
  progress(100, 'Entering Neon World…');
  NeonScene.startLoop();

  await new Promise(r => setTimeout(r, 400));
  hideLoader();
  NeonHUD.show();

  console.log('🌆 Neon World is live!');

  // ── Auto-save position every 30 seconds ────────────────────────────────────
  setInterval(async () => {
    const spr = NeonCharacter.getSprite();
    if (!spr) return;
    try {
      await NeonAPI.savePosition(
        Math.round(spr.position.x * 10) / 10,
        Math.round(spr.position.y * 10) / 10,
        Math.round(spr.position.z * 10) / 10,
        NeonSocket.getZone()
      );
    } catch (e) { /* non-critical */ }
  }, 30_000);

  // ── Refresh game settings every 60 seconds ─────────────────────────────────
  setInterval(async () => {
    try {
      const sRes = await NeonAPI.getSettings();
      if (sRes.success) {
        // Apply live settings (economy, features, etc.)
        const s = sRes.settings || {};
        if (s.day_night_enabled === 'false') NeonLighting.setEnabled(false);
        if (s.weather_enabled   === 'false') NeonWeather.setRainEnabled(false);
      }
    } catch (e) { /* non-critical */ }
  }, 60_000);

})();

// ── Zone name formatter ─────────────────────────────────────────────────────
function formatZoneName(key) {
  const names = {
    neon_city: 'Neon City',
    farm:      'Green Farm',
    highway:   'Neon Highway',
    beach:     'Dark Beach',
    hills:     'Shadow Hills',
    industrial:'Industrial Zone'
  };
  return names[key] || key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}
